package net.travelsky.skymart.code.enums;

public enum ResultCode {
	
	// 正常返回
	SUCCESS("200"),
	// 操作失败
	FAIL("404"),
	// 系统级错误
	ERROR("500");
	
	
	private ResultCode(String value) {
		this.value = value;
	}

	private String value;

	public String getValue() {
		return value;
	}
	
}
