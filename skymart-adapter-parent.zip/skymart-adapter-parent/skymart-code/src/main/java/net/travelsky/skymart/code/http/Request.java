package net.travelsky.skymart.code.http;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpHost;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import lombok.extern.slf4j.Slf4j;
import net.travelsky.skymart.code.http.config.URLConfig;
import net.travelsky.skymart.code.http.enums.Encoding;
import net.travelsky.skymart.code.http.enums.HeaderKey;

/**
 * 请求的父类
 * @ClassName Request
 * @Description TODO
 * @author CY
 * @date 2018年8月29日 下午12:34:40
 */
@Slf4j
public abstract class Request {
    /**
     *  scoket超时时间
     */
    private int scoketTimeout = 2000;
    /**
     *  连接超时时间
     */
    private int connectTimeout = 2000;
    /**
     * 添加的头部信息
     */
    private Map<String, String> headers = new HashMap<String,String>(0);

    /**
     * 参数对象
     */
    protected HttpParameter parameter;
    
    /**
     * 抽象方法，需要子类实现，发送post请求
     * @Title sendPost
     * @Description TODO
     * @param config
     * @param encoding
     * @return
     */
    abstract HttpResponse sendPost(URLConfig config,Encoding encoding);
    
    /**
     *  抽象方法，需要子类实现，发送post请求,可以设置代理
        * @Title: sendPost  
        * @Description: TODO  
        * @param @param config
        * @param @param encoding
        * @param @param proxy
        * @param @return
        * @return HttpResponse
        * @throws
     */
    abstract HttpResponse sendPost(URLConfig config,Encoding encoding, HttpHost proxy);
    
    /**
     * 抽象方法，需要子类实现，发送get请求
     * @Title sendGet
     * @Description TODO
     * @param config
     * @param encoding
     * @return
     */
    abstract HttpResponse sendGet(URLConfig config,Encoding encoding);
    
    /**
     * 设置参数对象
     * @Title setParameter
     * @Description TODO
     * @param parameter
     */
    public void setParameter(HttpParameter parameter) {
        this.parameter = parameter;
    }
    
    public HttpParameter getParameer() {
        return this.parameter;
    }
    
    /**
     * 添加一个头部信息，包括key 与 value
     * @Title addHeader
     * @Description TODO
     * @param key
     * @param value
     */
    public Request addHeader(HeaderKey hKey,String value) {
        log.debug("[headerKey="+hKey+"]----["+"headerValue="+value+"]");
        headers.put(hKey.getValue(), value);
        // 默认表单形式提交
        return this;
    }
    /**
     * 添加一组头部信息，包括key 与 value
     * @Title addHeaders
     * @Description TODO
     * @param header
     */
    public Request addHeaders(Map<HeaderKey, String> header) {
        if(header == null || header.isEmpty()) return this;
        for(Map.Entry<HeaderKey, String> entry : header.entrySet()) {
            addHeader(entry.getKey(),entry.getValue());
        }
        return this;
    }
 
    /**
     * 得到header类型
     * @Title getHeader
     * @Description TODO
     * @param key
     */
    public String getHeader(String key) {
        for(Map.Entry<String, String> entry : headers.entrySet()) {
            if(entry.getKey().equals(key)) {
                return entry.getValue();
            }
        }
        return null ;
    }
    public int getScoketTimeout() {
        return scoketTimeout;
    }
    
    /**
     * 设置
     * @Title setScoketTimeout
     * @Description TODO
     * @param scoketTimeout
     */
    public Request setScoketTimeout(int scoketTimeout) {
        this.scoketTimeout = scoketTimeout;
        return this;
    }

    public int getConnectTimeout() {
        return connectTimeout;
    }
    
    /**
     * 设置连接超时时间
     * @Title setConnectTimeout
     * @Description TODO
     * @param connectTimeout
     */
    public Request setConnectTimeout(int connectTimeout) {
        this.connectTimeout = connectTimeout;
        return this;
    }
    
    protected void setHeader(HttpPost httpPost) {
        if(headers.isEmpty()) return;
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            httpPost.setHeader(entry.getKey(), entry.getValue());
        }   
    }
    
    protected void setHeader(HttpGet httpGet) {
        if(headers.isEmpty()) {
            return;
        }
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            httpGet.setHeader(entry.getKey(), entry.getValue());
        }
    }
}
