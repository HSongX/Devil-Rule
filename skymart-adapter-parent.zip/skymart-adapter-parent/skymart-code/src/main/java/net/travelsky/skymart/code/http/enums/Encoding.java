package net.travelsky.skymart.code.http.enums;
public enum Encoding {
    
    UTF8("UTF-8"),
    GBK("GB2312"),
    ISO8859("ISO-8859-1");
    
    private String value;
    private Encoding(String value) {
        this.value = value;
    }
    public String getValue() {
        return this.value;
    }
}
