package net.travelsky.skymart.code.mybatis;

import java.util.List;

public class Parameter {
	
	@SuppressWarnings("unused")
	private boolean isValid;
	
	private List<Condition> conditions;
	
	private List<String> orderByList;
	
	private String sort;

	public String getSort() {
		return sort;
	}

	public Parameter(List<Condition> conditions,List<String> orderByList ,String sort) {
		this.sort = sort;
		this.conditions = conditions;
		this.orderByList = orderByList;
	}

	/**
	 * 是否有排序字段
	 */
	public boolean isOpenOrderBy() {
		if(orderByList.isEmpty())
			return false;
		return  true;
	}
	
	public boolean isValid() {
		if(null == conditions)
			return this.isValid = false;
		if(conditions.isEmpty())
			return this.isValid = false;
		return isValid = true;
	}
	
}
