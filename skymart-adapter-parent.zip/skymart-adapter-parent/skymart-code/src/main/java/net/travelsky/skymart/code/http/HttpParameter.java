package net.travelsky.skymart.code.http;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 *  参数对象
 * @ClassName HttpParameter
 * @Description TODO
 * @author CY
 * @date 2018年8月29日 下午3:22:13
 */
public class HttpParameter {

    private Map<String, String> paramMap = new HashMap<String, String>();
    
    private List<Map.Entry<String, String>> parameterList = new ArrayList<Map.Entry<String, String>>(paramMap.entrySet());
    
    public HttpParameter setParameter(String key,String value) {
        paramMap.put(key, value);
        return this;
    }
    
    public HttpParameter setParameter(String value) {
        paramMap.put("", value);
        return this;
    }
    
    public Map<String, String> getParameterMap(){
        return paramMap;
    }
    
    public List<Map.Entry<String, String>> getParameter() {
        parameterList.addAll(paramMap.entrySet());
        return parameterList;
    }
    
    public void asc() {
        Collections.sort(parameterList, new Comparator<Map.Entry<String, String>>() {
            @Override
            public int compare(Entry<String, String> o1, Entry<String, String> o2) {
                return o1.getKey().compareTo(o2.getKey());
            }
            
        });
    }
    
    public void desc() {
        Collections.sort(parameterList, new Comparator<Map.Entry<String, String>>() {
            @Override
            public int compare(Entry<String, String> o1, Entry<String, String> o2) {
                return o2.getKey().compareTo(o1.getKey());
            }
            
        });
    }
    
}
