package net.travelsky.skymart.code.http;
import java.io.IOException;
import java.net.URISyntaxException;
import net.travelsky.skymart.code.http.config.URLConfig;
import net.travelsky.skymart.code.http.enums.Encoding;
import net.travelsky.skymart.code.http.enums.Scheme;

public class RequestDemo {
    /**
     * 请求案例
     * @Title main
     * @Description TODO
     * @param args
     * @throws IOException
     * @throws URISyntaxException
     */
    @SuppressWarnings("unused")
    public static void main(String[] args) throws IOException, URISyntaxException {
        
        String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
                "<AirShoppingRQ xmlns=\"http://www.iata.org/IATA/EDIST\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.iata.org/IATA/EDIST/AirShoppingRQ.xsd\" Version=\"\">\r\n" + 
                "    <Document/>\r\n" + 
                "    <Party>\r\n" + 
                "        <Sender>\r\n" + 
                "            <TravelAgencySender>\r\n" + 
                "                <!--部门ID-->\r\n" + 
                "                <AgencyID>123</AgencyID>\r\n" + 
                "            </TravelAgencySender>\r\n" + 
                "        </Sender>\r\n" + 
                "    </Party>\r\n" + 
                "    <Parameters>\r\n" + 
                "        <CurrCodes>\r\n" + 
                "            <!--货币三字码-->\r\n" + 
                "            <CurrCode>USD</CurrCode>\r\n" + 
                "        </CurrCodes>\r\n" + 
                "        <Inventory>\r\n" + 
                "            <!--选填项 三种场景：\r\n" + 
                "                    1、传GuaranteeInd节点并且值为false，\r\n" + 
                "                    2、传GuaranteeInd节点并且值为true，\r\n" + 
                "                    3、不传GuaranteeInd节点\r\n" + 
                "             -->\r\n" + 
                "            <GuaranteeInd>false</GuaranteeInd>\r\n" + 
                "        </Inventory>\r\n" + 
                "    </Parameters>\r\n" + 
                "    <Travelers>\r\n" + 
                "        <Traveler>\r\n" + 
                "            <AnonymousTraveler>\r\n" + 
                "                <!--PTC:旅客类型（ADT 成人） Quantity：人数-->\r\n" + 
                "                <PTC Quantity=\"2\">ADT</PTC>\r\n" + 
                "            </AnonymousTraveler>\r\n" + 
                "        </Traveler>\r\n" + 
                "        <Traveler>\r\n" + 
                "            <AnonymousTraveler>\r\n" + 
                "                <!--PTC:旅客类型（CHD 儿童） Quantity：人数-->\r\n" + 
                "                <PTC Quantity=\"1\">CHD</PTC>\r\n" + 
                "            </AnonymousTraveler>\r\n" + 
                "        </Traveler>\r\n" + 
                "        <Traveler>\r\n" + 
                "            <AnonymousTraveler>\r\n" + 
                "                <!--PTC:旅客类型（INF 婴儿） Quantity：人数-->\r\n" + 
                "                <PTC Quantity=\"1\">INF</PTC>\r\n" + 
                "            </AnonymousTraveler>\r\n" + 
                "        </Traveler>\r\n" + 
                "    </Travelers>\r\n" + 
                "    <CoreQuery>\r\n" + 
                "        <OriginDestinations>\r\n" + 
                "            <!--一个OriginDestination节点为单程，两个OriginDestination节点为往返-->\r\n" + 
                "            <OriginDestination>\r\n" + 
                "                <Departure>\r\n" + 
                "                    <!--出发地三字码-->\r\n" + 
                "                    <AirportCode>HAK</AirportCode>\r\n" + 
                "                    <!--出发时间-->\r\n" + 
                "                    <Date>2016-08-01</Date>\r\n" + 
                "                </Departure>\r\n" + 
                "                <Arrival>\r\n" + 
                "                    <!--目的地三字码-->\r\n" + 
                "                    <AirportCode>CKG</AirportCode>\r\n" + 
                "                </Arrival>\r\n" + 
                "            </OriginDestination>\r\n" + 
                "            <OriginDestination>\r\n" + 
                "                <Departure>\r\n" + 
                "                    <!--出发地三字码-->\r\n" + 
                "                    <AirportCode>CKG</AirportCode>\r\n" + 
                "                    <!--返回时间-->\r\n" + 
                "                    <Date>2016-08-02</Date>\r\n" + 
                "                </Departure>\r\n" + 
                "                <Arrival>\r\n" + 
                "                    <!--目的地三字码-->\r\n" + 
                "                    <AirportCode>HAK</AirportCode>\r\n" + 
                "                </Arrival>\r\n" + 
                "            </OriginDestination>\r\n" + 
                "        </OriginDestinations>\r\n" + 
                "    </CoreQuery>\r\n" + 
                "</AirShoppingRQ>\r\n" + 
                "";
        // XML请求案例
//        URLConfig httpURL = new URLConfig(Scheme.HTTP,"localhost","9090","/skymart-ndc-api/air/api/air_shopping_rs");
//        HttpRequest request = new HttpRequest();
//        request.addHeader(HeaderKey.ContentType, "text/xml");
//        request.setParameter(new HttpParameter().setParameter(data));        
//        HttpResponse response = request.sendPost(httpURL, Encoding.UTF8);
        
        // JSON请求案例
//        Map<String,String> param = new HashMap<String, String>();
//        param.put("username","admin");
//        param.put("password","000000"); 
//        data = JSONArray.toJSONString(param); 
//        URLConfig httpURL = new URLConfig(Scheme.HTTP,"localhost","9090","/system/auth/do_login");
//        HttpRequest request = new HttpRequest();
//        request.addHeader(HeaderKey.ContentType, "application/json");
//        request.setParameter(new HttpParameter().setParameter(data));        
//        HttpResponse response = request.sendPost(httpURL, Encoding.UTF8);
        
        // 表单提交案例
//        URLConfig httpURL = new URLConfig(Scheme.HTTP,"localhost","9090","/system/auth/test_form");
//        HttpRequest request = new HttpRequest();
//        request.setParameter(new HttpParameter().setParameter("username","admin").setParameter("password","000000"));
//        HttpResponse response = request.sendPost(httpURL, Encoding.UTF8);
        
        // https请求
      URLConfig httpURL = new URLConfig(Scheme.HTTPS,"www.baidu.com");
      HttpRequest request = new HttpRequest();
      //request.setParameter(new HttpParameter().setParameter("username","admin").setParameter("password","000000"));        
      HttpResponse response = request.sendGet(httpURL, Encoding.UTF8);
        
        System.out.println(response);
    }
}
