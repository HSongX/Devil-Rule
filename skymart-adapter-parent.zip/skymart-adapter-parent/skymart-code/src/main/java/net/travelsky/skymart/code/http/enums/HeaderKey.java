package net.travelsky.skymart.code.http.enums;
/**
 * HTTP 请求常用的枚举类型
 * @ClassName HeaderKey
 * @Description TODO
 * @author CY
 * @date 2018年8月28日 下午5:01:46
 */
public enum HeaderKey {
    
    // 指定客户端能够接收的内容类型
    Accept("Accept"),
    // 浏览器可以接受的字符编码集
    AcceptCharset("Accept-Charset"),
    // 指定浏览器可以支持的web服务器返回内容压缩编码类型。
    AcceptEncoding("Accept-Encoding"),
    // 浏览器可接受的语言
    AcceptLanguage("Accept-Language"),
    // HTTP授权的授权证书
    Authorization("Authorization"),
    // 指定请求和响应遵循的缓存机制
    CacheControl("Cache-Control"),
    // 表示是否需要持久连接。（HTTP 1.1默认进行持久连接）
    Connection("Connection"),
    // HTTP请求发送时，会把保存在该请求域名下的所有cookie值一起发送给web服务器
    Cookie("Cookie"),
    // 请求的内容长度
    ContentLength("Content-Length"),
    // 请求的与实体对应的MIME信息
    ContentType("Content-Type"),
    // 请求发送的日期和时间
    Date("Date"),
    // User-Agent的内容包含发出请求的用户信息
    UserAgent("User-Agent"),
    // 先前网页的地址，当前请求网页紧随其后,即来路
    Referer("Referer");
    
    private String value;
    
    private HeaderKey(String value) {
        this.value = value;
    }
    
    public String getValue() {
        return this.value;
    }
}
