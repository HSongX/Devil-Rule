package net.travelsky.skymart.code.http;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.http.HttpHost;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import lombok.extern.slf4j.Slf4j;
import net.travelsky.skymart.code.http.config.HttpConnectionManager;
import net.travelsky.skymart.code.http.config.URLConfig;
import net.travelsky.skymart.code.http.enums.Encoding;
import net.travelsky.skymart.code.http.enums.HeaderKey;
import net.travelsky.skymart.code.http.enums.Method;


@Slf4j
public class HttpRequest extends Request{

    @Override
    public HttpResponse sendPost(URLConfig config,Encoding encoding) {
        
        HttpResponse response = null;
        try {
            response = send(config, Method.POST, encoding, null);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }
    
    @Override
    public HttpResponse sendPost(URLConfig config,Encoding encoding, HttpHost proxy) {
        
        HttpResponse response = null;
        try {
            response = send(config, Method.POST, encoding, proxy);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }

    @Override
    public HttpResponse sendGet(URLConfig config,Encoding encoding) {
        HttpResponse response = null;
        try {
            response = send(config, Method.GET, encoding, null);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }
    
    /**
     * 发送请求
     * @Title send
     * @Description TODO
     * @param url 请求的URL
     * @param param 请求的参数
     * @param method 请求的方法
     * @return
     * @throws IOException 
     * @throws URISyntaxException 
     */
    @SuppressWarnings("static-access")
    private HttpResponse send(URLConfig urlConfig,Method method,Encoding encoding, HttpHost proxy) throws IOException, URISyntaxException {
        // 编码不传递这个参数的情况，使用默认编码UTF-8
        if(encoding == null) {
            encoding = encoding.UTF8;
        }
        HttpResponse response = new HttpResponse();
        // 通过连接池创建CloseableHttpClient
        CloseableHttpClient httpclient = HttpConnectionManager.newInstance().getHttpClient(); 
        // 设置请求和传输超时时间
        RequestConfig config = RequestConfig.custom()
                .setSocketTimeout(getScoketTimeout())
                .setConnectTimeout(getConnectTimeout())
                .setProxy(proxy)
                .build();
        // GET 请求
        if(method.equals(Method.GET)) {
            // 创建GET请求连接信息，并且设置参数
            URIBuilder uri = new URIBuilder()
                    .setScheme(urlConfig.getScheme().getValue())
                    .setHost(urlConfig.getHost()+":"+urlConfig.getPort())
                    .setPath(urlConfig.getPath());
            if(parameter != null) {
                List<Map.Entry<String, String>> param = parameter.getParameter();
                // 设置GET请求参数
                for(Entry<String, String> entry : param) {
                    uri.setParameter(entry.getKey(), entry.getValue());
                }
            }
            
            HttpGet hGet = new HttpGet(uri.build());
            hGet.setConfig(config);
            // 设置请求的头部信息
            setHeader(hGet);
            log.debug("请求方式:"+method);
            log.debug("请求地址:"+hGet.getURI());

            // 发送请求，得到响应对象
            CloseableHttpResponse resp = httpclient.execute(hGet);
            log.debug("响应结果："+resp.getStatusLine().getStatusCode());
            response.setStatus(resp.getStatusLine().getStatusCode());
            response.setSuccess((resp.getStatusLine().getStatusCode() == HttpStatus.SC_OK) ? true : false);
            response.setResponse(EntityUtils.toString(resp.getEntity(),encoding.getValue()));
            // 关闭流
            EntityUtils.consume(resp.getEntity());
            resp.close();
            
        }
        // POST 请求
        if(method.equals(Method.POST)) {
            
            URIBuilder uri = new URIBuilder()
                    .setScheme(urlConfig.getScheme().getValue())
                    .setHost(urlConfig.getHost()+":"+urlConfig.getPort())
                    .setPath(urlConfig.getPath());  
            HttpPost hPost = new HttpPost(uri.build());
            hPost.setConfig(config);
            setHeader(hPost);
            log.debug("请求方式:"+method);
            log.debug("请求地址:"+hPost.getURI());
            
            String contentType = getHeader(HeaderKey.ContentType.getValue());
            // 默认的请求方式,表单形式
            if(contentType == null) {
                contentType = "application/x-www-form-urlencoded";
            }
            if(parameter != null) {
                // 装填参数
                if(contentType.equals("application/x-www-form-urlencoded")) {        
                    List<NameValuePair> nvps = new ArrayList<NameValuePair>();
                    List<Map.Entry<String, String>> param = parameter.getParameter();
                    for (Entry<String, String> entry : param) {
                        nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                    }
                    hPost.setEntity(new UrlEncodedFormEntity(nvps, encoding.getValue()));   
                }
                
                // json数据发送
                else if(contentType.equals("application/json")) { 
                    List<Map.Entry<String, String>> param = parameter.getParameter();
                    for (Entry<String, String> entry : param) {
                        StringEntity sEntity = new StringEntity(entry.getValue());
                        sEntity.setContentEncoding(encoding.getValue());
                        sEntity.setContentType("application/json");
                        hPost.setEntity(sEntity);
                    }
                }
                // xml数据发送
                else if(contentType.equals("text/xml")) {
                    List<Map.Entry<String, String>> param = parameter.getParameter();
                    for (Entry<String, String> entry : param) {
                        StringEntity sEntity = new StringEntity(entry.getValue());
                        sEntity.setContentType("text/xml");
                        sEntity.setContentEncoding(encoding.getValue());
                        hPost.setEntity(sEntity);  
                    }
                }
                // 默认
                else {
                    List<NameValuePair> nvps = new ArrayList<NameValuePair>();
                    List<Map.Entry<String, String>> param = parameter.getParameter();
                    for (Entry<String, String> entry : param) {
                        nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                    }
                    hPost.setEntity(new UrlEncodedFormEntity(nvps, encoding.getValue())); 
                }
            }
            
            // 发送请求，得到响应对象
            CloseableHttpResponse resp = httpclient.execute(hPost);
            log.debug("响应结果："+resp.getStatusLine().getStatusCode());
            response.setStatus(resp.getStatusLine().getStatusCode());
            response.setSuccess((resp.getStatusLine().getStatusCode() == HttpStatus.SC_OK) ? true : false);
            response.setResponse(EntityUtils.toString(resp.getEntity(),encoding.getValue()));
            // 关闭流
            EntityUtils.consume(resp.getEntity());
            resp.close();
        }
        //httpclient.close();
        return response;
    }
    
}
