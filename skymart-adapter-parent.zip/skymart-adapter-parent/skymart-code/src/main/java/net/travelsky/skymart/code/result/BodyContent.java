package net.travelsky.skymart.code.result;


/**
 *  返回消息的主体
    * @ClassName: Body  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月9日  
    *
 */
public class BodyContent implements java.io.Serializable{
	  
	private static final long serialVersionUID = -7927254069135213235L;
	private Object data = new Object();
	
	public Object getData() {
		return data;
	}
	
	public void setData(Object data) {
		this.data = data;
	}
	
}


