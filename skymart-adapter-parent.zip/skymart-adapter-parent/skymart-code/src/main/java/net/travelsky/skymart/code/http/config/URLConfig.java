package net.travelsky.skymart.code.http.config;
import net.travelsky.skymart.code.http.enums.Scheme;

public class URLConfig {
    // 请求的协议
    private Scheme scheme;
    // 请求的地址/域名
    private String host;
    // 请求的端口
    private String port;
    // 请求路径
    private String path;

    public URLConfig() {
        super();
    }

    public URLConfig(Scheme scheme, String host) {
        super();
        this.scheme = scheme;
        this.host = host;
    }

    public URLConfig(Scheme scheme, String host, String port) {
        super();
        this.scheme = scheme;
        this.host = host;
        this.port = port;
    }

    public URLConfig(Scheme scheme, String host, String port, String path) {
        super();
        this.scheme = scheme;
        this.host = host;
        this.port = port;
        this.path = path;
    }

    public Scheme getScheme() {
        return scheme;
    }
    public URLConfig setScheme(Scheme scheme) {
        this.scheme = scheme;
        return this;
    }
    public String getHost() {
        return host;
    }
    public URLConfig setHost(String host) {
        this.host = host;
        return this;
    }
    public String getPort() {
        return port;
    }
    public URLConfig setPort(String port) {
        this.port = port;
        return this;
    }
    public String getPath() {
        return path;
    }
    public URLConfig setPath(String path) {
        this.path = path;
        return this;
    }
    
}
