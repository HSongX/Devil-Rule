package net.travelsky.skymart.code.http;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class HttpResponse {
    /**
     * 响应的结果
     */
    private String response;
    /**
     * 响应状态是否成功
     */
    private boolean isSuccess = false;
    /**
     * 响应码
     */
    private int status;
}
