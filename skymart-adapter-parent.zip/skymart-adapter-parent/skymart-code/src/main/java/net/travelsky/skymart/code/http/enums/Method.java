package net.travelsky.skymart.code.http.enums;

/**
 * 枚举类型，请求的类型
 * @ClassName Method
 * @Description TODO
 * @author CY
 * @date 2018年8月28日 下午4:26:49
 */
public enum Method {

    GET("GET"),POST("POST");

    @SuppressWarnings("unused")
    private String value;
    
    private Method(String value) {
        this.value = value;
    }
    
}
