package net.travelsky.skymart.code.handler;

import javax.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import net.travelsky.skymart.code.enums.ResultCode;
import net.travelsky.skymart.code.result.ResultEntity;
import net.travelsky.skymart.code.result.ResultEntityUtil;

/**
 * 统一异常处理拦截
 * @ClassName ExceptionHandlerAdvice
 * @Description TODO
 * @author CY
 * @date 2018年8月28日 下午3:49:28
 */
@ControllerAdvice
public class ExceptionHandlerAdvice {

    @ExceptionHandler({ Exception.class })
    @ResponseBody
    public ResultEntity handException(HttpServletRequest request ,Exception e) throws Exception {
        // 打印异常信息，生成环境应该关闭
        // e.printStackTrace();
        return ResultEntityUtil.getEntity(ResultCode.ERROR , "500","程序发生未知异常");
    }
    
}
