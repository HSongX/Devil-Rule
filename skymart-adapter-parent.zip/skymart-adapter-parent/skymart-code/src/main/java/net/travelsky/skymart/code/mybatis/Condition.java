package net.travelsky.skymart.code.mybatis;

import java.util.List;

/**
 * 
    * @ClassName: Condition  symbol
    * @Description: mybatis 相关的查询条件对象  
    * @author CY  
    * @date 2018年8月1日  
    *
 */
public class Condition {
	
	/**
	 * 符号
	 */
	private String symbol;
	/**
	 * 列名
	 */
	private String column;
	/**
	 * 值
	 */
	private String value;
	/**
	 * 第二个value值，一般用户between
	 */
	private String endValue;
	/**
	 * in 条件用到的values
	 */
	private List<String> values;
	/**
	 * 逻辑运算符
	 */
	private String logical;
	/**
	 * 是否是in条件
	 */
	private boolean isIn;
	/**
	 * 是否是between条件
	 */
	private boolean isBetWeen;
	/**
	 * 是否是like条件
	 */
	private boolean isLike;
	/**
	 * 非特殊条件下
	 */
	private boolean isBase;

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	public Condition() {
		super();
	}
	
	public Condition(String column, String value) {
		super();
		this.column = column;
		this.value = value;
	}

	public Condition(String symbol, String column, String value) {
		super();
		this.symbol = symbol;
		this.column = column;
		this.value = value;
	}
	
	public String getEndValue() {
		return endValue;
	}

	public void setEndValue(String endValue) {
		this.endValue = endValue;
	}

	public boolean isBase() {
		return isBase;
	}

	public void setBase(boolean isBase) {
		this.isBase = isBase;
	}

	public boolean isLike() {
		return isLike;
	}

	public void setLike(boolean isLike) {
		this.isLike = isLike;
	}
	
	public String getLogical() {
		return logical;
	}

	public void setLogical(String logical) {
		this.logical = logical;
	}

	public boolean isInparam() {
		return isIn;
	}
	public void setIn(boolean isIn) {
		this.isIn = isIn;
	}
	public boolean isBetWeen() {
		return isBetWeen;
	}
	public void setBetWeen(boolean isBetWeen) {
		this.isBetWeen = isBetWeen;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getColumn() {
		return column;
	}
	public void setColumn(String column) {
		this.column = column;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	
	
}
