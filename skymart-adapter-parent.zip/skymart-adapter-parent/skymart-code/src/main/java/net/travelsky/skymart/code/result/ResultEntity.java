package net.travelsky.skymart.code.result;
/**
 *  系统返回的信息对象
    * @ClassName: ResultEntity  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月9日  
    *
 */
public class ResultEntity implements java.io.Serializable{

	private static final long serialVersionUID = 6621281715609770356L;
	private HeaderContent header;
	private BodyContent body;
	public HeaderContent getHeader() {
		return header;
	}
	public void setHeader(HeaderContent header) {
		this.header = header;
	}
	public BodyContent getBody() {
		return body;
	}
	public void setBody(BodyContent body) {
		this.body = body;
	}
	
	
}
