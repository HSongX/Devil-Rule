package net.travelsky.skymart.code.result;

/**
 *  返回的头部信息
    * @ClassName: HeaderContent  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月9日  
    *
 */
public class HeaderContent implements java.io.Serializable{
	
	private static final long serialVersionUID = 8679537322213175900L;

	/**
	 * 相应的状态吗
	 */
	private String stateCode;
	
	/**
	 * 返回的消息对象
	 */
	private Message msg;

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public Message getMsg() {
		return msg;
	}

	public void setMsg(Message msg) {
		this.msg = msg;
	}
	
	
}
