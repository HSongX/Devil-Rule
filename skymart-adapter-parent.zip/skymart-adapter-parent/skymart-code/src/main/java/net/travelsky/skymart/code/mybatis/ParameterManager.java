package net.travelsky.skymart.code.mybatis;
import java.util.ArrayList;
import java.util.List;

/**
 * 
    * @ClassName: MapperParameter  
    * @Description: 处理mybatis  查询条件的封装类  
    * @author CY  
    * @date 2018年8月1日  
    *
 */
public class ParameterManager {
	/**
	 * 符号常量定义
	 */
	private static final String EQ = "=";
	private static final String NO_EQ = "<>";
	private static final String GT = ">";
	private static final String LT = "<";
	private static final String GT_EQ = ">=";
	private static final String LT_EQ = "<=";
	private static final String IS_NULL = "is null";
	private static final String IS_NOT_NULL = "is not null";
	private static final String LIKE = "like";
	private static final String BETWEEN = "between";
	private static final String IN = "in";
	private static final String NOT_IN = "not in";
	private static final String AND = "and";
	private static final String OR = "or";
	public static final String DESC = "desc";
	public static final String ASC = "asc";
	
	/**
	 * 排序方式
	 */
	private String sort;
	
	/**
	 * 查询条件对象集合
	 */
	private List<Condition> conditions = new ArrayList<>();
	
	/**
	 * 排序条件集合
	 */
	private List<String> orderByList = new ArrayList<>();
	
	
	public String getSort() {
		if(sort == null) {
			return sort = DESC;
		}
		return this.sort;
	}
	
	public void setSort(String sort) {
		this.sort = sort;
	}

	/**
	 * 
	    * @Title: setOrderBy  
	    * @Description: 设置查询 排序相关参数  
	    * @param @param column
	    * @param @return
	    * @return List<String>
	    * @throws
	 */
	public ParameterManager setOrderBy(String column) {
		orderByList.add(column);
		return this;
	}
	
	/**
	 * 
	    * @Title: setOrderBy  
	    * @Description: 设置查询 排序相关参数    
	    * @param @param columns
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager setOrderBy(List<String> columns) {
		if(columns == null || columns.isEmpty()) {
			return this;
		}
		orderByList.addAll(columns);
		return this;
	}
	
	/**
	 * 
	    * @Title: setOrderBy  
	    * @Description: 设置查询 排序相关参数      
	    * @param @param columns
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager setOrderBy(String... columns) {
		if(columns == null || columns.length <= 0) {
			return this;
		}
		for(String column : columns) {
			orderByList.add(column);
		}
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: orNotIn  
	    * @Description: in 查询条件    
	    * @param @param column
	    * @param @param values
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager orNotIn(String column, List<String> values) {
		if(values == null || values.isEmpty()) {
			return this;
		}
		Condition condition = this.addConditions(OR, column, "", NOT_IN);
		condition.setValues(values);
		condition.setIn(true);
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: orNotIn  
	    * @Description: in 查询条件    
	    * @param @param column
	    * @param @param values
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager orNotIn(String column, String... values) {
		if(values == null || values.length < 0) {
			return this;
		}
		List<String> paramValues = new ArrayList<>();
		for(String value : values) {
			paramValues.add(value);
		}
		Condition condition = this.addConditions(OR, column, "", NOT_IN);
		condition.setValues(paramValues);
		condition.setIn(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addNotIn  
	    * @Description: in 查询条件    
	    * @param @param column
	    * @param @param values
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager addNotIn(String column, List<String> values) {
		if(values == null || values.isEmpty()) {
			return this;
		}
		Condition condition = this.addConditions(AND, column, "", NOT_IN);
		condition.setValues(values);
		condition.setIn(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addNotIn  
	    * @Description: in 查询条件   
	    * @param @param column
	    * @param @param values
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager addNotIn(String column, String... values) {
		if(values == null || values.length < 0) {
			return this;
		}
		List<String> paramValues = new ArrayList<>();
		for(String value : values) {
			paramValues.add(value);
		}
		Condition condition = this.addConditions(AND, column, "", NOT_IN);
		condition.setValues(paramValues);
		condition.setIn(true);
		return this;
	}
	
	
	/** 与逻辑运算
	    * @Title: addIn  
	    * @Description: in 查询条件  
	    * @param @param column
	    * @param @param values
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager addIn(String column, List<String> values) {
		if(values == null || values.isEmpty()) {
			return this;
		}
		Condition condition = this.addConditions(AND, column, "", IN);
		condition.setValues(values);
		condition.setIn(true);
		return this;
	}
	
	/** 与逻辑运算
	    * @Title: addIn  
	    * @Description: in 查询条件  (重载方法)
	    * @param @param column
	    * @param @param values
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager addIn(String column, String... values) {
		if(values == null || values.length < 0) {
			return this;
		}
		List<String> paramValues = new ArrayList<>();
		for(String value : values) {
			paramValues.add(value);
		}
		Condition condition = this.addConditions(AND, column, "", IN);
		condition.setValues(paramValues);
		condition.setIn(true);
		return this;
	}
	
	/** 或逻辑运算
	    * @Title: orIn  
	    * @Description: in 查询条件  (重载方法)
	    * @param @param column
	    * @param @param values
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager orIn(String column, List<String> values) {
		if(values == null || values.isEmpty()) {
			return this;
		}
		Condition condition = this.addConditions(OR, column, "", IN);
		condition.setValues(values);
		condition.setIn(true);
		condition.setBetWeen(true);
		return this;
	}
	
	/** 或逻辑运算
	    * @Title: orIn  
	    * @Description: in 查询条件  (重载方法)
	    * @param @param column
	    * @param @param values
	    * @param @return
	    * @return ParameterManager
	    * @throws
	 */
	public ParameterManager orIn(String column, String... values) {
		if(values == null || values.length < 0) {
			return this;
		}
		List<String> paramValues = new ArrayList<>();
		for(String value : values) {
			paramValues.add(value);
		}
		Condition condition = this.addConditions(OR, column, "", IN);
		condition.setValues(paramValues);
		condition.setIn(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addBetween  
	    * @Description: between 条件设置  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager addBetween(String column, String startVale,String endValue) {
		Condition condition = this.addConditions(AND, column, startVale, BETWEEN);
		condition.setEndValue(endValue);
		condition.setBetWeen(true);
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: addBetween  
	    * @Description: between 条件设置    
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orBetween(String column, String startVale,String endValue) {
		Condition condition = this.addConditions(OR, column, startVale, BETWEEN);
		condition.setEndValue(endValue);
		condition.setBetWeen(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addLike  
	    * @Description: like 的查询条件  
	    * @param @param column
	    * @param @param value
	    * @param @param leftMatch   是否左侧匹配
	    * @param @param rightMatch  是否右侧匹配
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager addLike(String column, String value, boolean leftMatch, boolean rightMatch) {
		String val = value;
		if(leftMatch) {
			val = "%" + val;
		}
		if(rightMatch) {
			val = val + "%";
		}
		Condition condition = this.addConditions(AND, column, val, LIKE);
		condition.setLike(true);
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: orLike  
	    * @Description: like 的查询条件  
	    * @param @param column
	    * @param @param value
	    * @param @param leftMatch   是否左侧匹配
	    * @param @param rightMatch  是否右侧匹配
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orLike(String column, String value, boolean leftMatch, boolean rightMatch) {
		String val = value;
		if(leftMatch) {
			val = "%" + val;
		}
		if(rightMatch) {
			val = val + "%";
		}
		Condition condition = this.addConditions(OR, column, val, LIKE);
		condition.setLike(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addIsNotNull  
	    * @Description: value 值不是null的查询条件    （非空条件）
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager addIsNotNull(String column, String value) {
		Condition condition = this.addConditions(AND, column, value, IS_NOT_NULL);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: orIsNotNull  
	    * @Description: value 值不是null的查询条件    （非空条件）  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orIsNotNull(String column, String value) {
		Condition condition = this.addConditions(OR, column, value, IS_NOT_NULL);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addIsNull  
	    * @Description: value 值是null的查询条件  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager addIsNull(String column, String value) {
		Condition condition = this.addConditions(AND, column, value, IS_NULL);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: orIsNull  
	    * @Description: value 值是null的查询条件  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orIsNull(String column, String value) {
		Condition condition = this.addConditions(OR, column, value, IS_NULL);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addLessThanEqual  
	    * @Description: 小于等于某个条件    
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager addLessThanEqual(String column, String value) {
		Condition condition = this.addConditions(AND, column, value, LT_EQ);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: orLessThanEqual  
	    * @Description: 小于等于某个条件  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orLessThanEqual(String column, String value) {
		Condition condition = this.addConditions(OR, column, value, LT_EQ);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addGreaterThanEqual  
	    * @Description: 大于等于某个条件
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager addGreaterThanEqual(String column, String value) {
		Condition condition = this.addConditions(AND, column, value, GT_EQ);
		condition.setBase(true);
		return this;
	}
	
	/**
	 * 	或逻辑运算
	    * @Title: orGreaterThanEqual  
	    * @Description: 大于等于某个条件  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orGreaterThanEqual(String column, String value) {
		Condition condition = this.addConditions(OR, column, value, GT_EQ);
		condition.setBase(true);
		return this;
	}
	
	/**
	 * 	与逻辑运算
	    * @Title: addLessThan  
	    * @Description: 小于某个条件    
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter 
	    * @throws
	 */
	public ParameterManager addLessThan(String column, String value) {
		Condition condition = this.addConditions(AND, column, value, LT);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: orLessThan  
	    * @Description: 小于某个条件   
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orLessThan(String column, String value) {
		Condition condition = this.addConditions(OR, column, value, LT);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addGreaterThan  
	    * @Description: 大于某个条件  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager addGreaterThan(String column, String value) {
		Condition condition = this.addConditions(AND, column, value, GT);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: orGreaterThan  
	    * @Description: 大于某个条件  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orGreaterThan(String column, String value) {
		Condition condition = this.addConditions(OR, column, value, GT);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addEquals  
	    * @Description: 相等的条件  
	    * @param @param column
	    * @param @param value
	    * @return void
	    * @throws
	 */
	public ParameterManager addEquals(String column, String value) {
		Condition condition = this.addConditions(AND, column, value, EQ);
		condition.setBase(true);
		return this;
	}
	/**
	 * 	或逻辑运算
	    * @Title: orEquals  
	    * @Description: 相等的条件  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orEquals(String column, String value) {
		Condition condition = this.addConditions(OR, column, value, EQ);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  与逻辑运算
	    * @Title: addNotEquals  
	    * @Description: 不相等条件  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager addNotEquals(String column,String value) {
		Condition condition = this.addConditions(AND, column, value, NO_EQ);
		condition.setBase(true);
		return this;
	}
	
	/**
	 *  或逻辑运算
	    * @Title: orNotEquals  
	    * @Description: 不相等条件  
	    * @param @param column
	    * @param @param value
	    * @param @return
	    * @return MapperParameter
	    * @throws
	 */
	public ParameterManager orNotEquals(String column, String value) {
		Condition condition = this.addConditions(OR, column, value, NO_EQ);
		condition.setBase(true);
		return this;
	}
	/**
	 * 
	    * @Title: addConditions  
	    * @Description: 添加一个条件到参数中  
	    * @param @param condition
	    * @return void
	    * @throws
	 */
	public void addConditions(Condition condition) {
		conditions.add(condition);
	}
	
	/**
	 * 
	    * @Title: addConditions  
	    * @Description: 添加查询条件  
	    * @param @param column
	    * @param @param value
	    * @param @param symbol
	    * @return void
	    * @throws
	 */
	public Condition addConditions(String logical, String column,String value,String symbol) {
		Condition condition = getCondition(column,value);
		condition.setSymbol(symbol);
		condition.setLogical(logical);
		this.conditions.add(condition);
		return condition;
	}
	
	/**
	 * 
	    * @Title: getParameter  
	    * @Description: 查询条件的参数相关对象  
	    * @param @return
	    * @return Parameter
	    * @throws
	 */
	public Parameter getParameter() {
		return new Parameter(conditions, orderByList, getSort());
	}
	
	/**
	 * 	
	    * @Title: isValid  
	    * @Description: 是否有条件  如果条件集合中为空，则表示这个查询没有条件，也不会进行where语句拼接
	    * @param @return
	    * @return boolean
	    * @throws
	 */
	@SuppressWarnings("unused")
	private boolean isValid() {
		if(conditions.isEmpty()) {
			return false;
		}
		return true;
	}
	
	/******************get/set*******************/
	
	public List<Condition> getConditions() {
		return conditions;
	}

	public void setConditions(List<Condition> conditions) {
		this.conditions = conditions;
	}
	
	/**************以下是私有方法*****************/
	/**
	 * 
	    * @Title: getCondition  
	    * @Description: 获得  Condition对象
	    * @param @return
	    * @return Condition
	    * @throws
	 */
	private Condition getCondition(String column,String value) {
		return new Condition(column,value);
	}
}
