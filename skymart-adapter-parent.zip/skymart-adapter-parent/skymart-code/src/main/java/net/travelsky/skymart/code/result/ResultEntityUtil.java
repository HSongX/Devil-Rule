package net.travelsky.skymart.code.result;

import com.alibaba.fastjson.JSONObject;

import net.travelsky.skymart.code.enums.ResultCode;

/**
 *  返回结果的工具对象，用来创建返回结果对象
    * @ClassName: ResultEntityUtil  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月9日  
    *
 */
public class ResultEntityUtil {

	/**
	 *  获取返回消息对象
	    * @Title: getEntity  
	    * @Description: TODO  
	    * @param @param rsCode
	    * @param @param msg
	    * @param @param body
	    * @param @return
	    * @return ResultEntity
	    * @throws
	 */
	public static ResultEntity getEntity(ResultCode rsCode,Message msg,Object body) {
		ResultEntity rEntity = new ResultEntity();
		HeaderContent hc = new HeaderContent();
		hc.setStateCode(rsCode.getValue());
		if(msg != null) {
			hc.setMsg(msg);
		}
		rEntity.setHeader(hc);
		if(body == null) {
			BodyContent bc = new BodyContent();
			bc.setData(new JSONObject());
			rEntity.setBody(bc);
		}
		else {
			BodyContent bc = new BodyContent();
			bc.setData(body);
			rEntity.setBody(bc);
		}
		return rEntity;
	}
	
	/**
	 *  重载方法
	    * @Title: getEntity  
	    * @Description: TODO  
	    * @param @param rsCode
	    * @param @param msgCode
	    * @param @param msgText
	    * @param @param body
	    * @param @return
	    * @return ResultEntity
	    * @throws
	 */
	public static ResultEntity getEntity(ResultCode rsCode,String msgCode,String msgText,Object body) {
		Message message = new Message();
		message.setMsgCode(msgCode);
		message.setMsgText(msgText);
		return getEntity(rsCode,message,body);
	}
	
	/**
	 *  重载方法
	    * @Title: getEntity  
	    * @Description: TODO  
	    * @param @param rsCode
	    * @param @param msgCode
	    * @param @param msgText
	    * @param @param body
	    * @param @return
	    * @return ResultEntity
	    * @throws
	 */
	public static ResultEntity getEntity(ResultCode rsCode,String msgCode,String msgText) {
		Message message = new Message();
		message.setMsgCode(msgCode);
		message.setMsgText(msgText);
		return getEntity(rsCode,message,null);
	}
	
	/**
	 *  重载方法
	    * @Title: getEntity  
	    * @Description: TODO  
	    * @param @param rsCode
	    * @param @param msgCode
	    * @param @param msgText
	    * @param @param body
	    * @param @return
	    * @return ResultEntity
	    * @throws
	 */
	public static ResultEntity getEntity(ResultCode rsCode,Message msg) {
		return getEntity(rsCode,msg,null);
	}
	
	/**
	 *  重载方法
	    * @Title: getEntity  
	    * @Description: TODO  
	    * @param @param rsCode
	    * @param @param body
	    * @param @return
	    * @return ResultEntity
	    * @throws
	 */
	public static ResultEntity getEntity(ResultCode rsCode,Object body) {
		return getEntity(rsCode,null,body);
	}
	
}
