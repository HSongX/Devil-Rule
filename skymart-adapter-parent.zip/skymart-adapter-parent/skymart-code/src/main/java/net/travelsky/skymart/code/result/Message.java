package net.travelsky.skymart.code.result;


public class Message implements java.io.Serializable{
	
	private static final long serialVersionUID = -3245257684599613924L;

	/**
	 * 消息吗
	 */
	private String msgCode;
	
	/**
	 * 消息文本
	 */
	private String msgText;
	    
	public Message() {
		super();
	}

	public Message(String msgCode, String msgText) {
		super();
		this.msgCode = msgCode;
		this.msgText = msgText;
	}

	public String getMsgCode() {
		return msgCode;
	}

	public void setMsgCode(String msgCode) {
		this.msgCode = msgCode;
	}

	public String getMsgText() {
		return msgText;
	}

	public void setMsgText(String msgText) {
		this.msgText = msgText;
	}
	
	
}
