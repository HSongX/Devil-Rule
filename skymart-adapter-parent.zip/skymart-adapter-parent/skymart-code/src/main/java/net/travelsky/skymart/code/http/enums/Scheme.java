package net.travelsky.skymart.code.http.enums;

public enum Scheme {

    HTTP("http"),
    HTTPS("https");
    
    private String value;
    private Scheme(String value) {
        this.value = value;
    }
    public String getValue() {
        return this.value;
    }
   
}
