var common_js = [
	'    <script src="@{ctxPath}/static/assets/js/jquery.min.js"></script>',
	'    <script src="@{ctxPath}/static/assets/js/echarts.min.js"></script>',
	'    <script src="@{ctxPath}/static/assets/js/amazeui.min.js"></script>',
	'    <script src="@{ctxPath}/static/assets/js/iscroll.js"></script>',
	'    <script src="@{ctxPath}/static/assets/js/app.js"></script>'].join("");

document.write(common_js);