

var common_css = [
	' <link rel="icon" type="image/png" href="@{ctxPath}/static/assets/i/favicon.png"/>',
	' <link rel="apple-touch-icon-precomposed" href="@{ctxPath}/static/assets/i/app-icon72x72@2x.png"/>',
	' <link rel="stylesheet" href="@{ctxPath}/static/assets/css/amazeui.min.css" />',
	' <link rel="stylesheet" href="@{ctxPath}/static/assets/css/admin.css"/>',
	' <link rel="stylesheet" href="@{ctxPath}/static/assets/css/app.css"/>'].join("");
document.write(common_css);