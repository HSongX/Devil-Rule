$(function(){
	var setting = {
			data: {
				simpleData: {
					enable: true
				}
			},
			callback: {
				onClick: onClick
			}
		};

	/**
	 * 加载数据库中的表
	 */
	$("#loadTables").click(function(){
		// 得到树形的AJAX数据
		$.ajax({
			url:'tables',
			type:'post',
			success:function(zNodes){
				$.fn.zTree.init($("#tablesTree"), setting, zNodes);
			}
		});
	})
	
	/**
	 * 生成的按钮
	 */
	$("#generate_btn").click(function(){
		alertLoading("正在生成代码文件....");
		// 得到db相关的配置信息
		var dbName = $("#db_name").val();
		var tableName = $("#table_name").val();
		// 生成的配置信息
		var className = $("#class_name").val();
		var pojoPackageName = $("#pojoPackageName").val();
		var mapperPackageName = $("#mapperPackageName").val();
		var filePath = $("#filePath").val();
		var chk_xml = $("#chk_xml").is(":checked") ? true : false;
		var chk_mapper = $("#chk_mapper").is(":checked") ? true : false;
		var chk_pojo = $("#chk_pojo").is(":checked") ? true : false;
		var dbPojo = new DBPojo(dbName,tableName);
		var tplselect = new TemplateSelector(chk_mapper,chk_xml,chk_pojo);
		// 组装对象
		var pojo = new MapperPojo(className,pojoPackageName,mapperPackageName,filePath,dbPojo,tplselect);
		var param = JSON.stringify(pojo);
		// 发起请求，开始生成
		$.ajax({
			url:'generate',
			data:param,
			type:'POST',
			dataType:'json',
			contentType: "application/json; charset=utf-8",
			success:function(data){
				loadingClose();
				if(data == "200"){
					alertDialog('','生成成功');
				}else{
					alertDialog('','生成失败');
				}
			}
		});
		
	})

})

function validate(){
	
}

function DBPojo(dbName,tableName){
	this.dbName = dbName;
	this.tableName = tableName;
}

function TemplateSelector(isMapper,isMappingXML,isPojo,isOracle,isMySql){
	this.isMapper=isMapper;
	this.isMappingXML=isMappingXML;
	this.isPojo=isPojo;
	this.isOracle=isOracle;
	this.isMySql=isMySql;
}

function MapperPojo(className,pojoPackageName,mapperPackageName,filePath,dbPojo,tplselect){
	this.className = className;
	this.pojoPackageName = pojoPackageName;
	this.mapperPackageName = mapperPackageName;
	this.filePath = filePath;
	this.dbPojo = dbPojo;
	this.tplselect = tplselect;
}

/**
 * 左侧树形，处理点击的表名的字符串处理
 * @param event
 * @param treeId
 * @param treeNode
 * @param clickFlag
 * @returns
 */
function onClick(event, treeId, treeNode, clickFlag) {
	
	if(treeNode.id == 0){
		return;
	}
	$("#table_name").val(treeNode.name);
	var tName = treeNode.name.toLowerCase();
	var _index = tName.indexOf('_');
	var name = "";
	if(_index != -1){
		tName = tName.split("_");
		for(var n=0;n<tName.length;n++){
			name +=  tName[n].substring(0,1).toUpperCase() 
			+ tName[n].substring(1,tName[n].length) ;
		}

	}else{
		name = tName.substring(0,1).toUpperCase() + tName.substring(1,tName.length)
	}
	
	$("#class_name").val(name);
}	
