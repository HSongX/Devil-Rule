function alertDialog(title,msg,callback){
	
	var alertHtml = ['<div class="am-modal am-modal-alert" tabindex="-1" id="my-alert">',
		'  <div class="am-modal-dialog">',
		'    <div class="am-modal-hd">'+title+'</div>',
		'    <div class="am-modal-bd">',
		'      '+msg+'',
		'    </div>',
		'    <div class="am-modal-footer">',
		'      <span class="am-modal-btn">确定</span>',
		'    </div>',
		'  </div>',
		'</div>'].join("");
	var elem = $(alertHtml);
	$('#my-alert').remove();
	$('body').append($(elem).clone()); 
	
	$('#my-alert').on('closed.modal.amui',function(){
		if(typeof callback == 'function'){
			callback();
		}
	}).modal()

}

function loadingClose(){
	$("#my-modal-loading").modal('close');
}

function alertLoading(content){
	var loadHtml = ['<div class="am-modal am-modal-loading am-modal-no-btn" tabindex="-1" id="my-modal-loading">',
		'  <div class="am-modal-dialog">',
		'    <div class="am-modal-hd">'+content+'</div>',
		'    <div class="am-modal-bd">',
		'      <span class="am-icon-spinner am-icon-spin"></span>',
		'    </div>',
		'  </div>',
		'</div>'].join("");
	
	var elem = $(loadHtml);
	$('#my-modal-loading').remove();
	$('body').append($(elem).clone()); 
	$("#my-modal-loading").modal();
}