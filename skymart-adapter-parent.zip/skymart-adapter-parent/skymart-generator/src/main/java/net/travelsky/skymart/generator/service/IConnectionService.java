package net.travelsky.skymart.generator.service;

/**
 *  DB连接相关的操作类，用来完成数据库连接，读写相关数据库连接的相关可配置属性
    * @ClassName: IConnectionService  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月6日  
    *
 */
public interface IConnectionService {

	/**
	 *  检查数据连接是否成功，通过JDBC方式
	    * @Title: checkConnection  
	    * @Description: TODO  
	    * @param @return
	    * @return boolean
	    * @throws
	 */
	boolean checkConnection();
	
}
