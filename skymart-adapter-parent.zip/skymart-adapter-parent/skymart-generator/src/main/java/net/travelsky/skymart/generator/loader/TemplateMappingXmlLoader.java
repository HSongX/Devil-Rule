package net.travelsky.skymart.generator.loader;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.beetl.core.GroupTemplate;
import org.beetl.core.Template;
import net.travelsky.skymart.generator.loader.interfaces.ITemplageLoader;
import net.travelsky.skymart.generator.pojo.MapperPojo;


/**
 *  加载xml的模板
    * @ClassName: TemplagePojoLoader  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月3日  
    *
 */
public class TemplateMappingXmlLoader implements ITemplageLoader{

	/**
	 * 加载MapperXML模板，并且返回模板对象
	 */
	@Override
	public Template loader(GroupTemplate gt, MapperPojo pojo) {
		Map<String, Object> vars = new HashMap<String, Object>();
		vars.put("className", pojo.getClassName());
		vars.put("createDate", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		vars.put("columns", pojo.getColumns());
		vars.put("tableName", pojo.getDbPojo().getTableName());
		vars.put("pojoPackageName", pojo.getPojoPackageName());
		vars.put("mapperPackageName", pojo.getMapperPackageName());
		gt.setSharedVars(vars);
		Template t = gt.getTemplate(DEFAULT_MAPPING_XML);
		return t;
	}
	
}
