package net.travelsky.skymart.generator.pojo;

import lombok.Data;

@Data
public class ColumnPojo {
	
	/**
	 * 列名
	 */
	private String columnName;
	/**
	 * 列的描述信息
	 */
	private String columnComment;
	/**
	 * 转换后的属性
	 */
	private String propertyName;
	/**
	 * 转换后属性的类型
	 */
	private String propertyType;
	/**
	 * jdbc类型
	 */
	private String jdbcType;
	/**
	 * resultMap
	 */
	private String result;
	/**
	 * insert
	 */
	private String insert;
	/**
	 * update
	 */
	private String update;
}
