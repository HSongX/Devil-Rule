package net.travelsky.skymart.generator.pojo.entity;

import lombok.Data;

@Data
public class ColumnEntity {
	
	/**
	 * 列名
	 */
	private String columnName;
	/**
	 * 列类型
	 */
	private String columnType;
	/**
	 * 列备注
	 */
	private String comments;
	
}
