package net.travelsky.skymart.generator.service;

import java.util.List;

import net.travelsky.skymart.generator.pojo.ZtreeEntity;


/**
 *  ztree 加载数据库中的所有的表格，组成tree 格式文件
    * @ClassName: IZtreeTableService  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月7日  
    *
 */
public interface IZtreeTableService {

	/**
	 *  获得系统中当前数据库所有的表，返回树形结构集合
	    * @Title: getTables  
	    * @Description: TODO  
	    * @param @return
	    * @return List<ZtreeEntity>
	    * @throws
	 */
	public List<ZtreeEntity> getTables();
}
