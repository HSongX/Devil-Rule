package net.travelsky.skymart.generator.pojo;
import lombok.Data;
import lombok.ToString;

/**
 * 
    * @ClassName: ZtreeEntity  
    * @Description: js 控件  ztree 的数据展示实体对象  
    * @author CY  
    * @date 2018年8月1日  
    *
 */
@Data
@ToString
public class ZtreeEntity {

	private String id;
	private String name;
	private String url;
	private String title;
	private boolean open;
	private String pId;
	private String icon;
	
}
