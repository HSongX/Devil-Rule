package net.travelsky.skymart.generator.service;

import net.travelsky.skymart.generator.pojo.MapperPojo;

/**
 *  自动生成相关代码的业务逻辑类
    * @ClassName: IDBManagerService  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月2日  
    *
 */
public interface IAutoCodeService {
	
	/**
	 *  需要的相关属性设置
	    * @Title: setpMapperPojo  
	    * @Description: 包含了数据库的信息，要生成的属性，表，等  
	    * @param @param pMapperPojo
	    * @return void
	    * @throws
	 */
	void setpMapperPojo(MapperPojo pMapperPojo);
	
	/**
	 *  自动生成mapper类文件
	    * @Title: generateMapper  
	    * @Description: TODO  
	    * @param @param pojo
	    * @return void
	    * @throws
	 */
	void generateMapper(); 
	
	/**
	 *  自动生成实体类文件
	    * @Title: generatePojo  
	    * @Description: TODO  
	    * @param @param tableName
	    * @param @param pojo
	    * @return void
	    * @throws
	 */
	void generatePojo();
	
	/**
	 *  自动生成mapping.xml文件
	    * @Title: generateMappingXML  
	    * @Description: TODO  
	    * @param @param dbName
	    * @param @param tableName
	    * @param @param pojo
	    * @return void
	    * @throws
	 */
	void generateMappingXML();

}
