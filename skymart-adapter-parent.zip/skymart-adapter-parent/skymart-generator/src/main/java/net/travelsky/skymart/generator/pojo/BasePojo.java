package net.travelsky.skymart.generator.pojo;

import lombok.Data;

@Data
public class BasePojo {
	private String filePath;
}
