package net.travelsky.skymart.generator.enums;

public enum GeneratorType {

	VIEW_ADD("VIEW_ADD"),
	VIEW_EDIT("VIEW_EDIT"),
	VIEW_LIST("VIEW_LIST"),
	CLASS_CONTROLLER("CLASS_CONTROLLER"),
	CLASS_POJO("CLASS_POJO"),
	CLASS_SERVICE("CLASS_SERVICE"),
	CLASS_MAPPER("CLASS_MAPPER"),
	XML_MAPPING("XML_MAPPING");
		
	GeneratorType(String type) {
		this.type = type;
	}

	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
}
