package net.travelsky.skymart.generator.enums;

public interface DB {

	final static String DB_NAME = "test";
	
}
