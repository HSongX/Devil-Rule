package net.travelsky.skymart.generator.factory;

import lombok.Data;

/**
 *  模板生成选择器，用来选择生成的模板类型
    * @ClassName: TemplateSelector  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月2日  
    *
 */
@Data
public class TemplateSelector {
	
	/**
	 * 是否生成视图
	 */
	private boolean isView;
	/**
	 * 是否生成mybatis映射类
	 */
	private boolean isMapper;
	/**
	 * 是否生成映射XML文件
	 */
	private boolean isMappingXML;
	/**
	 * 是否生成控制器
	 */
	private boolean isController;
	/**
	 * 是否生成业务类接口
	 */
	private boolean isService;
	/**
	 * 是否生成实体对象
	 */
	private boolean isPojo;
	/**
	 * 是否生成Oracle
	 */
	private boolean isOracle;
	/**
	 * 是否生成MySQl
	 */
	private boolean isMySql;
	
	public TemplateSelector() {
		this.isView = false;
		this.isMapper = false;
		this.isMappingXML = false;
		this.isController = false;
		this.isService = false;
		this.isPojo = false;
		this.isOracle = false;
		this.isMySql = false;
	}
}
