package net.travelsky.skymart.generator.loader.interfaces;

import org.beetl.core.GroupTemplate;
import org.beetl.core.Template;
import net.travelsky.skymart.generator.pojo.MapperPojo;

/**
 *  模板加载的接口
    * @ClassName: ITemplageLoader  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月3日  
    *
 */
public interface ITemplageLoader {
	/**
	 * 模板加载的路径和名称
	 */
	public static final String DEFAULT_VIEW_ADD = "default_add_template.html";
	
	public static final String DEFAULT_VIEW_EDIT = "default_edit_template.html";
	
	public static final String DEFAULT_VIEW_LIST = "default_list_template.html";
	
	public static final String DEFAULT_CONTROLLER = "default_controller_template.html";
	
	public static final String DEFAULT_MAPPER = "default_mapper_template.html";
	
	public static final String DEFAULT_MAPPING_XML = "default_mapping_template.html";
	
	public static final String DEFAULT_SERVICE = "default_service_template.html";
	
	public static final String DEFAULT_POJO = "default_pojo_template.html"; 
	/**
	 *  加载模板
	    * @Title: loader  
	    * @Description: TODO  
	    * @param @param pojo
	    * @param @return
	    * @return Template
	    * @throws
	 */
	public Template loader(GroupTemplate gt, MapperPojo pojo);
}
