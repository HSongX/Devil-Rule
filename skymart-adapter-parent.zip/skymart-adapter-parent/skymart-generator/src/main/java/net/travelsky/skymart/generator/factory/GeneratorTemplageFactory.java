package net.travelsky.skymart.generator.factory;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.beetl.core.Template;
import org.beetl.core.exception.BeetlException;
import net.travelsky.skymart.generator.enums.GeneratorType;
import net.travelsky.skymart.generator.loader.TemplateMapperLoader;
import net.travelsky.skymart.generator.loader.TemplateMappingXmlLoader;
import net.travelsky.skymart.generator.loader.TemplatePojoLoader;
import net.travelsky.skymart.generator.pojo.MapperPojo;
import net.travelsky.skymart.generator.util.FileUtils;
import org.springframework.stereotype.Component;

/**
 *  模板生成的父类
    * @ClassName: BaseGenerator  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月2日  
    *
 */
@Component
public class GeneratorTemplageFactory {
	
	/**
	 * 模板生成选择器
	 */
	private TemplateSelector selector = new TemplateSelector();

	/**
	 * 	生成模板
	    * @Title: transferFile  
	    * @Description: TODO  
	    * @param 
	    * @return void
	    * @throws
	 */
	public void transferFile(MapperPojo pojo) {
		
		/**
		 * 生成mapper模板
		 */
		if(selector.isMapper()) {
			Template template = new TemplateFactory(pojo).productionTemplage(new TemplateMapperLoader());
			try {
				File file = new File(FileUtils.mapperFilePageName(
						pojo.getFilePath(), 
						pojo.getClassName(), 
						GeneratorType.CLASS_MAPPER));
				template.renderTo(new FileOutputStream(file));
			} catch (BeetlException | FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		if(selector.isPojo()) {
			Template template = new TemplateFactory(pojo).productionTemplage(new TemplatePojoLoader());
			try {
				File file = new File(FileUtils.mapperFilePageName(
						pojo.getFilePath(), 
						pojo.getClassName(), 
						GeneratorType.CLASS_POJO));
				template.renderTo(new FileOutputStream(file));
			} catch (BeetlException | FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		if(selector.isMappingXML()) {
			Template template = new TemplateFactory(pojo).productionTemplage(new TemplateMappingXmlLoader());
			try {
				File file = new File(FileUtils.mapperFilePageName(
						pojo.getFilePath(), 
						pojo.getClassName(), 
						GeneratorType.XML_MAPPING));
				template.renderTo(new FileOutputStream(file));
			} catch (BeetlException | FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		
	}


	public TemplateSelector getSelector() {
		return selector;
	}
	
	public void setSelector(TemplateSelector selector) {
		this.selector = selector;
	}
	
	
	
}
