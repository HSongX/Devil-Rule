package net.travelsky.skymart.generator.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class DBPojo extends BasePojo{
	/**
	 * 数据库名称
	 */
	private String dbName;
	/**
	 * 表名称
	 */
	private String tableName;
}
