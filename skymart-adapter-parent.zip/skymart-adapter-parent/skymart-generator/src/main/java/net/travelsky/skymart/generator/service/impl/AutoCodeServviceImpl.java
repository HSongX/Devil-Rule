package net.travelsky.skymart.generator.service.impl;

import java.util.List;
import net.travelsky.skymart.generator.factory.GeneratorTemplageFactory;
import net.travelsky.skymart.generator.factory.TemplateSelector;
import net.travelsky.skymart.generator.pojo.MapperPojo;
import net.travelsky.skymart.generator.pojo.entity.ColumnEntity;
import net.travelsky.skymart.generator.repository.OracleDBManagerMapper;
import net.travelsky.skymart.generator.service.IAutoCodeService;
import net.travelsky.skymart.generator.util.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 *  系统自动生成相关的业务对象
    * @ClassName: AutoCodeServviceImpl  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月2日  
    *
 */
@Service
public class AutoCodeServviceImpl implements IAutoCodeService{

	/**
	 * 注入自动生成的工具类对象
	 */
	@Autowired GeneratorTemplageFactory gt;

	
	/**
	 * 获得oracle数据库操作得Mapper
	 */
	@Autowired OracleDBManagerMapper odbMapper;
	
	/**
	 * 
	 */
	MapperPojo pMapperPojo = null;
	
	public void setpMapperPojo(MapperPojo pMapperPojo) {
		this.pMapperPojo = pMapperPojo;
	}

	@Override
	public void generateMapper() {
		/**
		 * 创建模板选择器对象，
		 */
		TemplateSelector ts = gt.getSelector();
		ts.setMapper(true);
		gt.transferFile(pMapperPojo);
	}

	@Override
	public void generatePojo() {
		/**
		 * 获取当前表下所有的列信息
		 */
		List<ColumnEntity> columns = odbMapper.getColumnsByTable(pMapperPojo.getDbPojo().getTableName());		
		/**
		 * 转换列的类型
		 */
		pMapperPojo.setColumns(FileUtils.columnTransformationProperty(columns));
		TemplateSelector ts = gt.getSelector();
		ts.setPojo(true);
		gt.transferFile(pMapperPojo);
	}

	@Override
	public void generateMappingXML() {
		/**
		 * 获取当前表下所有的列信息
		 */
		List<ColumnEntity> columns = odbMapper.getColumnsByTable(pMapperPojo.getDbPojo().getTableName());
		/**
		 * 转换列的类型
		 */
		pMapperPojo.setColumns(FileUtils.columnTransformationProperty(columns));
		TemplateSelector ts = gt.getSelector();
		ts.setMappingXML(true);
		gt.transferFile(pMapperPojo);
	}

}
