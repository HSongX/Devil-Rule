package net.travelsky.skymart.generator.factory;

import java.io.IOException;

import org.beetl.core.Configuration;
import org.beetl.core.GroupTemplate;
import org.beetl.core.Template;
import org.beetl.core.resource.WebAppResourceLoader;
import net.travelsky.skymart.generator.loader.interfaces.ITemplageLoader;
import net.travelsky.skymart.generator.pojo.MapperPojo;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternUtils;

/**
 *  生成模板的工厂类
    * @ClassName: TemplageFactory  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月3日  
    *
 */
public class TemplateFactory {
	
	private MapperPojo mPojo;
	
	private static GroupTemplate gt;
	
	/**
	 * 静态加载模板配置对象
	 */
	static {
		
		ResourcePatternResolver patternResolver = ResourcePatternUtils.getResourcePatternResolver(new DefaultResourceLoader());
		WebAppResourceLoader resourceLoader = null;
		// 加载resource目录下的模板文件
		//ClasspathResourceLoader resourceLoader = new ClasspathResourceLoader("/templages");
		Configuration cfg = null;
		try {
			resourceLoader = new WebAppResourceLoader(
					patternResolver.getResource("classpath:/net/travelsky/skymart/generator/templates").getFile().getPath());
			cfg = Configuration.defaultConfiguration();
		} catch (IOException e) {
			e.printStackTrace();
		}
		gt = new GroupTemplate(resourceLoader, cfg);
	}
	
	public TemplateFactory(MapperPojo mPojo) {
		super();
		this.mPojo = mPojo;
	}

	/**
	 *  生产一个模板对象
	    * @Title: createTemplage  
	    * @Description: TODO  
	    * @param @param iTemplageLoader
	    * @param @return
	    * @return Template
	    * @throws
	 */
	public Template productionTemplage(ITemplageLoader iTemplageLoader) {
		return iTemplageLoader.loader(gt,mPojo);
	}
	
}
