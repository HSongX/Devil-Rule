package net.travelsky.skymart.generator.pojo;

import java.util.ArrayList;
import java.util.List;

import net.travelsky.skymart.generator.factory.TemplateSelector;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *  模板写入的 Mapper 类文件相关需要的参数
    * @ClassName: MapperPojo  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月2日  
    *
 */
@Data
@EqualsAndHashCode(callSuper=true)
public class MapperPojo extends BasePojo{
	/**
	 * 类名称
	 */
	private String className;
	/**
	 * 实体类包路径
	 */
	private String pojoPackageName;
	/**
	 * mapper文件路径
	 */
	private String mapperPackageName;
	/**
	 * DB信息对象
	 */
	private DBPojo dbPojo;
	/**
	 * 选择生成的文件类型
	 */
	private TemplateSelector tplselect;
	/**
	 * 列的集合对象，包含了列名与类型
	 */
	private List<ColumnPojo> columns = new ArrayList<>();
	
}
