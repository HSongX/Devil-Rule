package net.travelsky.skymart.generator.service.impl;

import net.travelsky.skymart.generator.service.IConnectionService;

public class ConnectionServiceImpl implements IConnectionService{
	
	@Override
	public boolean checkConnection() {
			
		return false;
	}

}
