package net.travelsky.skymart.generator.util;

import java.util.ArrayList;
import java.util.List;
import net.travelsky.skymart.generator.enums.GeneratorType;
import net.travelsky.skymart.generator.pojo.ColumnPojo;
import net.travelsky.skymart.generator.pojo.entity.ColumnEntity;
public class FileUtils {

	/**
	 *  生成相关文件名称
	    * @Title: mapperFileName  
	    * @Description: TODO  
	    * @param @param className
	    * @param @return
	    * @return String
	    * @throws
	 */
	public static String mapperFilePageName(String filePath,String className,GeneratorType gType) {
		StringBuilder sBuilder = new StringBuilder(filePath);
		/**
		 * 根据生成的类型，返回相应的文件路径
		 */
		if(gType == GeneratorType.CLASS_MAPPER) {
			sBuilder.append(className);
			sBuilder.append("Mapper");
			sBuilder.append(".java");
			return sBuilder.toString();
		}
		if(gType == GeneratorType.XML_MAPPING) {
			sBuilder.append(className);
			sBuilder.append("Mapper");
			sBuilder.append(".xml");
			return sBuilder.toString();
		}
		if(gType == GeneratorType.CLASS_POJO) {
			sBuilder.append(className);
			sBuilder.append("Entity");
			sBuilder.append(".java");
			return sBuilder.toString();
		}
		return null;
	}
	
	/**
	 *  列转换为实体对象，以及相关属性
	    * @Title: columnTransformationProperty  
	    * @Description: TODO  
	    * @param @param cPojos
	    * @param @return
	    * @return List<ColumnPojo>
	    * @throws
	 */
	public static List<ColumnPojo> columnTransformationProperty(List<ColumnEntity> tList){
		List<ColumnPojo> cList = new ArrayList<ColumnPojo>();
		/**
		 * 转换列的类型
		 */
		for(ColumnEntity column : tList) {
			ColumnPojo columnPojo = new ColumnPojo();
			columnPojo.setColumnName(column.getColumnName().toLowerCase());
			/**
			 * 列名转换属性
			 */
			columnPojo.setPropertyName(columnTransfoProperty(column.getColumnName()));
			// 判定表类型
			if(column.getColumnType().equals("NUMBER")) {
				columnPojo.setJdbcType("DECIMAL");
				columnPojo.setPropertyType("BigDecimal");
				columnPojo.setResult(columnTransfoResult(columnPojo));
				columnPojo.setInsert(columnTransfoInsert(columnPojo));
				columnPojo.setUpdate(columnTransfoUpdate(columnPojo));
			}
			else if(column.getColumnType().equals("VARCHAR2")) {
				columnPojo.setJdbcType("VARCHAR");
				columnPojo.setPropertyType("String");
				columnPojo.setResult(columnTransfoResult(columnPojo));
				columnPojo.setInsert(columnTransfoInsert(columnPojo));
				columnPojo.setUpdate(columnTransfoUpdate(columnPojo));
			}
//			else if(column.getColumnType().equals("double")) {
//				columnPojo.setJdbcType("DOUBLE");
//				columnPojo.setPropertyType("Double");
//				columnPojo.setResult(columnTransfoResult(columnPojo));
//				columnPojo.setInsert(columnTransfoInsert(columnPojo));
//				columnPojo.setUpdate(columnTransfoUpdate(columnPojo));
//			}
//			else if(column.getColumnType().equals("text")) {
//				columnPojo.setJdbcType("VARCHAR");
//				columnPojo.setPropertyType("String");
//				columnPojo.setResult(columnTransfoResult(columnPojo));
//				columnPojo.setInsert(columnTransfoInsert(columnPojo));
//				columnPojo.setUpdate(columnTransfoUpdate(columnPojo));
//			}
			else if(column.getColumnType().equals("DATE")) {
				columnPojo.setJdbcType("DATE");
				columnPojo.setPropertyType("Date");
				columnPojo.setResult(columnTransfoResult(columnPojo));
				columnPojo.setInsert(columnTransfoInsert(columnPojo));
				columnPojo.setUpdate(columnTransfoUpdate(columnPojo));
			}
//			else if(column.getColumnType().equals("decimal")) {
//				columnPojo.setJdbcType("DECIMAL");
//				columnPojo.setPropertyType("BigDecimal");
//				columnPojo.setResult(columnTransfoResult(columnPojo));
//				columnPojo.setInsert(columnTransfoInsert(columnPojo));
//			}
			else {
				columnPojo.setJdbcType("VARCHAR");
				columnPojo.setPropertyType("String");
				columnPojo.setResult(columnTransfoResult(columnPojo));
				columnPojo.setInsert(columnTransfoInsert(columnPojo));
				columnPojo.setUpdate(columnTransfoUpdate(columnPojo));
			}
			cList.add(columnPojo);
		}
		return cList;
	}
	
	/**
	 *  将查询到的数据库的列，转换为属性需要的格式，去掉_等特殊字符
	    * @Title: columnTransfoProperty  
	    * @Description: TODO  
	    * @param @param column
	    * @param @return
	    * @return String
	    * @throws
	 */
	private static String columnTransfoProperty(String column) {
		String col = column.toLowerCase();
		col = col.replace("_", "");
		return col;
	}
	
	/**
	 *  转换result列
	    * @Title: columnTransfoResult  
	    * @Description: TODO  
	    * @param @param pojo
	    * @param @return
	    * @return String
	    * @throws
	 */
	private static String columnTransfoResult(ColumnPojo pojo) {
		StringBuilder result = new StringBuilder();
		result
		.append("<result ")
		.append("column=\"")
		.append(pojo.getColumnName())
		.append("\" ")
		.append("property=\"")
		.append(pojo.getPropertyName())
		.append("\" ")
		.append("jdbcType=\"")
		.append(pojo.getJdbcType())
		.append("\" ")
		.append("/>");
		return result.toString();
	}
	
	/**
	 *  生成insert 相关的标签
	    * @Title: columnTransfoInsert  
	    * @Description: TODO  
	    * @param @param pojo
	    * @param @return
	    * @return String
	    * @throws
	 */
	private static String columnTransfoInsert(ColumnPojo pojo) {
		StringBuilder insert = new StringBuilder();
		insert
		.append("<if test=\"")
		.append(pojo.getPropertyName())
		.append("!=null \">")
		.append("#{").append(pojo.getPropertyName()).append("},")
		.append("</if>");
		return insert.toString();
	}
	
	/**
	 *  生成update 相关标签
	    * @Title: columnTransfoUpdate  
	    * @Description: TODO  
	    * @param @param pojo
	    * @param @return
	    * @return String
	    * @throws
	 */
	private static String columnTransfoUpdate(ColumnPojo pojo) {
		StringBuilder insert = new StringBuilder();
		insert
		.append("<if test=\"")
		.append(pojo.getPropertyName())
		.append("!=null\">")
		.append(pojo.getColumnName()).append("=")
		.append("#{").append(pojo.getPropertyName()).append("},")
		.append("</if>");
		return insert.toString();
	}
}
