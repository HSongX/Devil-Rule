package net.travelsky.skymart.generator.controller.web;

import net.travelsky.skymart.generator.pojo.DBPojo;
import net.travelsky.skymart.generator.pojo.MapperPojo;
import net.travelsky.skymart.generator.service.IAutoCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mysql")
public class TestController {

	@Autowired private IAutoCodeService iacs;
	
	@RequestMapping("/link")
	public String link() {
		
		MapperPojo pojo = new MapperPojo();
		pojo.setClassName("Employee");
		pojo.setFilePath("D:/");
		pojo.setPojoPackageName("org.nick.business.employee.pojo");
		pojo.setMapperPackageName("org.nick.business.employee.repository");
		pojo.setDbPojo(new DBPojo("test", "EMPLOYEEUSER"));
		iacs.setpMapperPojo(pojo);
		iacs.generatePojo();
		iacs.generateMapper();
		iacs.generateMappingXML();
		
		return "OK";
	}
}
