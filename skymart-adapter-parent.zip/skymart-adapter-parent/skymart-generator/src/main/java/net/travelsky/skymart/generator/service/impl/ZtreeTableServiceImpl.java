package net.travelsky.skymart.generator.service.impl;

import java.util.ArrayList;
import java.util.List;

import net.travelsky.skymart.generator.pojo.ZtreeEntity;
import net.travelsky.skymart.generator.repository.MySqlDBManagerMapper;
import net.travelsky.skymart.generator.repository.OracleDBManagerMapper;
import net.travelsky.skymart.generator.service.IZtreeTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ZtreeTableServiceImpl implements IZtreeTableService{

	@Autowired MySqlDBManagerMapper mdbManagerMapper;
	
	@Autowired OracleDBManagerMapper odbManagerMapper;
	
	@Override
	public List<ZtreeEntity> getTables() {
		ZtreeEntity ztreeEntity = new ZtreeEntity();
		ztreeEntity.setId("0");
		ztreeEntity.setName("列表");
		ztreeEntity.setOpen(true);
		ztreeEntity.setPId("-1");
		List<ZtreeEntity> ztreeList = new ArrayList<>();
		ztreeList.add(ztreeEntity);
		List<String> sList = odbManagerMapper.getTables();
		
		int index = 1;
		for(String tName : sList) {
			ztreeEntity = new ZtreeEntity();
			ztreeEntity.setId(String.valueOf(index));
			ztreeEntity.setName(tName);
			ztreeEntity.setOpen(true);
			ztreeEntity.setPId("0");
			ztreeList.add(ztreeEntity);
			index ++ ;
		}
		return ztreeList;
	}
	
}
