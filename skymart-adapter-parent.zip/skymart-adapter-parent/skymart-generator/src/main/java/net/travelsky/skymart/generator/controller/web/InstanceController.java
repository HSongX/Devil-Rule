package net.travelsky.skymart.generator.controller.web;

import java.util.List;
import net.travelsky.skymart.generator.pojo.ZtreeEntity;
import net.travelsky.skymart.generator.pojo.MapperPojo;
import net.travelsky.skymart.generator.service.IAutoCodeService;
import net.travelsky.skymart.generator.service.IZtreeTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *  初始化的控制器
    * @ClassName: InstanceController  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月6日  
    *
 */
@RestController
@RequestMapping("/mysql")
public class InstanceController {

	@Autowired private IZtreeTableService iztreeService;
	
	@Autowired private IAutoCodeService iacs;
	
	/**
	 *  ajax加载表列表,返回JSON数据
	    * @Title: instance  
	    * @Description: TODO  
	    * @param @return
	    * @return String
	    * @throws
	 */
	@PostMapping(value = "/tables", produces = "application/json;charset=utf-8")
	public List<ZtreeEntity> instance() {
		// 加载当前DB的所有表数据
		List<ZtreeEntity> ztreeList = iztreeService.getTables();

		return ztreeList;
	}

	/**
	 *  开始生成
	    * @Title: generate  
	    * @Description: TODO  
	    * @param @param pojo
	    * @param @return
	    * @return String
	    * @throws
	 */
	@PostMapping(value = "/generate", produces = "application/json;charset=utf-8")
	public String generate(@RequestBody MapperPojo pojo) {
		try {
			iacs.setpMapperPojo(pojo);
			if(pojo.getTplselect().isMapper()) {
				iacs.generateMapper();
			}
			if(pojo.getTplselect().isMappingXML()) {
				iacs.generateMappingXML();
			}
			if(pojo.getTplselect().isPojo()) {
				iacs.generatePojo();
			}	
		}catch (Exception e) {
			e.printStackTrace();
			return "404";
		}
		return "200";
	}
}
