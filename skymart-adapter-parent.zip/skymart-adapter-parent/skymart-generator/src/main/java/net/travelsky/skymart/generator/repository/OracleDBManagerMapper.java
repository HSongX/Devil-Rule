package net.travelsky.skymart.generator.repository;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import net.travelsky.skymart.generator.pojo.entity.ColumnEntity;

public interface OracleDBManagerMapper {
	/**
	 *  根据表名，获取当前表的所有列名，以及列的类型
	    * @Title: getColumnsByTable  
	    * @Description: TODO  
	    * @param @param tableName
	    * @param @return
	    * @return List<TableEntity>
	    * @throws
	 */
	List<ColumnEntity> getColumnsByTable(@Param("tableName") String tableName);
	
	/**
	 *  获取系统数据库的所有表名集合，并且返回
	    * @Title: getTables  
	    * @Description: TODO  
	    * @param @return
	    * @return List<String>
	    * @throws
	 */
	List<String> getTables();
	

}
