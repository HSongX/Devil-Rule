package net.travelsky.skymart.generator.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 
    * @ClassName: ViewControllerConfig  
    * @Description: 用来处理view视图的请求默认路径  ，根路径跳转的画面
    * @author CY  
    * @date 2018年7月24日  
    *
 */
@Configuration
public class BaseViewConfig implements WebMvcConfigurer{

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		/**
		 * 设置默认，跟目录跳转的画面
		 */
		registry
			.addViewController("/").setViewName("redirect:/mysql/index");
		registry.setOrder(Ordered.HIGHEST_PRECEDENCE);	
		WebMvcConfigurer.super.addViewControllers(registry);
	}

}
