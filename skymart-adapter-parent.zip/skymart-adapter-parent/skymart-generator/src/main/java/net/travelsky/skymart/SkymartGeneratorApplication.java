package net.travelsky.skymart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 *  springboot 系统启动类，可作为tomcat  编译war包
    * @ClassName: NickGeneratorApplication  
    * @Description: TODO  
    * @author CY  
    * @date 2018年8月3日  
    *
 */
@SpringBootApplication
public class SkymartGeneratorApplication  extends SpringBootServletInitializer{
    public static void main(String[] args) {
    	SpringApplication.run(SkymartGeneratorApplication.class, args);
    }
    
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
	    return builder.sources(this.getClass());
	}
}
