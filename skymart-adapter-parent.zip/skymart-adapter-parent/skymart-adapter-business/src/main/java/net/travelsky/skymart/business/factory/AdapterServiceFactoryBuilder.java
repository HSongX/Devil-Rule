  
 
package net.travelsky.skymart.business.factory;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import net.travelsky.skymart.business.BaseValid;
import net.travelsky.skymart.business.IBaseService;
import net.travelsky.skymart.business.message.MessageCode;
import net.travelsky.skymart.code.enums.ResultCode;
import net.travelsky.skymart.code.result.ResultEntity;
import net.travelsky.skymart.code.result.ResultEntityUtil;
import net.travelsky.skymart.pojo.BaseParameter;
import net.travelsky.skymart.pojo.enums.Action;
import net.travelsky.skymart.pojo.param.CommonEntity;
import net.travelsky.skymart.tools.TMThirdDes;

/**
 *  业务工程构建着
    * @ClassName: ServiceFactoryBuilder  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
@Slf4j
@Component
public class AdapterServiceFactoryBuilder implements ApplicationContextAware{
	
	private ApplicationContext context;
	
	/** 业务逻辑接口 */
	private IBaseService ibs;
	/** 统一参数对象 （包含用户等信息）*/
	private CommonEntity commonEntity;
	/** 统一航班查询相关的参数JSON对象，解密后 */
	private String data;
	/** 统一返回结果对象 */
	private ResultEntity result;	
	
	public AdapterServiceFactoryBuilder build() {
		// 根据不同的action构建不同的业务对象
		if(Action.FLIGHT_SEARCH.equals(commonEntity.getAction())){
			BaseParameter param = null;
			// 验证参数
			if(null == data) {
				log.info("[data:]参数异常");
				this.result = ResultEntityUtil.getEntity(
						ResultCode.FAIL, 
						MessageCode.Param.CODE_10020.getKey(),
						MessageCode.Param.CODE_10020.getValue());
				return this;
			}
			// 解析参数
			try {
				param = ibs.resolver(data);
				if(null == param) {
					log.info("[resolver:]参数异常");
					this.result = ResultEntityUtil.getEntity(
							ResultCode.FAIL, 
							MessageCode.Param.CODE_10020.getKey(),
							MessageCode.Param.CODE_10020.getValue());
					return this;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			
			// 验证参数
			BaseValid bv = ibs.valid(param);
			if(bv != null && !bv.success) {
				this.result = ResultEntityUtil.getEntity(
						ResultCode.FAIL, 
						bv.getMeg().getMsgCode(),
						bv.getMeg().getMsgText());
			}else {
				this.result = ibs.execute(param);
			}
		}
		return this;
	}
	
	public ResultEntity end() {
		return result;
	}
	
	/**
	 *  接密，并且将传递的JSON 参数
	    * @Title: resolver  
	    * @Description: TODO  
	    * @param @param json
	    * @param @return
	    * @return ServiceFactoryBuilder
	    * @throws
	 */
	public AdapterServiceFactoryBuilder resolver(CommonEntity commonEntity) {
		this.commonEntity = commonEntity;
		try {
			this.data = TMThirdDes.getDecodeString(this.commonEntity.getInBean(),"UTF-8");
		}catch (Exception e) {
			log.info("参数解密过程中，传递了非正常加密串，因此产生了一个异常!");
			e.printStackTrace();
		}
		this.ibs = getBean(commonEntity.getAction());
		return this;
	}

	  
	public IBaseService getBean(String action) {
		return (IBaseService) this.context.getBean(action);
	}
	    
	@Override
	public void setApplicationContext(org.springframework.context.ApplicationContext applicationContext)
			throws BeansException {
		this.context = applicationContext;
	}
	
	
	
}
