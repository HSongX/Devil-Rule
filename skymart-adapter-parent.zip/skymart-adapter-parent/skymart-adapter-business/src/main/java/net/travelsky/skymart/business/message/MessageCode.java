
package net.travelsky.skymart.business.message;

  
/**
 *  所有返回消息的CODE
    * @ClassName: MessageCode  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
public class MessageCode {
	
	public enum Search {
		/** 查询错误 */
		
		CODE_10010("10010","未查找到相关的航班数据"),
		CODE_10011("10011","操作成功");
		
		private String key,value;
		
		Search(String key,String value){
			this.key = key;
			this.value = value;
		}
		
		public String getKey() {
			return this.key;
		}
		
		public String getValue() {
			return this.value;
		}
	}
	
	/**
	 *  参数编码
	    * @ClassName: ParamError  
	    * @Description: TODO  
	    * @author CY  
	    * @date 2018年11月9日  
	    *
	 */
	public enum Param{
		
		/** 查询错误 */
		
		CODE_10020("10020","参数异常");
		private String key,value;
		
		Param(String key,String value){
			this.key = key;
			this.value = value;
		}
		
		public String getKey() {
			return this.key;
		}
		
		public String getValue() {
			return this.value;
		}
		
	}
	
	
	
}
