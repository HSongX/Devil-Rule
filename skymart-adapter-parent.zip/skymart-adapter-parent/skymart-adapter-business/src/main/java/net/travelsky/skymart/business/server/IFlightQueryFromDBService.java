package net.travelsky.skymart.business.server;


import java.util.List;

import net.travelsky.skymart.pojo.domain.DtcFlightSegmentEntity;
import net.travelsky.skymart.pojo.domain.FlightFromDB;
import net.travelsky.skymart.pojo.param.search.FlightSegParam;
import net.travelsky.skymart.pojo.vo.AdapterFlightInfoVo;

public interface IFlightQueryFromDBService {
	AdapterFlightInfoVo queryBySegParam(FlightSegParam flightSegParam);
}
