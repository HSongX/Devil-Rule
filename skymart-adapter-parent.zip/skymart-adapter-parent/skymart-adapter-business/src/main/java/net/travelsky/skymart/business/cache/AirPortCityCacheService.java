
package net.travelsky.skymart.business.cache;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import net.travelsky.skymart.code.mybatis.ParameterManager;
import net.travelsky.skymart.pojo.entity.DtcAirportInfoEntity;
import net.travelsky.skymart.pojo.entity.DtcCitysDataEntity;
import net.travelsky.skymart.redis.util.RedisTools;
import net.travelsky.skymart.repository.DtcAirportInfoMapper;
import net.travelsky.skymart.repository.DtcCitysDataMapper;

/**  
    * @ClassName: CommonCityCache  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月14日  
    *    
    */
@Component(value = "airPortCityCacheService")
public class AirPortCityCacheService {
	
	public static final String CITY_KEY = "SYS:CITY";
	
	public static final String AIR_PORT_KEY = "SYS:AIR_PORT";
	
	@Autowired private DtcAirportInfoMapper airPortMapper;
	
	@Autowired private DtcCitysDataMapper cityDataMapper;
	
	@Autowired 
	@Qualifier("redisLocalTools")
	private RedisTools redis;
	
	
	
	/**
	 *  缓存城市数据到redis中
	    * @Title: cacheToCity  
	    * @Description: TODO  
	    * @param @param citys
	    * @return void
	    * @throws
	 */
	public void cacheToCity() {
		List<DtcCitysDataEntity> cityItems = initCitys();
		for(DtcCitysDataEntity city : cityItems) {
			redis.setObjectToMap(CITY_KEY, city.getCitycode(), city);
		}
	}
	
	/**
	 *  缓存机场数据到redis中
	    * @Title: cacheToAirPort  
	    * @Description: TODO  
	    * @param @param airPorts
	    * @return void
	    * @throws
	 */
	public void cacheToAirPort() {
		List<DtcAirportInfoEntity> airPortItems = initAirPorts();
		for(DtcAirportInfoEntity airPort : airPortItems) {
			redis.setObjectToMap(AIR_PORT_KEY, airPort.getAirportcode(), airPort);
		}
	}
	
	public void removeCity() {
		redis.deleteObject(CITY_KEY);
	}
	
	public void removeAirPort() {
		redis.deleteObject(AIR_PORT_KEY);
	}
	
	/**
	 *  获取DB的城市信息
	    * @Title: initCitys  
	    * @Description: TODO  
	    * @param @return
	    * @return List<DtcCitysDataEntity>
	    * @throws
	 */
	public List<DtcCitysDataEntity> initCitys() {
		ParameterManager pm = new ParameterManager();
		return cityDataMapper.searchList(pm.getParameter());
	}
	
	/**
	 *  获取DB的机场信息
	    * @Title: initAirPorts  
	    * @Description: TODO  
	    * @param @return
	    * @return List<DtcAirportInfoEntity>
	    * @throws
	 */
	public List<DtcAirportInfoEntity> initAirPorts() {
		ParameterManager pm = new ParameterManager();
		return airPortMapper.searchList(pm.getParameter());
	}
	
}
