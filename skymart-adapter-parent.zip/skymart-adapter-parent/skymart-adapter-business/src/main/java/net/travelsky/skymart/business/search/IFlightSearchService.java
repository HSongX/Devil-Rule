  
    /**    
    * @Title: ITestService.java  
    * @Package net.travelsky.skymart.business.search  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    * @version V1.0    
    */  
    
package net.travelsky.skymart.business.search;

import net.travelsky.skymart.business.IBaseService;

/**  
    * @ClassName: ITestService  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *    
    */

public interface IFlightSearchService extends IBaseService{

}
