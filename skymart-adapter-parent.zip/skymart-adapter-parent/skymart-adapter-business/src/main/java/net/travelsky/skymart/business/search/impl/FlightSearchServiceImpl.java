 
package net.travelsky.skymart.business.search.impl;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import net.travelsky.skymart.business.BaseValid;
import net.travelsky.skymart.business.cache.AirPortCityCacheTools;
import net.travelsky.skymart.business.cache.FlightCacheTools;
import net.travelsky.skymart.business.message.MessageCode;
import net.travelsky.skymart.business.search.IFlightSearchService;
import net.travelsky.skymart.code.enums.ResultCode;
import net.travelsky.skymart.code.result.ResultEntity;
import net.travelsky.skymart.code.result.ResultEntityUtil;
import net.travelsky.skymart.pojo.BaseParameter;
import net.travelsky.skymart.pojo.enums.Action;
import net.travelsky.skymart.pojo.enums.Passenger;
import net.travelsky.skymart.pojo.enums.Source;
import net.travelsky.skymart.pojo.param.search.FlightSearchParam;
import net.travelsky.skymart.pojo.param.search.FlightSegParam;
import net.travelsky.skymart.pojo.vo.AdapterFlightCabinVo;
import net.travelsky.skymart.pojo.vo.AdapterFlightInfoVo;
import net.travelsky.skymart.pojo.vo.AdapterFlightSegmentDetailsVo;
import net.travelsky.skymart.pojo.vo.AdapterFlightSegmentInfoVo;
import net.travelsky.skymart.pojo.vo.AdapterFlightTransitVo;
import net.travelsky.skymart.pojo.vo.AdpterFlightPriceVo;
import net.travelsky.skymart.service.ITDCFlightService;
import net.travelsky.skymart.tools.JSONUtil;
import net.travelsky.skymart.tools.MD5Util;
import net.travelsky.skymart.utils.AirLineSetting;
import net.travelsky.skymart.vo.RequestVo;
import net.travelsky.skymart.vo.flight.FlightCabin;
import net.travelsky.skymart.vo.flight.FlightFare;
import net.travelsky.skymart.vo.flight.FlightList;
import net.travelsky.skymart.vo.flight.FlightProduct;
import net.travelsky.skymart.vo.flight.FlightSegVO;
import net.travelsky.skymart.vo.flight.FlightSegmentDetail;
import net.travelsky.skymart.vo.flight.FlightSegmentList;
import net.travelsky.skymart.vo.flight.ToAvSearchVO;

/** 航班查询接口数据适配业务 
    * @ClassName: TestServiceImpl  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *    
    */
@Slf4j
@Service(value = Action.FLIGHT_SEARCH)
public class FlightSearchServiceImpl implements IFlightSearchService {
 	
	/** TDC驿程，接口注入 */
	@Autowired private ITDCFlightService tdcfs;
	
	@Autowired private AirPortCityCacheTools airPortCitytools;
	
	@Autowired private FlightCacheTools flightTools;
	
	/**
	 *  父类接口，完成具体业务功能的执行，并且返回对应的数据
	 */
	@Override
	public ResultEntity execute(BaseParameter param) {
		
		// 转换成需要的参数对象
		FlightSearchParam fsp = (FlightSearchParam) param;
		
		// 调用DB获取DB缓存的相关航班数据
		
		List<AdapterFlightInfoVo> afivs = Collections.emptyList();
		// 生成缓存的KEY
		String cacheKey = MD5Util.MD5(JSONUtil.toJson(param));
		if(!flightTools.hashKey(cacheKey)) {
			log.info("请求远程接口获取数据..............");
			//获取驿程,转换后的数据集
			FlightList flights_YC = getTDCHttpData(fsp);
			afivs = this.transformFlightInfoVo(flights_YC);
			flightTools.cacheFlighe(afivs, cacheKey);
		}else {
			log.info("请求本地缓存获取航班数据");
			afivs = flightTools.getFlightCache(cacheKey);
		}

		// 如果驿程数据存在,则将驿程数据装载到DB得返回结果中，并且将数据返回
		if(!afivs.isEmpty()) {
			// 装载数据
			return ResultEntityUtil.getEntity(
					ResultCode.SUCCESS, 
					MessageCode.Search.CODE_10011.getKey(), 
					MessageCode.Search.CODE_10011.getValue(),afivs);
		}
		
		return ResultEntityUtil.getEntity(
				ResultCode.FAIL, 
				MessageCode.Param.CODE_10020.getKey(), 
				MessageCode.Param.CODE_10020.getValue());

	}
	  
	/**
	 * 验证参数
	 */
	@Override
	public BaseValid valid(BaseParameter param) {
		FlightSearchParam fsp = (FlightSearchParam) param;
		BaseValid bv = null;
		// 国际/国内
		if(StringUtils.isEmpty(fsp.getFareType())) {
			log.info("[参数验证]:getFareType is null");
			bv = parameterIsNull();
			return bv;
		}
		// 数据来源
		if(StringUtils.isEmpty(fsp.getSource())) {
			log.info("[参数验证]:getSource is null");
			bv = parameterIsNull();
			return bv;
		}
		// 单程往返
		if(StringUtils.isEmpty(fsp.getRouteType())) {
			log.info("[参数验证]:getRouteType is null");
			bv = parameterIsNull();
			return bv;
		}
		// 验证航司CODE
		if(fsp.getAirLineCodes().isEmpty()) {
			log.info("[参数验证]:getCustomerInfos is null");
			bv = parameterIsNull();
			return bv;
		}
		// 验证航线信息
		if(fsp.getSegList().isEmpty()) {
			log.info("[参数验证]:getCustomerInfos is null");
			bv = parameterIsNull();
			return bv;
		}	
		return bv;
	}
    
	/**
	 * 解析参数
	 */
	@Override
	public BaseParameter resolver(String data) {
		if(data == null)
			return null;
		FlightSearchParam param = JSONUtil.toObject(data, FlightSearchParam.class);
		if(null == param) {
			return null;
		}
		return param;
	}

	/**
	 *  调用驿程接口,获取数据
	    * @Title: getTDCHttpData  
	    * @Description: TODO  
	    * @param @return
	    * @return FlightList
	    * @throws
	 */
	private FlightList getTDCHttpData(FlightSearchParam fsp) {
		// 设置驿程查询的航司
		AirLineSetting.setAirLineCode("HO");
		// 定义查询参数对象
		RequestVo<ToAvSearchVO> av = new RequestVo<ToAvSearchVO>();
		// 参数转换过程
		ToAvSearchVO inBean = new ToAvSearchVO();
		inBean.setCustomerInfos(AirLineSetting.getAirLineMap());				// 航司CODE	
		inBean.setDirect(fsp.getDirect());										// 中转方案
		inBean.setFareType(fsp.getFareType());									// 国际国内
		inBean.setRouteType(fsp.getRouteType());								// 单程往返
		inBean.setFlightSegs(this.getTransformFlightSegVO(fsp.getSegList()));	// 航程信息
		// 设置查询参数
		av.setInBean(inBean);
		FlightList flights = tdcfs.flightSearch(av);
		return flights;
	}
	
	/**
	 *  适配驿程数据，到响应对象中
	    * @Title: transformFlightInfoVo  
	    * @Description: TODO  
	    * @param @param fligthList
	    * @param @return
	    * @return AdapterFlightInfoVo
	    * @throws
	 */
	private List<AdapterFlightInfoVo> transformFlightInfoVo(FlightList fligthList) {
		
		List<AdapterFlightInfoVo> afvs = new ArrayList<AdapterFlightInfoVo>();
		
		// 驿程数据未查到得情况
		if(null == fligthList) {
			return Collections.emptyList();
		}
		FlightList result = fligthList;
		// 如果返回的结果正确
		if(result.getResult().equals(net.travelsky.skymart.contants.ResultCode.SUCCESS)) {
			
			// 获取行程列表
			List<FlightSegmentList> ycSeg = result.getFlightSegmentList();
			
			for(FlightSegmentList seg : ycSeg) {
				// 建立系统响应对象
				AdapterFlightInfoVo afvos = new AdapterFlightInfoVo();
				afvos.setArrCityCode(seg.getDestinationCity());							// 到达城市CODE
				afvos.setDepCityCode(seg.getOriginCity());								// 出发城市CODE
				afvos.setFlightDate(seg.getFlightDate());								// 出发日期
				afvos.setSource(Source.YC.getValue());									// 数据来源（驿程）
				afvos.setSegNo(seg.getSegNo()); 										// 航段号（旅行顺序）
				afvos.setFlightList(transformFlightList(seg.getFlightSegmentDetail()));	// 航班信息对象转换
				afvs.add(afvos);
			}
			
			return afvs;
		}
		
		return Collections.emptyList();
	}
	
	  
	/**
	 *  转换航班数据
	    * @Title: transformFlightList  
	    * @Description: TODO  
	    * @param @return
	    * @return List<AdapterFlightSegmentInfoVo>
	    * @throws
	 */
	private List<AdapterFlightSegmentInfoVo> transformFlightList(List<FlightSegmentDetail> segDetails) {
		List<AdapterFlightSegmentInfoVo> fsvos = new ArrayList<AdapterFlightSegmentInfoVo>();
		if(null == segDetails || segDetails.isEmpty()) {
			return Collections.emptyList();
		}
		
		for(FlightSegmentDetail details : segDetails) {
			// 创建航班信息对象
			AdapterFlightSegmentInfoVo fsvo = new AdapterFlightSegmentInfoVo();			
			fsvo.setSegMentDetails(transformSegmentDetails(details));		// 航线详情
			fsvo.setCabins(transformSCabin(details.getCabinList()));		// 仓位与价格
			fsvo.setTransits(transformTransits(details));					// 中转与经停
			fsvos.add(fsvo);
		}
	
		
		return fsvos;
	}
	
	  
	/**
	 *  中转或者航段详细信息，有中转就会有多个航段
	    * @Title: transformTransits  
	    * @Description: TODO  
	    * @param @param details
	    * @param @return
	    * @return List<AdapterFlightTransitVo>
	    * @throws
	 */
	private List<AdapterFlightTransitVo> transformTransits(FlightSegmentDetail details) {
		List<AdapterFlightTransitVo> ftVos = new ArrayList<AdapterFlightTransitVo>();
		
		/**
		 *  从缓存中获取机场与城市名称
		 */
		String arrAirPortName = airPortCitytools.getAirPortName(details.getArrAirport());
		String depAirPortName = airPortCitytools.getAirPortName(details.getDepAirport());
		String arrCityName = airPortCitytools.getCityNameByAirPortCode(details.getArrAirport());
		String depCityName = airPortCitytools.getCityNameByAirPortCode(details.getDepAirport());
		
		AdapterFlightTransitVo ftVo = new AdapterFlightTransitVo();		
		ftVo.setAirLineCode("HO");
		ftVo.setAirLineName("吉祥航空");
		ftVo.setDepAirPortName(depAirPortName);			// 起飞机场名称
		ftVo.setArrAirPortName(arrAirPortName);			// 到达机场名称
		ftVo.setDepCityName(depCityName);				// 起飞城市名称
		ftVo.setArrCityName(arrCityName);				// 到达城市名称
		ftVo.setArrAirPort(details.getArrAirport());	// 起飞机场CODE
		ftVo.setArrDate("");							// 起飞日期
		ftVo.setArrTerminal(details.getArrTerminal());	// 到达航站楼
		ftVo.setArrTime(details.getArrTm());			// 到达时间（不包含日期）
		ftVo.setCarrierFlightNo("");					// 共享航班号
		ftVo.setCarrierName("");						// 承运方名称
		ftVo.setDepAirPort(details.getDepAirport());	// 到达机场CODE
		ftVo.setDepDate("");
		ftVo.setDepTeminal(details.getDepTerminal());	// 起飞航站楼
		ftVo.setDepTime(details.getDepTm());			// 起飞时间
		ftVo.setFlightNo(details.getFlightNo());		// 航班号
		ftVo.setFltTp(details.getFltTp());				// 航班机型
		ftVo.setShared(details.isShare());				// 是否是共享航班
		ftVo.setJourneyTime("");						// 飞行时长
		ftVo.setLayoverTime("");						// 中途滞留时间
		ftVo.setNexeDay(0);								// 飞行所跨天数
		ftVo.setPlaneSize("");							// 机型大小
		ftVo.setSeqNo("0");								// 航段序号
		ftVo.setStops("");								// 经停信息
		ftVo.setCarrier(details.getCarrier());          // 承运人
		ftVos.add(ftVo);
		return ftVos;
	}

	/**
	 *  读取吉祥航空仓位信息，设置航班仓位返回数据
	    * @Title: transformSCabin  
	    * @Description: TODO  
	    * @param @param cabinList
	    * @param @return
	    * @return List<AdapterFlightCabinVo>
	    * @throws
	 */
	private List<AdapterFlightCabinVo> transformSCabin(List<FlightCabin> cabinList) {
		List<AdapterFlightCabinVo> cabins = new ArrayList<AdapterFlightCabinVo>();
		if(null == cabinList || cabinList.isEmpty()) {
			return Collections.emptyList();
		}
		for(FlightCabin cabin : cabinList) {
			AdapterFlightCabinVo cabinVo = new AdapterFlightCabinVo();
			cabinVo.setCabinClass(cabin.getCabinClass());	// 仓位等级
			cabinVo.setCainbCode(cabin.getCabinCode());		// 仓位code
			cabinVo.setInventory(cabin.getInventory());		// 可销售票数
			// 仓位价格信息，这个价格信息包含了成人、婴儿、儿童
			cabinVo.setCabinPrices(transformPassengerPrice(cabin.getFlightProduct()));
			cabins.add(cabinVo);
		}
		return cabins;
	}

	  
	/**
	 *  读取吉祥航空的仓位产品价格数据，转换成为本地数据格式
	    * @Title: transformPassengerPrice  
	    * @Description: TODO  
	    * @param @param flightProduct
	    * @param @return
	    * @return List<AdpterFlightPrice>
	    * @throws
	 */
	private List<AdpterFlightPriceVo> transformPassengerPrice(List<FlightProduct> flightProduct) {
		if(null == flightProduct || flightProduct.isEmpty()) {
			return Collections.emptyList();
		}
		List<AdpterFlightPriceVo> afps = new ArrayList<AdpterFlightPriceVo>();
		
		AdpterFlightPriceVo afpVo = null;
		for(FlightProduct product : flightProduct) {	
			
			// 判定成人、婴儿、儿童在吉祥航空返回的数据是否存在，如果数据存在装载到响应数据对象中
			if(null != product.getAdultFare()) {
				afpVo = transformAdapterFlightPrice(product.getAdultFare(),Passenger.ADT);
				afps.add(afpVo);
			}
			if(null != product.getChildFare()) {
				afpVo = transformAdapterFlightPrice(product.getChildFare(),Passenger.CHD);
				afps.add(afpVo);
			}
			if(null != product.getInfantFare()) {
				afpVo = transformAdapterFlightPrice(product.getInfantFare(),Passenger.INF);
				afps.add(afpVo);
			}
	
		}
		return afps;
	}

	  
	/**
	 *  根据吉祥航空提交过来得，成人、儿童、婴儿票价信息，转换成本地对象
	    * @Title: transformAdapterFlightPrice  
	    * @Description: TODO  
	    * @param @param product
	    * @param @return
	    * @return AdpterFlightPriceVo
	    * @throws
	 */
	private AdpterFlightPriceVo transformAdapterFlightPrice(FlightFare fare, Passenger passenger) {
				
		AdpterFlightPriceVo afpVo = new AdpterFlightPriceVo();
		afpVo.setChangeAirLineFlag(fare.isRescheduledFlag());	// 是否允许改签
		afpVo.setCnTax(fare.getCnTax());						// 机场建设费
		afpVo.setContainAirportFee(false);						// 是否包含机场建设费
		afpVo.setContainFuelFee(false);							// 是否包含燃油税
		afpVo.setContainTax(false);								// 是否包含其他税费
		afpVo.setCurrency("");									// 货币种类
		afpVo.setExtra("0");									// 其他税费
		afpVo.setFreeChangeTimes(fare.getFreeChangeTimes());	// 免费改期次数
		afpVo.setIntereiorPrice(fare.getMarketFare());			// 内部价格
		afpVo.setOriginalPrice(fare.getMarketFare());			// 销售参考价
		afpVo.setPriceType(passenger.getValue());				// 价格类型：成人、儿童、婴儿
		afpVo.setRefundFlag(fare.isRefundedFlag());				// 是否可以退票	
		afpVo.setRefundedComment(fare.getRefundedComment());	// 退改政策
		afpVo.setCangedComment(fare.getChangedComment()); 		// 改签政策
		afpVo.setTicketPrice(fare.getMarketFare());             // 票面价格
		afpVo.setOriginalPrice(fare.getRsp());                  // 销售参考价
		afpVo.setOverheadPrice(fare.getEfPrice());              // 全价
		afpVo.setUpdateFlag(fare.isUpgradeFlag());              // 是否可以升仓
		afpVo.setYoTax(fare.getYqTax()); 						// 然后附加费
		afpVo.setPriceId(fare.getFareId());                     // 运价编号
		String discount = new DecimalFormat("0.00").format(Double.valueOf(fare.getDiscount()));
		afpVo.setDiscount(discount);							// 折扣率
		return afpVo;
	}
	
	/**
	 *  读取吉祥航空航班信息对象，转换航班详情对象
	    * @Title: transformSegmentDetails  
	    * @Description: TODO  
	    * @param @param details
	    * @param @return
	    * @return AdapterFlightSegmentDetailsVo
	    * @throws
	 */
	private AdapterFlightSegmentDetailsVo transformSegmentDetails(FlightSegmentDetail details) {
		
		/**
		 *  从缓存中获取机场与城市名称
		 */
		String arrAirPortName = airPortCitytools.getAirPortName(details.getArrAirport());
		String depAirPortName = airPortCitytools.getAirPortName(details.getDepAirport());
		String arrCityName = airPortCitytools.getCityNameByAirPortCode(details.getArrAirport());
		String depCityName = airPortCitytools.getCityNameByAirPortCode(details.getDepAirport());
		
		AdapterFlightSegmentDetailsVo aFsdVo = new AdapterFlightSegmentDetailsVo();
		aFsdVo.setAirLineCode("HO");					// 航司CODE
		aFsdVo.setAirLineName("吉祥航空");					// 航司名称
		aFsdVo.setArrAirPort(details.getArrAirport());	// 到达机场CODE
		aFsdVo.setArrDate("");							// 到达日期
		aFsdVo.setArrTerminal(details.getArrTerminal());// 到达航站楼
		aFsdVo.setArrTime(details.getArrTm());			// 到达时间（不包含日期）
		aFsdVo.setDepArrPort(details.getDepAirport());	// 起飞机场CODE
		aFsdVo.setDepDate("");							// 起飞日期
		aFsdVo.setDepTerminal(details.getDepTerminal());// 起飞航站楼
		aFsdVo.setDepTime(details.getDepTm());			// 起飞时间
		aFsdVo.setDirect(details.isDirect());			// 是否直达true直达
		aFsdVo.setStops(details.getStops());			// 经停次数	
		aFsdVo.setTransferNum(0);						// 中转次数
		aFsdVo.setDepAirPortName(depAirPortName);		// 起飞机场名称
		aFsdVo.setArrAirPortName(arrAirPortName);		// 到达机场名称
		aFsdVo.setDepCityName(depCityName);				// 起飞城市名称
		aFsdVo.setArrCityName(arrCityName);				// 到达城市名称	
		aFsdVo.setFlightDay(0);							// 飞行天数	
		aFsdVo.setJourneyTime(0);						// 飞行时长 
		aFsdVo.setFlightNo(details.getFlightNo()); 		// 航班号
		aFsdVo.setMeal(details.isMeal()); 				// 是否包含餐食
		aFsdVo.setMealCode(details.getMealCode()); 		// 餐食CODE
		return aFsdVo;
	}

	
	/**
	 *  将自己的航段参数，转换程驿程需要的参数
	    * @Title: getTransformFlightSegVO  
	    * @Description: TODO  
	    * @param @param segList
	    * @param @return
	    * @return List<FlightSegVO>
	    * @throws
	 */
	public List<FlightSegVO> getTransformFlightSegVO(List<FlightSegParam> segList){
		List<FlightSegVO> segVos = new ArrayList<FlightSegVO>();
		if(null == segList || segList.isEmpty()) {
			return segVos;
		}
		for(FlightSegParam param : segList) {
			
			FlightSegVO vo = new FlightSegVO();
			vo.setArrAirport("ALL");						// 起飞机场
			vo.setDepAirport("ALL");						// 到达机场
			vo.setDestinationCity(param.getArrCityCode());	// 起飞城市
			vo.setOriginCity(param.getDepCityCode());		// 到达城市
			vo.setSearchDate(param.getDepDate());			// 出发日期
			vo.setSegSq(param.getSegNo());					// 查询序号
			vo.setSegTp(param.getSetType());				// 航段类型（G-去程，R-回程）		
			
			segVos.add(vo);
		}
		
		return segVos;
	}
	
}
