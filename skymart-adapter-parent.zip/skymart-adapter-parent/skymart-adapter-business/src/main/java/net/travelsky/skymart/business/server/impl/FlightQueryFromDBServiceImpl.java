package net.travelsky.skymart.business.server.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import net.travelsky.skymart.business.server.IFlightQueryFromDBService;
import net.travelsky.skymart.pojo.domain.DtcFlightSegmentEntity;
import net.travelsky.skymart.pojo.domain.FlightFromDB;
import net.travelsky.skymart.pojo.param.search.FlightSegParam;
import net.travelsky.skymart.pojo.vo.AdapterFlightCabinVo;
import net.travelsky.skymart.pojo.vo.AdapterFlightInfoVo;
import net.travelsky.skymart.pojo.vo.AdapterFlightSegmentDetailsVo;
import net.travelsky.skymart.pojo.vo.AdapterFlightSegmentInfoVo;
import net.travelsky.skymart.pojo.vo.AdapterFlightTransitVo;
import net.travelsky.skymart.pojo.vo.AdpterFlightPriceVo;
import net.travelsky.skymart.repository.DtcFlightSegmentMapper;
@Service
public class FlightQueryFromDBServiceImpl implements IFlightQueryFromDBService {
	@Autowired DtcFlightSegmentMapper dtcFlight;
	@Override
	public AdapterFlightInfoVo queryBySegParam(FlightSegParam flightSegParam) {
		//获取数据DB对象
		List<FlightFromDB> fDB = dtcFlight.queryBySegParam(flightSegParam);
		AdapterFlightInfoVo finalObj = getInfoVo(fDB);
		System.out.println(finalObj.getArrCityCode()+"=================================");
		//返回转换后的对象
		return finalObj;
	}
	//装换infovo对象
	public AdapterFlightInfoVo getInfoVo(List<FlightFromDB> fDB) {
		AdapterFlightInfoVo infoVo = new AdapterFlightInfoVo();
		List<AdapterFlightSegmentInfoVo> segmentInfoVos = getSegmentInfoVo(fDB);
		for (FlightFromDB fdb : fDB) {
			//出发城市三字码
			infoVo.setDepCityCode(fdb.getORIGIN_CITY());
			//出发城市三字码
			infoVo.setArrCityCode(fdb.getDESTINATION_CITY());
			//航班日期
			infoVo.setFlightDate(fdb.getFLIGHT_DATE());
			//数据来源
			infoVo.setSource(fdb.getSourse());
			//航段号
			infoVo.setSegNo(fdb.getSeq());
		}
		infoVo.setFlightList(segmentInfoVos);
		return infoVo;
	}
	//获取adapterFlightSegmentInfoVo对象
	public List<AdapterFlightSegmentInfoVo> getSegmentInfoVo(List<FlightFromDB> fDB) {
		List<AdapterFlightSegmentInfoVo> infoVos = new ArrayList<>();
		//匹配仓位list
		List<AdapterFlightCabinVo> cabinVosNewList = new ArrayList<>();
		List<AdapterFlightCabinVo> cabinVosGetList = getCabinList(fDB);
		//匹配航段list
		List<AdapterFlightTransitVo> transitVosNewList = new ArrayList<>();
		List<AdapterFlightTransitVo> transitVosGetList = geTransitVosList(fDB);
		for (FlightFromDB fdb : fDB) {
			AdapterFlightSegmentInfoVo segmentInfoVo = new AdapterFlightSegmentInfoVo();
			segmentInfoVo.setSegment_detail_id(fdb.getSegment_detail_id());
			for (AdapterFlightCabinVo cabinGet : cabinVosGetList) {
				if (cabinGet.getSegment_detail_id()!=null&fdb.getSegment_detail_id()!=null) {
				
					if (cabinGet.getSegment_detail_id().equals(fdb.getSegment_detail_id())) {
						cabinVosNewList.add(cabinGet);
					}	
				}
			}
			for (AdapterFlightTransitVo TransitVo : transitVosGetList) {
				if (fdb.getSegment_detail_id()!=null&TransitVo.getSegment_detail_id()!=null) {
				
					if (TransitVo.getSegment_detail_id().equals(fdb.getSegment_detail_id())) {
						transitVosNewList.add(TransitVo);
					}	
				}
			}
			segmentInfoVo.setCabins(cabinVosNewList);
			segmentInfoVo.setTransits(transitVosNewList);
			infoVos.add(segmentInfoVo);
		}
		//List<AdapterFlightCabinVo> cabinList = getCabinList();
		
		//cabinList.add(cabinVo);
		
		return infoVos;
	}
	public List<AdapterFlightCabinVo> getCabinList(List<FlightFromDB> fDB){
		//获取全部price对象集合
		List<AdpterFlightPriceVo> priceVoGetList = getPriceVoList(fDB);
		//创建要返回的cabin对象集合
		List<AdapterFlightCabinVo> cabinVosList = new ArrayList<>();
		//便利fdb获取所有cabin对象集合
		for (FlightFromDB fdb : fDB) {
			List<AdpterFlightPriceVo> priceVoList = new ArrayList<>();
			AdapterFlightCabinVo cabinVo = new AdapterFlightCabinVo();
			cabinVo.setCabinClass(fdb.getCabin_class()); // 仓位类型
			cabinVo.setCainbCode(fdb.getCabin_code());//仓位code
			cabinVo.setInventory(fdb.getInventory());//可销售数
			cabinVo.setSegment_detail_id(fdb.getSegment_detail_id());//传入航班id
			//遍历获取的pricelist匹配cabin_code放入创建的cabin对象
			for (AdpterFlightPriceVo PriceVo : priceVoGetList) {
				if (PriceVo.getCabin_code()!=null&fdb.getCabin_code()!=null) {
					if (PriceVo.getCabin_code().equals(fdb.getCabin_code())) {
						priceVoList.add(PriceVo);
					}	
				}
			}
			//为cabin对象中的集合赋值
			cabinVo.setCabinPrices(priceVoList);
			//把每个遍历的cabin对象放入集合中
			cabinVosList.add(cabinVo);
		}
		
		return cabinVosList;
	}
	//获取航段信息
	public List<AdapterFlightTransitVo> geTransitVosList(List<FlightFromDB> fdbs){
		List<AdapterFlightTransitVo> transList = new ArrayList<>();
		for (FlightFromDB fdb : fdbs) {
			AdapterFlightTransitVo transitVo = new AdapterFlightTransitVo();
			transitVo.setSegment_detail_id(fdb.getSegment_detail_id());
			if (fdb.getSeq()!=null) {
				transitVo.setSeqNo(Integer.toString(fdb.getSeq()));
			}
			transitVo.setDepAirPort(fdb.getDep_airport());
			transitVo.setDepTeminal(fdb.getDep_terminal());
			transitVo.setArrAirPort(fdb.getArr_airport());
			transitVo.setArrTerminal(fdb.getArr_terminal());
			transitVo.setFlightNo(fdb.getFlight_no());
			transitVo.setFltTp(fdb.getPlane_type());
			transitVo.setDepTime(fdb.getDep_time());
			transitVo.setArrTime(fdb.getArr_time());
			if (fdb.getShared()!=null) {
				if (fdb.getShared().equals("0")) {
					transitVo.setShared(false);
				} else if (fdb.getShared().equals("1")){
					transitVo.setShared(true);
				}
			}
			transitVo.setAirLineCode(fdb.getAirline());
			transitVo.setAirLineName(fdb.getAirline());
			transitVo.setArrDate(fdb.getArr_date());
			transitVo.setDepDate(fdb.getDep_date());
			transitVo.setCarrierFlightNo(fdb.getCarrier_flight_no());
			transitVo.setCarrierName(fdb.getCarrier_name());
			transitVo.setJourneyTime(fdb.getJourney_time());
			transitVo.setLayoverTime(fdb.getLayover_time());
			if (fdb.getNext_day()!=null) {
				transitVo.setNexeDay(Integer.valueOf(fdb.getNext_day()));
			}
			//plantSize 没有 stops没有 承运人 没有
			transitVo.setDepAirPort(fdb.getDep_airport());
			transList.add(transitVo);
		}
		
		return transList;
	}
	/**
	 * 获取全部priceList未匹配
	 * @param fdbs
	 * @return
	 */
	public List<AdpterFlightPriceVo> getPriceVoList(List<FlightFromDB> fdbs){
		List<AdpterFlightPriceVo> priceVoList = new ArrayList<>();
		for (FlightFromDB fDb : fdbs) {
			AdpterFlightPriceVo priceVo = new AdpterFlightPriceVo(); 
			priceVo.setTicketPrice(fDb.getTicket_price());
			priceVo.setOriginalPrice(fDb.getOriginal_price());
			priceVo.setIntereiorPrice(fDb.getInterior_price());
			priceVo.setPriceType(fDb.getPrice_type());
			priceVo.setYoTax(fDb.getYQ_TAX());
			priceVo.setCnTax(fDb.getCN_TAX());
			priceVo.setExtra(fDb.getExtra());
			priceVo.setDiscount(fDb.getDISCOUNT());
			if (fDb.getContain_airport_fee()!=null) {
				if (fDb.getContain_airport_fee().equals("0")) {
					priceVo.setContainAirportFee(false);
				}if (fDb.getContain_airport_fee().equals("1")) {
					priceVo.setContainAirportFee(true);
				}
			}
			if (fDb.getContain_fuel_fee()!=null) {
				if (fDb.getContain_fuel_fee().equals("0")) {
					priceVo.setContainFuelFee(false);
				}else if(fDb.getContain_fuel_fee().equals("1")) {
					priceVo.setContainFuelFee(true);
				}
			}
			if (fDb.getContain_tax()!=null) {
				if (fDb.getContain_tax().equals("0")) {
					priceVo.setContainTax(false);
				}else if (fDb.getContain_tax().equals("1")) {
					priceVo.setContainTax(true);
				}
			}
			priceVo.setCurrency(fDb.getCurrency());
			priceVo.setRefundedComment(fDb.getRefunded_changed_comment());
			if (fDb.getUpdate_FLAG()!=null) {
				if (fDb.getUpdate_FLAG().equals("0")) {
					priceVo.setUpdateFlag(false);
				} else if(fDb.getUpdate_FLAG().equals("1")){
					priceVo.setUpdateFlag(true);
				}
			}
			if (fDb.getREFUND_FLAG()!=null) {
				if (fDb.getREFUND_FLAG().equals("0")) {
					priceVo.setRefundFlag(false);
				} else if (fDb.getREFUND_FLAG().equals("1")) {
					priceVo.setRefundFlag(true);
				}
			}
			if (fDb.getCHANGE_AIRLINE_FLAG()!=null) {
				if (fDb.getCHANGE_AIRLINE_FLAG().equals("0")) {
					priceVo.setChangeAirLineFlag(false);
				} else if(fDb.getCHANGE_AIRLINE_FLAG().equals("1")) {
					priceVo.setChangeAirLineFlag(true);
				}
			}
			priceVo.setFreeChangeTimes((fDb.getFREE_CHANGE_TIMES()));
			priceVo.setCabin_code(fDb.getCabin_code());
			priceVoList.add(priceVo);
		}
		return priceVoList;
	}
 }
