  
    /**    
    * @Title: FlightCacheTools.java  
    * @Package net.travelsky.skymart.business.cache  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月14日  
    * @version V1.0    
    */  
    
package net.travelsky.skymart.business.cache;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import net.travelsky.skymart.pojo.vo.AdapterFlightInfoVo;
import net.travelsky.skymart.redis.util.RedisTools;

/**  缓存航班数据
    * @ClassName: FlightCacheTools  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月14日  
    *    
    */
@Component
public class FlightCacheTools {
	
	@Autowired 
	@Qualifier("redisLocalTools")
	private RedisTools redis;
	
	private static final String FLIGHT_CACHE_KEY = "FLIGHT:FLIGHT_SEARCH_CACHE";
	
	private static final long cacheTime = 3600L;
	
	/**
	 *  缓存航班数据
	    * @Title: cacheFlighe  
	    * @Description: TODO  
	    * @param @param afivs
	    * @return void
	    * @throws
	 */
	public void cacheFlighe(List<AdapterFlightInfoVo> afivs, String cacheKey) {
		redis.setObjectToMap(FLIGHT_CACHE_KEY, cacheKey, afivs, cacheTime);
	}
	
	/**
	 *  获取缓存中的数据 (KEY:是由 参数对象MD5加密后产生 )
	    * @Title: getFlightCache  
	    * @Description: TODO  
	    * @param @param cacheKey
	    * @param @return
	    * @return List<AdapterFlightInfoVo>
	    * @throws
	 */
	public List<AdapterFlightInfoVo> getFlightCache(String cacheKey){
		return redis.getMapToObject(FLIGHT_CACHE_KEY, cacheKey);
	}
	
	public boolean hashKey(String cacheKey) {
		return redis.hasMapKey(FLIGHT_CACHE_KEY, cacheKey);
	}
	
	public String getKey() {
		return FLIGHT_CACHE_KEY;
	}
}
