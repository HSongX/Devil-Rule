
package net.travelsky.skymart.business;

import lombok.Data;
import lombok.ToString;
import net.travelsky.skymart.code.result.Message;

/**
 *  验证结果返回
    * @ClassName: BaseValid  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
@Data
@ToString
public class BaseValid {
	public boolean success = true;
	public Message meg;
}
