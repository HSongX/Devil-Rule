  
    /**    
    * @Title: AirPortCityTools.java  
    * @Package net.travelsky.skymart.business.cache  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月14日  
    * @version V1.0    
    */  
    
package net.travelsky.skymart.business.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import net.travelsky.skymart.pojo.entity.DtcAirportInfoEntity;
import net.travelsky.skymart.pojo.entity.DtcCitysDataEntity;
import net.travelsky.skymart.redis.util.RedisTools;

/**  
    * @ClassName: AirPortCityTools  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月14日  
    *    
    */
@Component
public class AirPortCityCacheTools {

	@Autowired 
	@Qualifier("redisLocalTools")
	private RedisTools redis;
	
	@Autowired 
	@Qualifier("airPortCityCacheService")
	private AirPortCityCacheService arcTools;
	
	/**
	 *  根据城市CODE获取城市对象
	    * @Title: getCityData  
	    * @Description: TODO  
	    * @param @param cityCode
	    * @param @return
	    * @return DtcCitysDataEntity
	    * @throws
	 */
	public DtcCitysDataEntity getCityData(String cityCode) {
		// 如果缓存中没有数据，则缓存后在获取
		if(!redis.hasKey(AirPortCityCacheService.CITY_KEY)) {
			arcTools.cacheToCity();
		}
		// 如果这个城市存在，则获取这个城市对象，否则返回NULL
		if(redis.hasMapKey(AirPortCityCacheService.CITY_KEY, cityCode)){
			return redis.getMapToObject(AirPortCityCacheService.CITY_KEY, cityCode);
		}
		return null;
	}
	
	/**
	 *  根据机场CODE获取机场对象
	    * @Title: getAirPortData  
	    * @Description: TODO  
	    * @param @param airPortCode
	    * @param @return
	    * @return DtcAirportInfoEntity
	    * @throws
	 */
	public DtcAirportInfoEntity getAirPortData(String airPortCode) {
		// 如果缓存中没有数据，则缓存后在获取
		if(!redis.hasKey(AirPortCityCacheService.AIR_PORT_KEY)) {
			arcTools.cacheToCity();
		}
		// 如果这个城市存在，则获取这个城市对象，否则返回NULL
		if(redis.hasMapKey(AirPortCityCacheService.AIR_PORT_KEY, airPortCode)){
			return redis.getMapToObject(AirPortCityCacheService.AIR_PORT_KEY, airPortCode);
		}
		return null;
	}
	
	/**
	 *  根据城市CODE获取城市名称
	    * @Title: getCityName  
	    * @Description: TODO  
	    * @param @param cityCode
	    * @param @return
	    * @return String
	    * @throws
	 */
	public String getCityName(String cityCode) {
		 DtcCitysDataEntity city = this.getCityData(cityCode);
		 if(null == city)
			 return"";
		 return city.getCityzhname();
	}
	
	/**
	 *  根据机场CODE获取机场名称
	    * @Title: getAirPortName  
	    * @Description: TODO  
	    * @param @param airPortCode
	    * @param @return
	    * @return String
	    * @throws
	 */
	public String getAirPortName(String airPortCode) {
		DtcAirportInfoEntity airPort = this.getAirPortData(airPortCode);
		if(null == airPort)
			return "";
		return airPort.getAirportname();		
	}
	
	/**
	 *  根据机场CODE获取这个机场的城市名称
	    * @Title: getCityNameByAirPortCode  
	    * @Description: TODO  
	    * @param @param airPortCode
	    * @param @return
	    * @return String
	    * @throws
	 */
	public String getCityNameByAirPortCode(String airPortCode) {
		DtcAirportInfoEntity airPort = this.getAirPortData(airPortCode);
		if(null == airPort)
			return "";
		return this.getCityName(airPort.getCitycode());
	}
	
}
