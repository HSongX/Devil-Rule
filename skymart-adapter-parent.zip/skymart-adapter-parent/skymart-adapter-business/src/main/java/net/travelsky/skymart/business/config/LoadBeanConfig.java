
package net.travelsky.skymart.business.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.core.RedisTemplate;
import net.travelsky.skymart.redis.util.RedisTools;

/**
 *  加载BEAN
    * @ClassName: LoadBeanConfig  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月14日  
    *
 */
@Configuration
public class LoadBeanConfig {
	
	/**
	 *  本地redis工具注入
	    * @Title: redisLocalTools  
	    * @Description: TODO  
	    * @param @param redisTemplate
	    * @param @return
	    * @return RedisTools
	    * @throws
	 */
	@Bean(name = "redisLocalTools")
	@Primary
	public RedisTools redisLocalTools(@Qualifier("redisLocalTemplate") RedisTemplate<String, Object> redisTemplate) {
		return new RedisTools(redisTemplate);
	}
	
}
