 
package net.travelsky.skymart.business.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import net.travelsky.skymart.business.cache.AirPortCityCacheService;

/**
 *  系统启动得监听器，在这个监听器中加载缓存的基础数据
    * @ClassName: ApplicationContextCacheListener  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月14日  
    *
 */
@Component
public class ApplicationContextCacheListener implements ServletContextListener{
	
	@Autowired 
	@Qualifier("airPortCityCacheService")
	private AirPortCityCacheService arcCache;
	
	
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		/**
		 *  加载DB的城市与机场相关数据到缓存中
		 */
		arcCache.cacheToAirPort();
		arcCache.cacheToCity();
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
//		arcCache.removeAirPort();
//		arcCache.removeCity();
	}
   

}
