 
package net.travelsky.skymart.business;


import net.travelsky.skymart.business.message.MessageCode;
import net.travelsky.skymart.code.result.Message;
import net.travelsky.skymart.code.result.ResultEntity;
import net.travelsky.skymart.pojo.BaseParameter;


/**
 *  所有业务接口的父接口
    * @ClassName: IBaseService  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
public interface IBaseService {
	
	/**
	 *  执行业务
	    * @Title: execute  
	    * @Description: TODO  
	    * @param @param inBean
	    * @param @return
	    * @return BaseVo
	    * @throws
	 */
	ResultEntity execute(BaseParameter param);
	
	/**
	 *  验证参数
	    * @Title: valid  
	    * @Description: TODO  
	    * @param @param inBean
	    * @param @return
	    * @return ResultEntity
	    * @throws
	 */
	BaseValid valid(BaseParameter param);
	
	/**
	 *  解析传递过来的数据,JSON 解析成为参数对象
	    * @Title: resolver  
	    * @Description: TODO  
	    * @param @param data
	    * @param @return
	    * @return BaseParameter
	    * @throws
	 */
	BaseParameter resolver(String data);
	
	/**
	 *  返回参数错误的验证信息
	    * @Title: parameterIsNull  
	    * @Description: TODO  
	    * @param @return
	    * @return BaseValid
	    * @throws
	 */
	default BaseValid parameterIsNull() {
		BaseValid bv = new BaseValid();
		bv.setSuccess(false);
		bv.setMeg(new Message(MessageCode.Param.CODE_10020.getKey(),MessageCode.Param.CODE_10020.getValue()));
		return bv;
	}
	
}
