package net.travelsky.skymart.redis.util;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.BoundHashOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import net.travelsky.skymart.redis.exception.ObjectNullException;
import net.travelsky.skymart.redis.exception.RedisException;
import net.travelsky.skymart.redis.exception.RedisKeyNullException;
import net.travelsky.skymart.redis.page.RedisPageHelper;

/**
 * 
    * @ClassName: RedisCacheUtils  
    * @Description: Redis 操作工具类，完成对缓存数据的操作，设置超时时间（单位：秒）  
    * @author CY  
    * @date 2018年7月31日  
    *
 */
public class RedisTools{
	
	private RedisTemplate<String,Object> redisTemplate;
	    
	public RedisTools(RedisTemplate<String, Object> redisTemplate) {
		this.redisTemplate = redisTemplate;
	}

	/**
	 * 
	    * @Title: getKeys  
	    * @Description: 获取redis中所有得keys  
	    * @param @return
	    * @return Set<Object>
	    * @throws
	 */
	public synchronized Set<String> getKeys() {
		return redisTemplate.keys("*");
	}
	
	/**
	 * 
	    * @Title: getKeys  
	    * @Description: 模糊获取系统中，相关的KEY  
	    * @param @param key
	    * @param @return
	    * @return Set<String>
	    * @throws
	 */
	public synchronized Set<String> getLikeKeys(String key){
		this.throwsKeyNullException(key, "getLikeKeys()");
		return redisTemplate.keys(key);
	}
	
	/**
	 * 
	    * @Title: hasKey  
	    * @Description: 判定是否存在这个key  
	    * @param @param key
	    * @param @return
	    * @return boolean
	    * @throws
	 */
	public synchronized boolean hasKey(final String key) {
		this.throwsKeyNullException(key, "hasKey()");
		return redisTemplate.hasKey(key);
	}
	
	/**
	 *  左侧压入 重载方法
	    * @Title: leftPush  
	    * @Description: TODO  
	    * @param @param key
	    * @param @param object
	    * @param @param timeout
	    * @param @return
	    * @return Long
	    * @throws
	 */
	public synchronized Long leftPush(String key, Object object, Long timeout){
		this.throwsObjectException(key, object, "leftPush()");
		if(timeout >= 0)
			redisTemplate.expire(key, timeout, TimeUnit.SECONDS);
		return redisTemplate.boundListOps(key).leftPush(object);
	}
	
	/**
	 *  左侧压入
	    * @Title: lpush  
	    * @Description: TODO  
	    * @param @param key
	    * @param @param list
	    * @param @return
	    * @return Long
	    * @throws
	 */
	public synchronized Long leftPush(String key, Object object){
		return leftPush(key, object, 0L);
	}
	
	/**
	 *  右侧取出
	    * @Title: rightPop  
	    * @Description: TODO  
	    * @param @param key
	    * @param @return
	    * @return Object
	    * @throws
	 */
	public Object rightPop(String key) {
		this.throwsKeyNullException(key, "rightPop()");
		return redisTemplate.boundListOps(key).rightPop();
	}
	
	/**
	 * 
	    * @Title: addObject  
	    * @Description: 添加一个对象到缓存中  
	    * @param @param key
	    * @param @param object
	    * @param @param timeout
	    * @return void
	    * @throws
	 */
	public void addObject(String key,Object object,Long timeout) {
		this.throwsObjectException(key, object,"addObject()");
		addObject(key,object);
		if(timeout >= 0)
			redisTemplate.expire(key, timeout, TimeUnit.SECONDS);
	}

	/**
	 * 
	    * @Title: addObject  
	    * @Description: 添加一个对象到缓存中  （重载方法）  
	    * @param @param key
	    * @param @param object
	    * @param @param timeout
	    * @return void
	    * @throws
	 */
	public void addObject(final String key,Object object, Date timeout) {
		this.throwsObjectException(key, object,"addObject()");
		addObject(key,object);
		if(null != timeout)
			redisTemplate.expireAt(key, timeout);
	}
	
	/**
	 *  根据key获取集合中的数量
	    * @Title: getListSize  
	    * @Description: TODO  
	    * @param @param key
	    * @param @return
	    * @return long
	    * @throws
	 */
	public long getListSize(String key) {
		return redisTemplate.boundListOps(key).size();
	}
	
	/**
	 * 
	    * @Title: addObject  
	    * @Description: 添加一个对象到缓存中  （重载方法）    
	    * @param @param key
	    * @param @param object
	    * @return void
	    * @throws
	 */
	public void addObject(final String key,Object object) {
		this.throwsObjectException(key, object,"addObject()");
		redisTemplate.boundValueOps(key).set(object); 
	}
	
	/**
	 * 
	    * @Title: getObject  
	    * @Description: 根据KEY获取对象    
	    * @param @param key
	    * @param @param clazz
	    * @param @return
	    * @return T
	    * @throws
	 */
	@SuppressWarnings("unchecked")
	public <T> T getObject(final String key,Class<T> clazz) {	
		this.throwsKeyNullException(key,"getObject()");
		return (T)redisTemplate.boundValueOps(key).get();
	}
	
	/**
	 * 
	    * @Title: getObject  
	    * @Description: 根据KEY获取对象  
	    * @param @param key
	    * @return void
	    * @throws
	 */
	public Object getObject(final String key) {	
		this.throwsKeyNullException(key,"getObject()");
		return redisTemplate.boundValueOps(key).get();
	}

	
	/**
	 * 
	    * @Title: addList  
	    * @Description: 添加一个集合到redis缓存中  
	    * @param @param key
	    * @param @param list
	    * @return void
	    * @throws
	 */
	public synchronized <T> Long addList(final String key, List<T> list) {
		this.throwsObjectException(key, list, "addList()");
		if(this.hasKey(key)) {
			this.deleteObject(key);
		}
		return setRightList(key, list);
	}
	
	/**
	 * 
	    * @Title: addList 
	    * @Description: 添加一个集合到redis缓存中  ,设置超时时间
	    * @param @param key
	    * @param @param list
	    * @param @param timeout  
	    * @return void
	    * @throws
	 */
	public synchronized <T> Long addList(final String key, List<T> list,Long timeout) {
		this.throwsObjectException(key, list, "addList()");
		Long rs = addList(key, list);
		if(null != timeout)
			redisTemplate.expire(key, timeout,TimeUnit.SECONDS);
		return rs;
	}
	
	/**
	 * 
	    * @Title: addList 
	    * @Description: 添加一个集合到redis缓存中  ,设置超时时间
	    * @param @param key
	    * @param @param list
	    * @param @param timeout  
	    * @return void
	    * @throws
	 */
	public synchronized <T> Long addList(final String key, List<T> list,Date timeout) {
		this.throwsObjectException(key, list, "addList()");
		Long rs = addList(key, list);
		if(null != timeout)
			redisTemplate.expireAt(key, timeout);
		return rs;
	}
	
	/**
	 * 
	    * @Title: appendListLast  
	    * @Description: 在缓存中追加一个对象到集合的默认  ，可以追缴一个
	    * @param @param key
	    * @param @return
	    * @return Long
	    * @throws
	 */
	public synchronized <T> Long appendListLast(final String key, T t) {
		this.throwsObjectException(key, t, "appendListLast()");
		if(!this.hasKey(key)) {
			return 0L;
		}
		return redisTemplate.boundListOps(key).rightPush(t);
	}
	
	/**
	 * 
	    * @Title: appendListLast  
	    * @Description: 添加一个集合到redis缓存中  ,可以追加多个
	    * @param @param key
	    * @param @param ts
	    * @return void
	    * @throws
	 */
	@SuppressWarnings({ "unchecked" })
	public synchronized <T> Long appendListLast(final String key,T...ts) {
		this.throwsObjectException(key, ts, "appendListLast()");
		if(!this.hasKey(key)) {
			return 0L;
		}
		Long index= 0L;
		if(ts != null && ts.length > 0) {
			for(T t: ts) {
				appendListLast(key,t);
				index ++;
			}
			return index;
		}
		return 0L;
	}
	
	/**
	 * 
	    * @Title: appendListLast  
	    * @Description: 追加一个集合到redis中，从右侧追加  
	    * @param @param key
	    * @param @param list
	    * @param @return
	    * @return Long
	    * @throws
	 */
	public synchronized <T> Long appendListLast(final String key ,List<T> list) {
		this.throwsObjectException(key, list, "appendListLast()");
		if(!this.hasKey(key)) {
			return 0L;
		}
		return this.setRightList(key, list);
	}
	
	/**
	 * 
	    * @Title: appendListLast  
	    * @Description: 在缓存中追加一个对象到集合的默认  ，可以追缴一个
	    * @param @param key
	    * @param @return
	    * @return Long
	    * @throws
	 */
	public synchronized <T> Long appendListFirst(final String key, T t) {
		this.throwsObjectException(key, t, "appendListAfter()");
		if(!this.hasKey(key)) {
			return 0L;
		}
		return redisTemplate.boundListOps(key).leftPush(t);
	}
	
	/**
	 * 
	    * @Title: appendListLast  
	    * @Description: 添加一个集合到redis缓存中  ,可以追加多个
	    * @param @param key
	    * @param @param ts
	    * @return void
	    * @throws
	 */
	@SuppressWarnings({ "unchecked" })
	public synchronized <T> Long appendListFirst(final String key,T...ts) {
		this.throwsObjectException(key, ts, "appendListAfter()");
		if(!this.hasKey(key)) {
			return 0L;
		}
		Long index= 0L;
		if(ts != null && ts.length > 0) {
			for(T t: ts) {
				appendListFirst(key,t);
				index ++;
			}
			return index;
		}
		return 0L;
	}

	/**
	 * 
	    * @Title: appendLastAfater  
	    * @Description: 追加一个集合到redis中，从左侧追加   
	    * @param @param key
	    * @param @param list
	    * @param @return
	    * @return Long
	    * @throws
	 */
	public synchronized <T> Long appendListFirst(final String key,List<T> list) {
		this.throwsObjectException(key, list, "appendListAfter()");
		if(!this.hasKey(key)) {
			return 0L;
		}
		return this.setLeftList(key, list);
	}
	
	/**
	 * 
	    * @Title: deleteObject  
	    * @Description: 删除缓存中的key  
	    * @param @param key
	    * @return void
	    * @throws
	 */
	public Long deleteObject(final String... keys) {
		return  redisTemplate.execute(new RedisCallback<Long>() {

			@Override
			public Long doInRedis(RedisConnection connection) throws DataAccessException {
			    if(keys!=null && keys.length > 0){  
				      if(keys.length == 1){  
				    	  connection.del(keys[0].getBytes()); 
				      }else{  
				    	  for(String key : keys) {
				    		  connection.del(key.getBytes()); 
				    	  }	
				      }  
				}		
				return 0L;
			}
			
		});
	}
    
	/**
	 * 
	    * @Title: getListAll  
	    * @Description: 读取全部缓存中的数据，转换为集合对象并且返回  
	    * @param @param key
	    * @param @return
	    * @return List<T>
	    * @throws
	 */
	public synchronized <T> List<T> getListAll(final String key){
		return getList(key, 0, -1);
	}

	/**
	 * 
	    * @Title: getListByIndex  
	    * @Description: 根据开始索引与结束索引读取缓存集合中的数据，如果结束索引设置为-1标识读取全部  
	    * @param @param key
	    * @param @param startIndex
	    * @param @param endIndex
	    * @param @return
	    * @return List<T>
	    * @throws
	 */
	public synchronized <T> List<T> getListByIndex(final String key,int startIndex,int endIndex){
		if(endIndex <= 0) {
			return this.getListAll(key);
		}
		return this.getList(key, startIndex, endIndex);
	}
	
	/**
	 *  根据索引获取数据
	    * @Title: getListByIndex  
	    * @Description: TODO  
	    * @param @param key
	    * @param @param index
	    * @param @return
	    * @return Object
	    * @throws
	 */
	public synchronized Object getListByIndex(final String key, long index){
		return redisTemplate.boundListOps(key).index(index);
	}
	
	/**
	 * 
	    * @Title: getListByPage  
	    * @Description: 根据开始索引与结束索引读取缓存集合中的数据，如果结束索引设置为-1标识读取全部  
	    * @param @param key
	    * @param @param pageIndex 当前页
	    * @param @param pageSize  每页显示数量
	    * @param @return
	    * @return List<T>
	    * @throws
	 */
	public synchronized <T> RedisPageHelper getListByPage(final String key,Long pageIndex,Long pageSize){
		
		/**
		 * 得到redis 这个key的总数据量
		 */
		Long total = redisTemplate.boundListOps(key).size();
		
		/**
		 * 创建分页助手对象，并且设置相关参数
		 */
		RedisPageHelper pageHelper = new RedisPageHelper();
		pageHelper.setPageIndex(pageIndex);
		pageHelper.setPageSize(pageSize);
		pageHelper.setTotal(total);
		
		// 计算显示的位置
		Long startIndex = (pageHelper.getPageIndex() - 1) * pageHelper.getPageSize();
		Long endIndex = startIndex + pageHelper.getPageSize() - 1;
		// 查询相关数据	
		List<T> list = this.getList(key, startIndex.intValue(), endIndex.intValue());
		// 设置结果集
		pageHelper.setList(list);
		
		return pageHelper; 
	}
	
	/**
	 * 
	    * @Title: getExpire  
	    * @Description: 获取某个键值的超时剩余时间  （单位：秒）
	    * @param @param key
	    * @param @return
	    * @return Long
	    * @throws
	 */
	public Long getExpire(final String key) {
		return redisTemplate.getExpire(key);
	}

	/**************************以下是私有方放****************************/
	/**
	 * 	私有方法：
	    * @Title: setList  
	    * @Description: 添加一个集合到缓存中，从右侧添加  
	    * @param @param key
	    * @param @param list
	    * @param @return
	    * @return Long
	    * @throws
	 */
	private <T> Long setRightList(final String key, List<T> list) {
		Long index = 0L;
		for(T t : list) {
			redisTemplate.boundListOps(key).rightPush(t);
			index ++;
		}
		return index;
	}
	
	/**
	 * 	私有方法：
	    * @Title: setList  
	    * @Description: 添加一个集合到缓存中，从左侧添加  
	    * @param @param key
	    * @param @param list
	    * @param @return
	    * @return Long
	    * @throws
	 */
	private <T> Long setLeftList(final String key, List<T> list) {
		Long index = 0L;
		for(T t : list) {
			redisTemplate.boundListOps(key).leftPush(t);
			index ++;
		}
		return index;
	}
	
	/**
	 * 私有方法：
	    * @Title: getList  
	    * @Description: 读取几何中的数据  
	    * @param @param key
	    * @param @param startIndex
	    * @param @param endIndex
	    * @param @return
	    * @return List<T>
	    * @throws
	 */
	@SuppressWarnings("unchecked")
	private <T> List<T> getList(String key, int startIndex, int endIndex) {
		Object object = redisTemplate.boundListOps(key).range(startIndex, endIndex);
		if(null == object) {
			return null;
		}
		List<T> tList = (List<T>)object;
		return tList;
	}
	
	/**
	 * 
	    * @Title: setMap  
	    * @Description: 保存Map对象到redis中  
	    * @param @param rKey
	    * @param @param dataMap
	    * @return void
	    * @throws
	 */
	public <T> BoundHashOperations<String, String, T> setMap(String rKey,Map<String,T> dataMap) {
		
		BoundHashOperations<String, String, T> bHashOperations = redisTemplate.boundHashOps(rKey);
		if(dataMap == null) {
			this.throwsObjectException(rKey, dataMap, "setMap()");
			return null;
		}
		
		for(Map.Entry<String, T> entry : dataMap.entrySet()) {
			bHashOperations.put(entry.getKey(), entry.getValue());
		}
		return bHashOperations;
	}
	
	/**
	 * 
	    * @Title: setMap  
	    * @Description: 保存Map对象到redis中   并设置超时时间(单位：秒)  
	    * @param @param rKey
	    * @param @param dataMap
	    * @param @param timeout
	    * @return void
	    * @throws
	 */
	public <T> BoundHashOperations<String, String, T> setMap(String rKey,Map<String,T> dataMap, Long timeout) {
		BoundHashOperations<String, String, T> bHashOperations = setMap(rKey, dataMap);
		if(bHashOperations == null) {
			return null;
		}
		bHashOperations.expire(timeout, TimeUnit.SECONDS);
		return bHashOperations;
	}
	
	/**
	 * 
	    * @Title: setMap  
	    * @Description: 保存Map对象到redis中   并设置超时时间(日期：延后)    
	    * @param @param rKey
	    * @param @param dataMap
	    * @param @param timeout
	    * @return void
	    * @throws
	 */
	public <T> BoundHashOperations<String, String, T> setMap(String rKey,Map<String,T> dataMap, Date timeout) {
		BoundHashOperations<String, String, T> bHashOperations = setMap(rKey, dataMap);
		if(bHashOperations == null) {
			return null;
		}
		bHashOperations.expireAt(timeout);
		return bHashOperations;
	}
	
	/**
	 * 
	    * @Title: getMapAll  
	    * @Description: 获取缓存中所有得Map对象  
	    * @param @param rKey
	    * @param @return
	    * @return Map<String,T>
	    * @throws
	 */
	public <T> Map<String, T> getMapAll(String rKey){
		BoundHashOperations<String, String, T> bHashOperations = redisTemplate.boundHashOps(rKey);
		return bHashOperations.entries();
	}
	
	/**
	 * 
	    * @Title: GetMap  
	    * @Description: 根据KEY获取缓存中得对象  
	    * @param @param rKey
	    * @param @param hKey
	    * @param @return
	    * @return T
	    * @throws
	 */
	@SuppressWarnings("unchecked")
	public <T> T getMapToObject(String rKey,String hKey) {
		return (T) redisTemplate.boundHashOps(rKey).get(hKey);
	}
	
	/**
	 * 
	    * @Title: getMapValues  
	    * @Description: 获取Map 下 key所有得  values   
	    * @param @param rKey
	    * @param @return
	    * @return List<T>
	    * @throws
	 */
	public <T> List<T> getMapValues(String rKey){
		BoundHashOperations<String, String, T> bHashOperations = redisTemplate.boundHashOps(rKey);
		return bHashOperations.values();
	}
	
	/**
	 * 
	    * @Title: isMapEmpty  
	    * @Description: 判定Map 中得 key 是否存在  
	    * @param @param rKey
	    * @param @param hKey
	    * @param @return
	    * @return boolean
	    * @throws
	 */
	public <T> boolean hasMapKey(String rKey,String hKey) {
		BoundHashOperations<String, String, T> bHashOperations = redisTemplate.boundHashOps(rKey);
		return bHashOperations.hasKey(hKey);
	}
	
	/**
	 * 
	    * @Title: getMapKeys  
	    * @Description: 获取 缓存 map 中所有的 keys  
	    * @param @param rKey
	    * @param @return
	    * @return Set<String>
	    * @throws
	 */
	public <T> Set<String> getMapKeys(String rKey){
		BoundHashOperations<String, String, T> bHashOperations = redisTemplate.boundHashOps(rKey);
		return bHashOperations.keys();
	}
	
	/**
	 * 
	    * @Title: setMap  
	    * @Description: 添加一个Key-Value 到缓存中  
	    * @param @param key
	    * @param @param value
	    * @return void
	    * @throws
	 */
	public  <T> BoundHashOperations<String, String, T> setObjectToMap(String rKey,String hKey, T hValue) {       
		BoundHashOperations<String, String, T> bHashOperations = redisTemplate.boundHashOps(rKey);
		if(bHashOperations == null) {
			return null;
		}
		bHashOperations.put(hKey, hValue);
		return bHashOperations;
	}
	
	/**
	 * 	重载方法：
	    * @Title: setObjectToMap  
	    * @Description: 添加一个Key-Value 到缓存中    ，带超时时间(单位：秒)
	    * @param @param rKey
	    * @param @param hKey
	    * @param @param hValue
	    * @param @param timeout
	    * @return void
	    * @throws
	 */
	public  <T> BoundHashOperations<String, String, T> setObjectToMap(String rKey,String hKey, T hValue,Long timeout) {      
		BoundHashOperations<String, String, T> bHashOperations = setObjectToMap(rKey,hKey,hValue);
		if(bHashOperations == null) {
			return null;
		}
		bHashOperations.expire(timeout, TimeUnit.SECONDS);
		return bHashOperations;
	}
	
	/**
	 * 
	    * @Title: setObjectToMap  
	    * @Description: 添加一个Key-Value 到缓存中    ，带超时时间(单位：日期延后)  
	    * @param @param rKey
	    * @param @param hKey
	    * @param @param hValue
	    * @param @param timeout
	    * @return void
	    * @throws
	 */
	public  <T> BoundHashOperations<String, String, T> setObjectToMap(String rKey,String hKey, T hValue,Date timeout) {      
		BoundHashOperations<String, String, T> bHashOperations = setObjectToMap(rKey,hKey,hValue);
		if(bHashOperations == null) {
			return null;
		}
		bHashOperations.expireAt(timeout);
		return bHashOperations;
	}
	
	/**
	 * 
	    * @Title: deleteMapByKeys  
	    * @Description: 删除相关 map 中的key  
	    * @param @param rKey
	    * @param @param keys
	    * @param @return
	    * @return Long
	    * @throws
	 */
	@SuppressWarnings("unchecked")
	public <T> Long deleteMapByKeys(String rKey, T... keys) {
		if(keys == null || keys.length <= 0) {
			return 0L;
		}
		BoundHashOperations<String, String, T> bHashOperations = redisTemplate.boundHashOps(rKey);
		return bHashOperations.delete(keys);
	}
	
	/**
	 * 	私有方法：
	    * @Title: throwsObjectException  
	    * @Description: 异常抛出的共通方法  
	    * @param @param key
	    * @param @param object
	    * @return void
	    * @throws
	 */
	private void throwsObjectException(String key,Object object,String methodName) {
		this.throwsKeyNullException(key,methodName);
		try {
			if(null == object) {
				throw new ObjectNullException("方法: "+methodName+"  参数为空,不能将一个null对象保存到redis中! ");
			}
		}catch (RedisException ex) {
			ex.printStackTrace();
		}
	}
	
	private void throwsKeyNullException(String key,String methodName) {
		try {
			if(null == key || key.equals("")) {
				throw new RedisKeyNullException("方法: "+methodName+"  要求传递的参数 key 是 null 或者是 empty, 因此产生的异常! ");
			}
		}catch (RedisException ex) {
			ex.printStackTrace();
		}
	}

}
