package net.travelsky.skymart.redis.config;

import org.springframework.cache.CacheManager;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.core.RedisTemplate;

import lombok.extern.slf4j.Slf4j;

/**
 * 
    * @ClassName: RedisCacheManager  
    * @Description: 配置 spring  缓存策略使用redis进行处理  
    * @author CY  
    * @date 2018年7月30日  
    *
 */
//@Configuration
@Slf4j
public class CacheManagerConfig {

	/**
	 * 
	    * @Title: cacheManager  
	    * @Description: 将redis模板工具类，添加到缓存管理器中  
	    * @param @param redisTemplate
	    * @param @return
	    * @return CacheManager
	    * @throws
	 */
    // @Bean 
    public CacheManager cacheManager(@SuppressWarnings("rawtypes") RedisTemplate redisTemplate) {
    	log.info("注册spring 缓存管理器为redis 处理.....");
    	RedisCacheManager cacheManager = new RedisCacheManager(redisTemplate);
        //设置缓存过期时间 
        cacheManager.setDefaultExpiration(10000);
        return cacheManager;
    }
	
}
