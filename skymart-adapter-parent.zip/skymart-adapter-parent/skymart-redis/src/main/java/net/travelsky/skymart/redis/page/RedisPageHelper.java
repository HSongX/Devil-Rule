package net.travelsky.skymart.redis.page;

import java.util.List;

public class RedisPageHelper {
	/**
	 * 当前页码
	 */
	private Long pageIndex = 1L;
	/**
	 * 每页显示记录数
	 */
	private Long pageSize = 10L;
	/**
	 * 总记录数，isOpenCount=true 开启才会统计
	 */
	private Long total;
	/**
	 * 返回的数据集合对象
	 */
	private List<?> list;
	
	/**
	 * 是否是第一页
	 */
	@SuppressWarnings("unused")
	private boolean isFirst;
	/**
	 * 是否是最后一页
	 */
	@SuppressWarnings("unused")
	private boolean isLast;
	
	/**
	 * 
	    * @Title: getPageNumber  
	    * @Description: 返回页码数量  
	    * @param @return
	    * @return Long
	    * @throws
	 */
	public Long getPageNumber() {
		
		if(getTotal() % pageSize == 0) {
			return getTotal() / pageSize;
		}
		return getTotal() / pageSize + 1;
	}
	
	/**
	 * 
	    * @Title: isLast  
	    * @Description: 判定是否是最后一页  
	    * @param @return
	    * @return boolean
	    * @throws
	 */
	public boolean isLast() {
		if(getPageIndex() >= getPageNumber()) {
			setPageIndex(getPageNumber());
			return isLast = true;
		}
		return isLast = false;
	}
	
	/**
	 * 
	    * @Title: isFirst  
	    * @Description: 判定是否是第一页
	    * @param @return
	    * @return boolean
	    * @throws
	 */
	public boolean isFirst() {
		if(getPageIndex() <= 1) {
			setPageIndex(1L);
			return isFirst = true;
		}
		return isFirst = false;
	}
	
	// get/set
	public Long getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(Long pageIndex) {
		this.pageIndex = pageIndex;
	}
	public Long getPageSize() {
		return pageSize;
	}
	public void setPageSize(Long pageSize) {
		this.pageSize = pageSize;
	}
	public Long getTotal() {
		return total;
	}
	public void setTotal(Long total) {
		this.total = total;
	}
	public List<?> getList() {
		return list;
	}
	public void setList(List<?> list) {
		this.list = list;
	}
	
}
