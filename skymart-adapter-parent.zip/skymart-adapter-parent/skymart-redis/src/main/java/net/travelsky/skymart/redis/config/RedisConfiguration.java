
package net.travelsky.skymart.redis.config;
import java.text.SimpleDateFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.JedisPoolConfig;

/**
 * 
    * @ClassName: RedisConfiguration  
    * @Description: Redis相关配置  
    * @author CY  
    * @date 2018年7月27日  
    *
 */
@Configuration
@Slf4j
public class RedisConfiguration {
    
	@Autowired RedisLocalConfigProperties redisLocalProperites;

  
    
    /**
     *  初始化本地redis读取线程
        * @Title: jedisPoolConfig  
        * @Description: 配置JedisPoolConfig  
        * @param @return
        * @return JedisPoolConfig
        * @throws
     */
    @Primary
    @Bean(name = "jedisLocalPoolConfig")
    public JedisPoolConfig jedisLocalPoolConfig() {
        log.info("初始化JedisPoolConfig 连接池.......");
        JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
        //  连接池最大连接数（使用负值表示没有限制）
        jedisPoolConfig.setMaxTotal(redisLocalProperites.getMaxTotal());  
        // 连接池最大阻塞等待时间（使用负值表示没有限制）
        jedisPoolConfig.setMaxWaitMillis(redisLocalProperites.getMaxWaitMillis());  
        // 连接池中的最大空闲连接
        jedisPoolConfig.setMaxIdle(redisLocalProperites.getMaxIdle()); 
        // 连接池中的最小空闲连接
        jedisPoolConfig.setMinIdle(redisLocalProperites.getMinIdle());  
        log.info("初始化Redis连接池完毕.......");
        return jedisPoolConfig;
    }
    


    /**
     *  建立本地redis 连接
        * @Title: jedisConnectionFactory  
        * @Description: 实例化 RedisConnectionFactory 对象  
        * @param @param poolConfig
        * @param @return
        * @return RedisConnectionFactory
        * @throws
     */
    @Primary
    @Bean(name = "jedisLocalConnectionFactory")
    public RedisConnectionFactory jedisLocalConnectionFactory(@Qualifier(value = "jedisLocalPoolConfig") JedisPoolConfig poolConfig) {
        log.info("初始化RedisConnectionFactory 连接工厂对象......");
        JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory(poolConfig);
        // 设置redis 连接地址
        jedisConnectionFactory.setHostName(redisLocalProperites.getHost());
        // 设置redis 连接密码
        jedisConnectionFactory.setPassword(redisLocalProperites.getPassword());
        // 设置redis 连接端口
        jedisConnectionFactory.setPort(redisLocalProperites.getPort());
        // 设置redis 连接DB号
        jedisConnectionFactory.setDatabase(redisLocalProperites.getDatabase());
        // 设置redis 超时时间
        jedisConnectionFactory.setTimeout(redisLocalProperites.getTimeout());   
        log.info("初始化RedisConnectionFactory 完毕......");
        return jedisConnectionFactory;
    }
    
    
    /**
     *  创建本地redisTemplate 操作模板类对象
        * @Title: redisTemplate  
        * @Description: 序列化使用的jdkSerializeable, 存储二进制字节码, 所以自定义序列化类  
        * @param @param redisConnectionFactory
        * @param @return
        * @return RedisTemplate<Object,Object>
        * @throws
     */
    @Bean(name = "redisLocalTemplate")
    public RedisTemplate<String, Object> redisLocalTemplate(@Qualifier(value = "jedisLocalConnectionFactory") RedisConnectionFactory redisConnectionFactory) {
    	return this.createTemplate(redisConnectionFactory);
    }
  

    
    /**
     *  创建模板对象，私有方法
        * @Title: createTemplate  
        * @Description: TODO  
        * @param @param redisConnectionFactory
        * @param @return
        * @return RedisTemplate<String,Object>
        * @throws
     */
    private RedisTemplate<String, Object> createTemplate(RedisConnectionFactory redisConnectionFactory){
    	
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory);
        redisTemplate.setEnableDefaultSerializer(false);
        // 使用Jackson2JsonRedisSerialize 替换默认序列化
		Jackson2JsonRedisSerializer<Object> jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer<Object>(Object.class);

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"));
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        objectMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);

        jackson2JsonRedisSerializer.setObjectMapper(objectMapper);

        // 设置value的序列化规则和 key的序列化规则
		redisTemplate.setValueSerializer(new StringRedisSerializer());
        //redisTemplate.setValueSerializer(jackson2JsonRedisSerializer);
		redisTemplate.setHashValueSerializer(jackson2JsonRedisSerializer);
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		
		redisTemplate.afterPropertiesSet();
        
        return redisTemplate;
    }
    
}
