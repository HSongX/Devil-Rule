package net.travelsky.skymart.redis.exception;

/**
 * 
    * @ClassName: RedisKeyNullException  
    * @Description: 如果传递的KEY的值是NULL或者是empty，会抛出这个异常  
    * @author CY  
    * @date 2018年7月31日  
    *
 */
public class RedisKeyNullException extends RedisException{
	    
	private static final long serialVersionUID = 5206109758894526696L;

	public RedisKeyNullException(String msg) {
		super(msg);
	}
	
}
