package net.travelsky.skymart.redis.exception;

/**
 * 
    * @ClassName: ObjectNullException  
    * @Description: 参数对象为空的时候抛出的异常信息  
    * @author CY  
    * @date 2018年7月31日  
    *
 */
public class ObjectNullException extends RedisException{

	public ObjectNullException(String msg) {
		super(msg);
	}

	private static final long serialVersionUID = 4738031726071148850L;

	
}
