package net.travelsky.skymart.redis.test;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.sun.tools.classfile.InnerClasses_attribute.Info;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.Jedis;
@Slf4j
public class redisTest {
	private Jedis jedis;
	@Before
	public void connectRedis() {
		log.info("开始连接redis");
		jedis = new Jedis("127.0.0.1", 6379);
		jedis.auth("123456");
	}
	@Test
	public void testString() {
		log.info("插入数据");
		jedis.set("name", "wangchenge");
		log.info("输出jedis数据");
		log.info(jedis.get("name")+"jedis.get(name)");
		jedis.append("name", "shimeinv");
		log.info(jedis.get("name")+"jedis.get(name)");
		jedis.del("name");
		log.info(jedis.get("name"));
		//jedis.mset操作能够设置多个键值对
		jedis.mset("name", "hello","age","11","color","write");
		//jedis.incr操作能使map中的参数值加一
		jedis.incr("age");
		log.info(jedis.get("age")+":ageageage");
	}
	@Test
	public void testMap() {
		//collection.empty 只能接受调用方法传回来的集合 必须接受返回的参数之后才能进行put add 操作
		//直接put或者add会报错 但是接受对象之后就有了接收回来的集合内存 所以就能进行add或者put操作
		Map<String,String> map = Collections.emptyMap();
		map = getmap();
		map.put("age", "11");
		jedis.hmset("user", map);
		List<String> list = jedis.hmget("user","name","age");
		for (String string : list) {
			
			System.out.println(string);
		}
		boolean isnull = map.isEmpty();
		log.info(map.get("name")+"age"+map.get("age")+map.size()+":判断是否为空");
	}
	public Map<String, String> getmap() {
		Map<String, String> map = new HashMap<>();
		map.put("name", "hansong");
		map.put("age", "222");
		return map;
		
	}
	/*@Test
	public void */
	
}
