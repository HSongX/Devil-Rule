package net.travelsky.skymart.redis.exception;

/**
 * 
    * @ClassName: RedisException  
    * @Description: 缓存相关的异常父类  
    * @author CY  
    * @date 2018年7月31日  
    *
 */
public class RedisException extends Exception{
	  
	private static final long serialVersionUID = -3483230152460266550L;

	public RedisException(String msg) {
		super(msg);
	}
	
}
