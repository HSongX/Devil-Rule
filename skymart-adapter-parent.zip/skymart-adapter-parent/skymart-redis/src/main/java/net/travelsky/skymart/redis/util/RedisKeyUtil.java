package net.travelsky.skymart.redis.util;

/**
 * 
    * @ClassName: RedisKeyUtil  
    * @Description: redis key 的生成策略  
    * @author CY  
    * @date 2018年7月30日  
    *
 */
public class RedisKeyUtil {

	/**
	 * 
	    * @Title: getKeyWithColumn  
	    * @Description: redis的key 
	    * 				形式为：
	    * 				数据库：表名:主键名:主键值:列名  
	    * 
	    * @param @param dbName 数据库名称
	    * @param @param tableName 表
	    * @param @param majorKey  主键名
	    * @param @param majorKeyValue  主键值
	    * @param @param column 列名
	    * @param @return
	    * @return String
	    * @throws
	 */
    public static String getKeyWithColumn(String dbName,String tableName,String majorKey,String majorKeyValue,String column){
        StringBuffer buffer = new StringBuffer();
        buffer.append(dbName).append(":");
        buffer.append(tableName).append(":");
        buffer.append(majorKey).append(":");
        buffer.append(majorKeyValue).append(":");
        buffer.append(column);
        return buffer.toString();
    }
    
	/**
	 * 
	    * @Title: getKey  
	    * @Description: redis的key 
	    * 				形式为：
	    * 				数据库：表名:主键名:主键值
	    * 
	    * @param @param dbName 数据库名称
	    * @param @param tableName 表
	    * @param @param majorKey  主键名
	    * @param @param majorKeyValue  主键值
	    * @param @return
	    * @return String
	    * @throws
	 */
    public static String getKey(String dbName,String tableName,String majorKey,String majorKeyValue){
        StringBuffer buffer = new StringBuffer();
        buffer.append(dbName).append(":");
        buffer.append(tableName).append(":");
        buffer.append(majorKey).append(":");
        buffer.append(majorKeyValue);
        return buffer.toString();
    }
    
	/**
	 * 
	    * @Title: getKey  
	    * @Description: redis的key 
	    * 				形式为：
	    * 				数据库：表名:主键值
	    * 
	    * @param @param dbName 数据库名称
	    * @param @param tableName 表
	    * @param @param majorKey  主键名
	    * @param @param majorKeyValue  主键值
	    * @param @return
	    * @return String
	    * @throws
	 */
    public static String getKey(String dbName,String tableName,String majorKeyValue){
        StringBuffer buffer = new StringBuffer();
        buffer.append(dbName).append(":");
        buffer.append(tableName).append(":");
        buffer.append(majorKeyValue);
        return buffer.toString();
    }
    
	/**
	 * 
	    * @Title: getKey  
	    * @Description: redis的key 
	    * 				形式为：
	    * 				数据库：表名
	    * 
	    * @param @param dbName 数据库名称
	    * @param @param tableName 表
	    * @param @return
	    * @return String
	    * @throws
	 */
    public static String getKey(String dbName,String tableName){
        StringBuffer buffer = new StringBuffer();
        buffer.append(dbName).append(":");
        buffer.append(tableName);
        return buffer.toString();
    }
}
