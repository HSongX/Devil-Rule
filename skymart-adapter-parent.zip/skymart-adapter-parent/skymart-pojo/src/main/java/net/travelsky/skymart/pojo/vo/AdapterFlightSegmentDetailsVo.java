
package net.travelsky.skymart.pojo.vo;

import lombok.Data;
import lombok.ToString;

/**
 *  航班飞行详情数据对象
    * @ClassName: AdapterFlightSegmentDetailsVo  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月13日  
    *
 */
@Data
@ToString
public class AdapterFlightSegmentDetailsVo implements java.io.Serializable{  

	private static final long serialVersionUID = -8945234815017836953L;

	//航班id
	private String segment_detail_id;
	/** 起飞机场三字码 */
	private String depArrPort;
	/** 起飞航站楼 */
	private String depTerminal;
	/** 到达机场三字码 */
	private String arrAirPort;
	/** 到达航站楼 */
	private String arrTerminal;
	/** 起飞时间 */
	private String depTime;
	/** 到达时间 */
	private String arrTime;
	/** 是否直达 */
	private Boolean direct;
	/** 经停站数 */
	private Integer stops;
	/** 航司名称 */
	private String airLineName;
	/** 航司三字码 */
	private String airLineCode;
	/** 到达日期 */
	private String arrDate;
	/** 起飞日期 */
	private String depDate;
	/** 飞行时长 */
	private Integer journeyTime;
	/** 飞行天数 (吉祥航空无)*/
	private Integer flightDay;
	/** 中转次数 (吉祥航空无)*/
	private Integer transferNum;
	/** 起飞机场名称 */
	private String depAirPortName;
	/** 到达机场名称 */
	private String arrAirPortName;
	/** 起飞城市名称 */
	private String depCityName;
	/** 到达城市名称 */
	private String arrCityName;
	/** 餐食代码 */
	private String mealCode;
	/** 航班号 */
	private String flightNo;
	/** 是否有餐食 */
	private Boolean meal;
	
}
