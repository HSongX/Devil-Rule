  
package net.travelsky.skymart.pojo;

  
/**
 *  所有参数类的父类
    * @ClassName: BaseParameter  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月12日  
    *
 */

public class BaseParameter implements java.io.Serializable{

	private static final long serialVersionUID = 7046209891698852315L;

}
