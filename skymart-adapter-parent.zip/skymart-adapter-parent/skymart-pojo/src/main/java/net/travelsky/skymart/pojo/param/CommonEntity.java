
package net.travelsky.skymart.pojo.param;

import lombok.Data;
import lombok.ToString;

/**
 *  所有父类的参数对象
    * @ClassName: CommonEntity  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
@Data
@ToString
public class CommonEntity implements java.io.Serializable{

	private static final long serialVersionUID = -2484143103930491128L;
	/** 控制器分类标识  */
	private String action;
	/** 系统用户名  */
	private String userName;
	/** 数据来源标识 */
	private String source;
	/** 数字签名（inBean的JSON串+userName+appId）做MD5加密 */
	private String sign;
	/** 参数对象，加密后的JSON对象 */
	private String inBean;
}
