  
package net.travelsky.skymart.pojo.enums;

  
/**
 *  控制器分发器，标识
    * @ClassName: Action  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
public interface Action {
	/** 航班检索 */
	static final String FLIGHT_SEARCH = "flight.search";
	
}
