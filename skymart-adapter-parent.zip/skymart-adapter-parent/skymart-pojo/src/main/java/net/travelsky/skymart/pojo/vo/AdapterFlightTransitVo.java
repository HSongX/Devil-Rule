
package net.travelsky.skymart.pojo.vo;

import lombok.Data;
import lombok.ToString;

/**
 *  航班中转信息对象
    * @ClassName: AdapterFlightTransitVo  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月13日  
    *
 */
@Data
@ToString
public class AdapterFlightTransitVo implements java.io.Serializable{  

	private static final long serialVersionUID = -7833364179405973983L;
	
	//航班id
	private String segment_detail_id;
	/** 航段番号 */
	private String seqNo;
	/** 起飞机场三字码 */
	private String depAirPort;
	/** 起飞航站楼 */
	private String depTeminal;	
	/** 到达机场三字码 */
	private String arrAirPort;	
	/** 到达航站楼 */
	private String arrTerminal;			
	/** 航班号 */
	private String flightNo;
	/** 机型 */	
	private String fltTp;
	/** 起飞时间(HH:mm) */
	private String depTime;
	/** 到达时间(HH:mm) */
	private String arrTime;
	/** 是否是共享航班（1：共享；2：非共享） */
	private Boolean shared;
	/** 航空公司名称 */
	private String airLineName;		
	/** 航空公司二字码 */
	private String airLineCode;	
	/** 到达日期 yyyy-MM-dd */
	private String arrDate;		
	/** 起飞日期  yyyy-MM-dd */
	private String depDate;		
	/** 实际承运航班号  (只有共享航班才有)*/
	private String carrierFlightNo;
	/** 承运方名称  (只有共享航班才有) */
	private String carrierName;		
	/** 飞行时长(分钟为单位) */
	private String journeyTime;
	/** 临时，中途滞留时长(分钟为单位) */	
	private String layoverTime;
	/** 航班是否跨天0,1,2 */
	private Integer nexeDay;
	/** 机型的大小 S为小，M为中，L为大 */
	private String planeSize;		
	/** 经停信息 */
	private String stops;		
	/** 起飞机场名称 */
	private String depAirPortName;
	/** 到达机场名称 */
	private String arrAirPortName;
	/** 起飞城市名称 */
	private String depCityName;
	/** 到达城市名称 */
	private String arrCityName;
	/** 承运人 */
	private String carrier;
}
