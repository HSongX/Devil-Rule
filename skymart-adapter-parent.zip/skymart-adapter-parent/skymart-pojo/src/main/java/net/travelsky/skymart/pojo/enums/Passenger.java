  

package net.travelsky.skymart.pojo.enums;

  
/**
 *  旅客类型
    * @ClassName: Passenger  
    * @Description: ADT:大人/CHD:小孩/INF:婴儿  
    * @author CY  
    * @date 2018年11月13日  
    *
 */
public enum Passenger {

	ADT("ADT"),
	CHD("CHD"),
	INF("INF");
	private String value;
	
	private Passenger(String value) {
		this.value = value;
	}
	public String getValue() {
		return this.value;
	}
}
