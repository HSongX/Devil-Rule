
package net.travelsky.skymart.pojo.vo;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.ToString;

/**
 *  每个航线的仓位价格信息
    * @ClassName: AdapterFlightCabinPrice  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月13日  
    *
 */
@Data
@ToString
public class AdapterFlightCabinVo implements java.io.Serializable{  

	private static final long serialVersionUID = -4344583060370532287L;

	/** 仓位CODE */
	private String cainbCode;
	/** 仓位等级 */
	private String cabinClass;
	/** 可销售数量 */
	private String inventory; 
	/**航班id*/
	private String segment_detail_id; 
	/** 仓位价格信息 */
	private List<AdpterFlightPriceVo> cabinPrices = new ArrayList<AdpterFlightPriceVo>();
}
