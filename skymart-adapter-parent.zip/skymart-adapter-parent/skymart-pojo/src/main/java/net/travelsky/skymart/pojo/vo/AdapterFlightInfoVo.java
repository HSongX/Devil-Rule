  
package net.travelsky.skymart.pojo.vo;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.ToString;

/**
 *  航线数据返回结果实体对象
    * @ClassName: AdapterFlightSegmentVo  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月13日  
    *
 */
@Data
@ToString
public class AdapterFlightInfoVo implements java.io.Serializable{

	private static final long serialVersionUID = -392439407174304203L;
	
	/** 出发城市三字码 */
	private String depCityCode;
	/** 到达城市三字码 */
	private String arrCityCode;
	/** 航班出发日期 */
	private String flightDate;
	/** 数据来源（GF 广分 YC 驿程 ALL 全部）*/
	private String source;
	/** 航段号 */
	private Integer segNo;
	/** 国内/国际 (D国内I国际)*/
	// private String area;
	/** 航班信息集合 */
	private List<AdapterFlightSegmentInfoVo> flightList = new ArrayList<AdapterFlightSegmentInfoVo>();
	
}
