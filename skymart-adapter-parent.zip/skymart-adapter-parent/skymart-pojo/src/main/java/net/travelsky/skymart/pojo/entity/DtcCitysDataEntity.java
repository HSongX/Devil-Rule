package net.travelsky.skymart.pojo.entity;
import java.math.BigDecimal;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class DtcCitysDataEntity{
	private BigDecimal id;
	/** 城市代码 */
	private String citycode;
	/** 城市中文名 */
	private String cityzhname;
	/** 城市英文名 */
	private String cityenname;
	/** 国家 */
	private String country;
	/** 热门城市标志 */
	private String cityhottype;
	/** 城市国内/国际标志 */
	private String citystatetype;
	/** 城市首字母 */
	private String cityinitial;
}
