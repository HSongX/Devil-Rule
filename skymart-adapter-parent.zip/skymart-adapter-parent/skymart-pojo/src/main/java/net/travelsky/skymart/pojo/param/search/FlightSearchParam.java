
package net.travelsky.skymart.pojo.param.search;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import net.travelsky.skymart.pojo.BaseParameter;

/**
 *  航班查询参数对象
    * @ClassName: FlightSearchParam  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月12日  
    *
 */
@Data
@ToString
@EqualsAndHashCode(callSuper=false)
public class FlightSearchParam extends BaseParameter{  
	
	private static final long serialVersionUID = -5214116569387646542L;
	
	/** 仓位三字码 */
	private String cabinCode;
	/** 单程往返 (OW单程/RT往返)*/
	private String routeType;
	/** 中转方案(D－只查询直达航班和运价，T－没有直达方案时，给出中转方案运价，S－没有直达方案时,只给出中转航程，不查询航班可利用座位和运价) */
	private String direct;
	/** 航司信息 */
	private Map<String,String> airLineCodes = Collections.emptyMap();
	/** 数据来源 (GF  广分接口数据   YC  驿程接口数据  ALL全部)*/
	private String source;
	/** 国际/国内(I国际/D国内) */
	private String fareType;
	/** 查询的航程 */
	private List<FlightSegParam> segList = Collections.emptyList();
	
}
