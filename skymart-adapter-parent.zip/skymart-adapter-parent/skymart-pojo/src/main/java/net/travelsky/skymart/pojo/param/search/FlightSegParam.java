  
package net.travelsky.skymart.pojo.param.search;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 *  查询的航段信息
    * @ClassName: FlightSeg  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月12日  
    *
 */
@Getter
@Setter
@ToString
public class FlightSegParam {
	/** 出发日期 */
	private String depDate;
	/** 出发城市三字码 */
	private String depCityCode;
	/** 到达城市三字码 */
	private String arrCityCode;
	/** 航段序号 0开始 */
	private Integer segNo;
	/** 航程类型（G-去程，R-回程） */
	private String setType;
}
