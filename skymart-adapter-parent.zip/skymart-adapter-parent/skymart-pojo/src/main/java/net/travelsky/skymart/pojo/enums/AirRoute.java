 
package net.travelsky.skymart.pojo.enums;

  
/**
 *  航线分类（国际国内）
    * @ClassName: AirRoute  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月13日  
    *
 */
public enum AirRoute {

	internationality("I"),  // 国际
	domestic("D");			// 国内
	
	private String value;
	private AirRoute(String value){
		this.value = value;
	} 
	public String getValue() {
		return this.value;
	}
}
