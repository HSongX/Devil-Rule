package net.travelsky.skymart.pojo.domain;
import java.util.*;

import lombok.Data;
import lombok.ToString;
@Data
@ToString
public class DtcFlightSegmentEntity{
	private String crawlerid;
	private String groups;
	private Date createtime;
	private Date updatetime;
	private String remarks;
	private String id;
	private String origincity;
	private String destinationcity;
	private String flightdate;
	private String sourse;
	private String thirdsource;
	private String area;
}
