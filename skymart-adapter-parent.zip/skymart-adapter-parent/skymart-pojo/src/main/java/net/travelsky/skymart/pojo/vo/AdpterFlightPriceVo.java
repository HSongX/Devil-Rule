
package net.travelsky.skymart.pojo.vo;

import lombok.Data;
import lombok.ToString;

/**
 *  航班价格信息实体对象
    * @ClassName: AdpterFlightPrice  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月13日  
    *
 */
@Data
@ToString
public class AdpterFlightPriceVo implements java.io.Serializable{  

	private static final long serialVersionUID = -6729131831150292243L;
	//仓位code
	private String cabin_code;
	/** 票面价格	接口传递得票面价格 */
	private String ticketPrice;
	/** 销售参考价	如果没有等同于票面价格 */
	private String originalPrice;
	/** 内部价格	如果没有等同于票面价格 */
	private String intereiorPrice;
	/** 全价 */
	private String overheadPrice;
	/** 价格类型 (ADT:大人/CHD:小孩/INF:婴儿) */
	private String priceType;
	/** 燃油附加费 */
	private String yoTax;
	/** 机场建设费 */
	private String cnTax;
	/** 其他税费  默认0 */
	private String extra;
	/** 折扣率（百分比） */
	private String discount;
	/** 票面价格是否包含机场建设费	默认false */
	private Boolean containAirportFee;
	/** 票面价格是否包含燃油附加费	默认false */
	private Boolean containFuelFee;
	/** 票面价格是否包含其他税费	默认false */
	private Boolean containTax; 
	/** 币种 */
	private String currency;
	/** 退改政策信息 (默认空字符串) */
	private String refundedComment;
	/** 改签政策信息*/
	private String cangedComment;
	/** 是否可以升仓(默认true)*/
	private Boolean updateFlag;
	/** 是否可以退票(默认true)*/
	private Boolean refundFlag;
	/** 免费改期次数(0标识无限次-1标识没有免费改期（默认0）) */
	private Integer freeChangeTimes;
	/** 是否可改签 */
	private Boolean changeAirLineFlag;
	/** 运价唯一编号 */
	private String priceId;
}
