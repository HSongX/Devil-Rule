package net.travelsky.skymart.pojo.domain;


import lombok.Data;
import lombok.ToString;

/**
 *  返回原始数据实体
    * @ClassName: FlightFromDB  
    * @Description: TODO  
    * @author HS 
    * @date 2018年11月13日  
    *
 */
@Data
@ToString
public class FlightFromDB {
	//航线id
	 private String segment_id;
	 private String cba_id;
     private String far_id;
     private String pro_id;
     private String tar_id;
	 //起飞城市三字码
     private String ORIGIN_CITY ;
     //到达城市三字码
     private String DESTINATION_CITY ;
     //航班日期
     private String FLIGHT_DATE;
     //数据来源
     private String sourse;
     //仓位代码
     private String cabin_code;
     //仓位类型
     private String cabin_class;
     //仓位可销售数
     private String inventory;
     //票面价格
     private String ticket_price;
     //销售参考价
     private String original_price;
     //内部价格
     private String interior_price;
     //价格类型
     private String price_type;
     //其他税费
     private String extra;
     //燃油费
     private String YQ_TAX;
     //机建费
     private String CN_TAX;
     //折扣率
     private String DISCOUNT;
     //票面是否含机建
     private String contain_airport_fee;
     //票面是否含燃油
     private String contain_fuel_fee;
     //票面是否包含税费
     private String contain_tax;
     //币种
     private String currency;
     //退改政策信息
     private String refunded_changed_comment;
     //是否可退票
     private String REFUND_FLAG;
     //免费可改签次数
     private Integer FREE_CHANGE_TIMES;
     //是否可改签
     private String CHANGE_AIRLINE_FLAG;
     //是否可升舱
     private String Update_FLAG;
     //行程id
     private String segment_detail_id;
     //起飞机场三字码
     private String dep_airport;
     //起飞航站楼
     private String dep_terminal;
     //到达机场三字码
     private String arr_airport;
     //到达航站楼
     private String arr_terminal;
     //起飞时间
     private String dep_time;
     //到达时间
     private String arr_time;
     //航空公司二字码
     private String airline;
     //航空公司名称
     private String airline_name;
     //起飞日期
     private String arr_date;
     //到达日期
     private String dep_date;
     //飞行时长
     private String journey_time;
     //中途滞留时长
     private String layover_time;
     //是否跨天
     private String next_day;
     //航段序号
     private Integer seq;
     //航班号
     private String flight_no;
     //机型
     private String plane_type;
     //是否共享航班
     private String shared;
     //承运方名称
     private String carrier_name;
     //实际承运航班号
     private String carrier_flight_no;                        
}