
package net.travelsky.skymart.pojo;

  
/**
 *  所有实体对象的父类
    * @ClassName: BaseEntity  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
public class BaseVo implements java.io.Serializable{

	private static final long serialVersionUID = 5509716272700210715L;

}
