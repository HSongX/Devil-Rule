package net.travelsky.skymart.pojo.entity;

import java.math.BigDecimal;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class DtcAirportInfoEntity{
	private BigDecimal id;
	/** 机场代码 */
	private String airportcode;
	/** 城市代码 */
	private String citycode;
	/** 城市中文名 */
	private String cityzhname;
	/** 城市英文名 */
	private String cityenname;
	/** 国家 */
	private String country;
	/** 机场中文名字 */
	private String airportname;
}
