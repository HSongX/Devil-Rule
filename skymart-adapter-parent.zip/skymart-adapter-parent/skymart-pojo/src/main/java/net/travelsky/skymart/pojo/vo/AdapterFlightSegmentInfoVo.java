
package net.travelsky.skymart.pojo.vo;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.ToString;

/**
 *  航班基础信息 
    * @ClassName: AdapterFlightSegmentInfoVo  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月13日  
    *
 */
@Data
@ToString
public class AdapterFlightSegmentInfoVo implements java.io.Serializable{

	private static final long serialVersionUID = 1775656193907618106L;
	
	/** 航班仓位价格 */
	private List<AdapterFlightCabinVo> cabins = new ArrayList<AdapterFlightCabinVo>();
	
	/** 航班飞行航段信息集合 */
	private List<AdapterFlightTransitVo> transits = new ArrayList<AdapterFlightTransitVo>();
	
	/** 航班飞行详细信息 */
	private AdapterFlightSegmentDetailsVo segMentDetails = new AdapterFlightSegmentDetailsVo();
	private String segment_detail_id ; //航班id
	
}
