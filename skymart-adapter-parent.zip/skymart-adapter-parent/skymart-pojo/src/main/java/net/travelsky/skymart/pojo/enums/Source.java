  

package net.travelsky.skymart.pojo.enums;

  
/**
 *  数据来源的枚举类
    * @ClassName: SourceType  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月13日  
    *
 */
public enum Source {

	GF("GF"),	// 广分数据来源
	YC("YC"),	// 驿程数据来源
	ALL("ALL");	// 全部数据来源
	
	private String value;
	private Source(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return this.value;
	}
}
