package net.travelsky.skymart.config.web;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

/**
 * 
    * @ClassName: ViewResolversConfig  
    * @Description: 请求视图映射相关配置，不同的工程模块，应该有自己的映射方式，独立配置  
    * @author CY  
    * @date 2018年7月24日  
    *
 */
@Configuration
public class ViewResolversConfig implements WebMvcConfigurer{

	/**
     * 配置html 视图解析器 请求视图映射
     * @return
     */
    @Bean
    public InternalResourceViewResolver resourceViewResolver()
    {
        InternalResourceViewResolver internalResourceViewResolver = new InternalResourceViewResolver();
        // 请求视图文件的前缀地址
        internalResourceViewResolver.setPrefix("/WEB-INF/views/");
        // 请求视图文件的后缀
        internalResourceViewResolver.setSuffix(".html");
        // 配置优先级
        internalResourceViewResolver.setOrder(1);
        return internalResourceViewResolver;
    }
    
    /**
     * 注册视图映射
     */
	@Override
	public void configureViewResolvers(ViewResolverRegistry registry) {			
	    WebMvcConfigurer.super.configureViewResolvers(registry);
	    registry.viewResolver(resourceViewResolver());
	    	
	}

	
}
