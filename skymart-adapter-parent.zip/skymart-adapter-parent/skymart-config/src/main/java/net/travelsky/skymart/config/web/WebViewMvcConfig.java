package net.travelsky.skymart.config.web;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 
    * @ClassName: WebViewMvcConfig  
    * @Description: 启动webmvc 视图解析  
    * @author CY  
    * @date 2018年7月25日  
    *
 */
@Configuration
@EnableWebMvc
public class WebViewMvcConfig implements WebMvcConfigurer{
	/**
	 * 配置启用 dispatcherServlet 方式进行处理 解析，自动匹配
	 */
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		WebMvcConfigurer.super.configureDefaultServletHandling(configurer);
		configurer.enable();
	}

}
