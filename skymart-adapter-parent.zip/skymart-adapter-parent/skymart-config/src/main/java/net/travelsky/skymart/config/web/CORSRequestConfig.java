package net.travelsky.skymart.config.web;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CORSRequestConfig implements WebMvcConfigurer {

	/**
	 * CORS可以分成两种：
	 * 	简单请求
	 * 	复杂请求
	 *  
	 * 一个简单的请求大致如下：
	 * 
	 * HTTP方法是下列之一 HEAD GET POST 
	 * 
	 * HTTP头包含 Accept Accept-Language Content-Language
	 * Last-Event-ID Content-Type
	 * 
	 * 但仅能是下列之一 
	 * application/x-www-form-urlencoded
	 * multipart/form-data 
	 * text/plain
	 */
	@Override
	public void addCorsMappings(CorsRegistry registry) {

		registry
				/**
				 * 所有请求都允许跨域
				 */
				.addMapping("/**")
				/**
				 * 所有控制器的方法都允许跨域
				 */
				.allowedMethods("*")
				/**
				 * 所有的简单请求都允许跨域
				 */
				.allowedOrigins("*")
				/**
				 * 带有（access-control-allow-headers头）的请求
				 * 都呗允许跨域
				 */
				.allowedHeaders("*");
		/**
		 * 设置跨域请求处理，允许路径
		 */
		WebMvcConfigurer.super.addCorsMappings(registry);
//        registry.addMapping("/**")	// 允许所有URL跨域
//        .allowedOrigins("*")	// 允许所有的访问源
//        .allowCredentials(true).allowedHeaders("Origin, X-Requested-With, Content-Type, Accept")
//        .allowedMethods("GET", "POST", "DELETE", "PUT", "OPTIONS")
//        .maxAge(3600);
	}

}
