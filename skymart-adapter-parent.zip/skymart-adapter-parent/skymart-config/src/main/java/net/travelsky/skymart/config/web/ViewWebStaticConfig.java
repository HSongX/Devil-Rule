package net.travelsky.skymart.config.web;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 
    * @ClassName: ViewWebStaticConfig  
    * @Description: 静态资源配置  
    * @author CY  
    * @date 2018年7月24日  
    *
 */
@Configuration
public class ViewWebStaticConfig implements WebMvcConfigurer{

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/static/**").addResourceLocations("classpath:/static/");
		WebMvcConfigurer.super.addResourceHandlers(registry);
	}

}
