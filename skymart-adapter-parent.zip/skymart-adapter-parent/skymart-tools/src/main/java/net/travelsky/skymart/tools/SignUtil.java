package net.travelsky.skymart.tools;

import java.net.URLEncoder;

/**
 * 用来验证签名
 * @author hqz
 *
 */
public class SignUtil {
	/**
	 * Logger for this class
	 */
	public static String  getSign(String xml,String action,String key){
		
		String sys_sign="";
		try {
			String encode=URLEncoder.encode(xml+action+key, "UTF-8");
			 sys_sign=MD5Util.MD5(encode.toUpperCase());
		} catch (Exception e) {
		}
		return sys_sign;
	}
}
