  
/**
 * 这个类用来处理日期相关的共通工具类    
 * @Title: DateTimeTools.java  
 * @Package net.travelsky.skymart.tools  
 * @Description: TODO  
 * @author CY  
 * @date 2018年9月20日  
 * @version V1.0    
 */     
package net.travelsky.skymart.tools;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**  
 * 这个类是日期与时间处理相关的共通方法
 * @ClassName: DateTimeTools  
 * @Description: TODO  
 * @author CY  
 * @date 2018年9月20日  
 *    
 */
public class DateTimeTools {
	
	public static final String DEFAULT_PATTERN ="yyyy-MM-dd HH:mm:ss";
	
	public static final String SHOFT_PATTERN = "yyyy-MM-dd";
	
	/**
	 *  传递一个参数日期对象，获取这个日期对象的时间部分
	    * @Title: getTime  
	    * @Description: TODO  
	    * @param @param dt
	    * @param @return
	    * @return String 返回格式：HH:mm:dd
	    * @throws
	 */
	public static String getTime(Date dt) {
		String date = toString(dt);
		date = date.substring(10, date.length());
		return date.trim();
	}
	
	/**
	 *  传递一个参数日期对象，获取这个日期对象的年月日部分
	    * @Title: getDate  
	    * @Description: TODO  
	    * @param @param dt
	    * @param @return
	    * @return String 返回格式：2018-08-08
	    * @throws
	 */
	public static String getDate(Date dt) {
		String date = toString(dt);
		date = date.substring(0, 10);
		return date.trim();
	}
	
	/**
	 * 根据参数的开始与结束日期对象，得到这个日期的（天/时/分）差 
	 * 
	    * @Title: getTimeDifference  
	    * @Description: TODO  
	    * @param @param start
	    * @param @param end
	    * @param @return
	    * @return String 返回格式：03h05m （03小时05分）
	    * @throws
	 */
	public static String getTimeDifference(Date min, Date max) {
		long hour = getHourDifference(min,max);
		long minute = getMinuteDefference(min,max);
		return "PT"+((hour > 10) ? (""+hour) : ("0"+hour)) + "H" + ((minute > 10) ? (""+minute) : ("0"+minute)) + "M";	
	}
	
	/**
	 * 计算两个日期的分钟差
	    * @Title: getMimuteDefference  
	    * @Description: TODO  
	    * @param @param min
	    * @param @param max
	    * @param @return
	    * @return long
	    * @throws
	 */
	public static long getMinuteDefference(Date min,Date max) {
		long sTime = min.getTime();
		long eTime = max.getTime();
		long time = eTime - sTime;
		//计算出小时数
		long leave1=time%(3600*1000);    //计算小时后剩余的毫秒数
		//计算相差分钟数
		long minutes=leave1/(60*1000);
		return minutes;
	}
	
	/**
	 * 计算两个日期的小时差
	    * @Title: getHourDifference  
	    * @Description: TODO  
	    * @param @param start
	    * @param @param end
	    * @param @return
	    * @return String
	    * @throws
	 */
	public static long getHourDifference(Date min, Date max) {
		long sTime = min.getTime();
		long eTime = max.getTime();
		long time = eTime - sTime;
		long hours=(time/(3600*1000));
		return hours;
	}
	
	/**
	 * 计算两个日期的天数差
	    * @Title: getDayDifference  
	    * @Description: TODO  
	    * @param @param start
	    * @param @param end
	    * @param @return
	    * @return String 返回格式：1d
	    * @throws
	 */
	public static String getDayDifference(Date min, Date max) {
		return String.valueOf((getHourDifference(min,max) % 24));
	}
	
	/**
	 *  日期对象返回参数提供的格式
	    * @Title: toString  
	    * @Description: TODO  
	    * @param @param dt
	    * @param @param perent
	    * @return void
	    * @throws
	 */
	public static String toString(Date dt, String pattern) {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(dt);
	}
	
	/**
	 * 格式化日期对象为默认格式
	    * @Title: formart  
	    * @Description: TODO  
	    * @param @param dt
	    * @param @return
	    * @return String  返回格式：yyyy-MM-dd HH:mm:ss
	    * @throws
	 */
	public static String toString(Date dt) {
		return toString(dt,DEFAULT_PATTERN);
	}
	
	/**
	 * 将一个字符串转换日历对象
	    * @Title: toCalendar  
	    * @Description: TODO  
	    * @param @param date
	    * @param @param pattern
	    * @param @return
	    * @return Calendar
	    * @throws
	 */
	public static Calendar toCalendar(String date, String pattern) {
		Calendar cal = Calendar.getInstance();
		try {
			cal.setTime(new SimpleDateFormat(pattern).parse(date));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return cal;
	}
	
	/**
	 * 将一个日期对象转换日历对象
	    * @Title: toCalendar  
	    * @Description: TODO  
	    * @param @param date
	    * @param @param pattern
	    * @param @return
	    * @return Calendar
	    * @throws
	 */
	public static Calendar toCalendar(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal;
	}
	
	public static void main(String[] args) throws ParseException {
//		String s1 = "2018-09-20 14:00:00";
//		String s2 = "2018-09-21 14:09:00";
//		Date d1 = new SimpleDateFormat(DEFAULT_PATTERN).parse(s1);
//		Date d2 = new SimpleDateFormat(DEFAULT_PATTERN).parse(s2);
//		System.out.println((DateTimeTools.getTimeDifference(d1,d2)) + "");
		String s1 = "2018-09-20 14:00:00";
		System.out.println(new SimpleDateFormat(SHOFT_PATTERN).format(DateTimeTools.toCalendar(s1, DEFAULT_PATTERN).getTime()));
	}

}

