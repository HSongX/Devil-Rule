  
    /**    
    * @Title: JSONUtil.java  
    * @Package net.travelsky.skymart.common.util  
    * @Description: TODO  
    * @author CY  
    * @date 2018年10月11日  
    * @version V1.0    
    */  
    
package net.travelsky.skymart.tools;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**  JSON 格式转换
    * @ClassName: JSONUtil  
    * @Description: TODO  
    * @author CY  
    * @date 2018年10月11日  
    *    
    */
public class JSONUtil {
	
	private static Logger log = LoggerFactory.getLogger(JSONUtil.class);
	private static ObjectMapper om = new ObjectMapper()
	        .setSerializationInclusion(Include.NON_NULL)
	        .enable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
	        .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
	        .enable(MapperFeature.USE_ANNOTATIONS);

	/**
	 * 将JSON字符串转换为对象
	 *
	 * @param json      JSON字符串
	 * @param valueType 对象类型
	 *
	 * @return 对象
	 */
	public static <T> T toObject(String json, Class<T> valueType) {
	    try {
	        return om.readValue(json, valueType);
	    } catch (Exception e) {
	    	log.error("ERROR:", e);
	    }
	    return null;
	}
	
	/**
	 *  将json字符串集合类型转换为arrayList对象
	    * @Title: toList  
	    * @Description: TODO  
	    * @param @param json
	    * @param @param valueType
	    * @param @return
	    * @return List<T>
	    * @throws
	 */
	public static <T> List<T> toList(String json, Class<T> valueType){
	    try {
	    	JavaType javaType = om.getTypeFactory().constructParametricType(List.class , valueType);
	        return om.readValue(json, javaType);
	    } catch (Exception e) {
	    	log.error("ERROR:", e);
	    }
	    return null;
	}

	
	/**
	 * 将对象转换为JSON字符串
	 *
	 * @param value 对象
	 *
	 * @return JSOn字符串
	 */
	public static String toJson(Object value) {
	    try {
	        return om.writeValueAsString(value);
	    } catch (Exception e) {
	        log.error("ERROR:", e);
	    }
	    return null;
	}

}
