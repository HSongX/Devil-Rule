package net.travelsky.skymart.config.datasource;

import java.util.Properties;
import javax.sql.DataSource;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import com.github.pagehelper.PageHelper;

/**
 * 
    * @ClassName: DuridAdminDataSourceConfig  
    * @Description: 配置MyBatis 多数据源支持,使得不同的应用模块使用自己的数据源配置  
    * @author CY  
    * @date 2018年7月23日  
    *
 */
@Configuration
@MapperScan(basePackages = "net.travelsky.skymart.repository", sqlSessionTemplateRef  = "sqlSessionTemplate")
public class DuridAuthDataSourceConfig {
	
	/**
	 * 
	    * @Title: dataSource  
	    * @Description: 通过配置文件，构建dataSource对象  
	    * @return DataSource
	    * @throws
	 */
    @Bean(name = "dataSource")
    @ConfigurationProperties(prefix = "spring.datasource.druid-adapter")
    @Primary
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }
    
    /**
     * 
        * @Title: sqlSessionFactory  
        * @Description: 注入dataSource 到sessionFactory中  
        * @param dataSource
        * @param @throws Exception
        * @return SqlSessionFactory
        * @throws
     */
    @Bean(name = "sqlSessionFactory")
    @Primary
    public SqlSessionFactory sqlSessionFactory(@Qualifier("dataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        //分页插件
        PageHelper pageHelper = new PageHelper();
        Properties properties = new Properties();
        properties.setProperty("offsetAsPageNum", "true");
        properties.setProperty("rowBoundsWithCount", "true");
        properties.setProperty("reasonable", "true");
        properties.setProperty("supportMethodsArguments", "true");
        properties.setProperty("returnPageInfo", "check");
        properties.setProperty("params", "pageNum=page;pageSize=rows;orderBy=orderBy");
        pageHelper.setProperties(properties);
        //添加插件
        bean.setPlugins(new Interceptor[]{pageHelper});
        bean.setDataSource(dataSource);
        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mapper/*.xml"));
        return bean.getObject();
    }
    
    /**
     * 
        * @Title: transactionManager  
        * @Description: 开始这个dataSource的事务机制  
        * @param dataSource
        * @return DataSourceTransactionManager
        * @throws
     */
    @Bean(name = "transactionManager")
    @Primary
    public DataSourceTransactionManager transactionManager(@Qualifier("dataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    /**
     * 
        * @Title: sqlSessionTemplate  
        * @Description: 构建mybatis的sessionTemplate模板  
        * @param sqlSessionFactory
        * @param @throws Exception
        * @return SqlSessionTemplate
        * @throws
     */
    @Bean(name = "sqlSessionTemplate")
    @Primary
    public SqlSessionTemplate sqlSessionTemplate(@Qualifier("sqlSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception {
    	return new SqlSessionTemplate(sqlSessionFactory);
    }
    
}
