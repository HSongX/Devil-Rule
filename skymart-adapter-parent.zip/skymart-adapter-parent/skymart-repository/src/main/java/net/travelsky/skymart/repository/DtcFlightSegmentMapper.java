package net.travelsky.skymart.repository;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import net.travelsky.skymart.pojo.domain.DtcFlightSegmentEntity;
import net.travelsky.skymart.pojo.domain.FlightFromDB;
import net.travelsky.skymart.pojo.param.search.FlightSegParam;
/**
 * 
    * @ClassName: DtcFlightSegmentMapper  
    * @Description:
    * @author AUTO  
    * @date ${createDate} 
    *
 */
public interface DtcFlightSegmentMapper {
	List<FlightFromDB> queryBySegParam(@Param(value="flightSegParam")FlightSegParam flightSegParam);
}