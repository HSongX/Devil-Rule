
package net.travelsky.skymart.config.datasource;

import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;

/**
 *  实例化对象加载器
    * @ClassName: LoadBeanConfig  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月1日  
    *
 */
@Configuration
public class DataSourceConfig{

	/**
	 *  加载外部YML
	    * @Title: properties  
	    * @Description: TODO  
	    * @param @return
	    * @return PropertySourcesPlaceholderConfigurer
	    * @throws
	 */
	@Bean
	@Primary
	public static PropertySourcesPlaceholderConfigurer properties() {
		PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
		YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
		//yaml.setResources(new FileSystemResource("config.yml"));//File引入
		yaml.setResources(new ClassPathResource("dataSource.yml"));//class引入
		configurer.setIgnoreUnresolvablePlaceholders(true);
		configurer.setProperties(yaml.getObject());
		return configurer;
	}

}
