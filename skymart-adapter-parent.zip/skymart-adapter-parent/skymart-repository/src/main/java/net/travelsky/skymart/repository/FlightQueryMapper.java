package net.travelsky.skymart.repository;
/**
 *  getDataByParam
    * @ClassName: GetData  
    * @Description: TODO  
    * @author HS  
    * @date 2018年11月13日  
    *
 */
import java.util.List;

import net.travelsky.skymart.pojo.domain.FlightFromDB;
import net.travelsky.skymart.pojo.param.search.FlightSegParam;

public interface FlightQueryMapper {
	public List<FlightFromDB> queryByParam(FlightSegParam flightSegParam); 
}