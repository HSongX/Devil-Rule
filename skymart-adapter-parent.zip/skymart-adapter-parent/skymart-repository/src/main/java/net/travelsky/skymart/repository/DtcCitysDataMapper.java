package net.travelsky.skymart.repository;

import java.util.List;
import net.travelsky.skymart.code.mybatis.Parameter;
import net.travelsky.skymart.pojo.entity.DtcCitysDataEntity;
/**
 * 
    * @ClassName: DtcCitysDataMapper  
    * @Description:
    * @author AUTO  
    * @date ${createDate} 
    *
 */
public interface DtcCitysDataMapper {
	
	List<DtcCitysDataEntity> searchList(Parameter param); 
}