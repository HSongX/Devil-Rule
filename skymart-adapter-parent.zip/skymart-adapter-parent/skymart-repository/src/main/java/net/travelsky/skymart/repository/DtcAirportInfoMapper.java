package net.travelsky.skymart.repository;

import java.util.List;
import net.travelsky.skymart.code.mybatis.Parameter;
import net.travelsky.skymart.pojo.entity.DtcAirportInfoEntity;
/**
 * 
    * @ClassName: DtcAirportInfoMapper  
    * @Description:
    * @author AUTO  
    * @date ${createDate} 
    *
 */
public interface DtcAirportInfoMapper {
	
	List<DtcAirportInfoEntity> searchList(Parameter param); 
}