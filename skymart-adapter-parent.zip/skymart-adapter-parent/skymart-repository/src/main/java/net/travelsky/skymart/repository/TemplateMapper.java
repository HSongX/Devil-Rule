  

package net.travelsky.skymart.repository;

/**
 *  测试用的mapper
    * @ClassName: TemplateMapper  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
public interface TemplateMapper {
	public void insert(); 
}
