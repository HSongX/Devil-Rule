 
package net.travelsky.skymart.api.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import net.travelsky.skymart.business.factory.AdapterServiceFactoryBuilder;
import net.travelsky.skymart.business.message.MessageCode;
import net.travelsky.skymart.business.server.IFlightQueryFromDBService;
import net.travelsky.skymart.code.enums.ResultCode;
import net.travelsky.skymart.code.result.ResultEntity;
import net.travelsky.skymart.code.result.ResultEntityUtil;
import net.travelsky.skymart.config.TDCConfig;
import net.travelsky.skymart.pojo.domain.DtcFlightSegmentEntity;
import net.travelsky.skymart.pojo.domain.FlightFromDB;
import net.travelsky.skymart.pojo.param.CommonEntity;
import net.travelsky.skymart.pojo.param.search.FlightSearchParam;
import net.travelsky.skymart.pojo.param.search.FlightSegParam;
import net.travelsky.skymart.pojo.vo.AdapterFlightInfoVo;

/**
 *  航班查询测试
 */
@RestController
@RequestMapping("/tm/flightTest")
public class FlightQueryController {
	
	@Autowired private IFlightQueryFromDBService iFlightQueryFromDBService;
	
	@PostMapping(value = "flightQuery", produces = "application/json;charset=utf-8")
	@ResponseBody
	//根据flightSegParam查询
	public AdapterFlightInfoVo flightQuery(FlightSegParam fSegParam) {
		AdapterFlightInfoVo finalobj = iFlightQueryFromDBService.queryBySegParam(fSegParam);
		return finalobj;
	}
}