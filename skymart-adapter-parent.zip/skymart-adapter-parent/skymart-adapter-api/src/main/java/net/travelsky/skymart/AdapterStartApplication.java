package net.travelsky.skymart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;


/**
 *  系统启动类
    * @ClassName: AdapterStartApplication  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
@SpringBootApplication	
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})
public class AdapterStartApplication extends SpringBootServletInitializer {

    public static void main( String[] args ){
    	SpringApplication.run(AdapterStartApplication.class, args);
    }
    
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(this.getClass());
    }
}
