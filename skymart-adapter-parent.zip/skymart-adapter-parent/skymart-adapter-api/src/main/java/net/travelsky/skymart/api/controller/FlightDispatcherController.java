 
package net.travelsky.skymart.api.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import net.travelsky.skymart.business.factory.AdapterServiceFactoryBuilder;
import net.travelsky.skymart.business.message.MessageCode;
import net.travelsky.skymart.code.enums.ResultCode;
import net.travelsky.skymart.code.result.ResultEntity;
import net.travelsky.skymart.code.result.ResultEntityUtil;
import net.travelsky.skymart.config.TDCConfig;
import net.travelsky.skymart.pojo.param.CommonEntity;

/**
 *  航班查询API控制器
    * @ClassName: FlightSearchController  
    * @Description: TODO  
    * @author CY  
    * @date 2018年11月9日  
    *
 */
@RestController
@RequestMapping("/tm/flight")
public class FlightDispatcherController {
	
	@Autowired private AdapterServiceFactoryBuilder sfb;
	
	@Autowired private TDCConfig config;
	
	@PostMapping(value = "dispatcher", produces = "application/json;charset=utf-8")
	public ResultEntity execute(@RequestBody CommonEntity data) {
		/** 验证参数 */
		if(null == data) {
			return ResultEntityUtil.getEntity(
					ResultCode.FAIL, 
					MessageCode.Param.CODE_10020.getKey(), 
					MessageCode.Param.CODE_10020.getValue());
		}
		/**
		 * 以下验证，通过拦截器进行拦截验证
		 * 1.验证提交参数
		 * 2.验证用户名
		 * 3.验证签名
		 */
		System.out.println(config);
		ResultEntity bv = sfb.resolver(data).build().end();
		return bv;
	}
}
