package net.travelsky.skymart.vo.flight;

import java.util.ArrayList;
import java.util.List;

public class FlightListResultVo {

	// 航班检索返回结果结构
	private List<FlightList> list = new ArrayList<FlightList>();

	public List<FlightList> getList() {
		return list;
	}

	public void setList(List<FlightList> list) {
		this.list = list;
	}

}
