   
package net.travelsky.skymart.config;

  
/**
 *  请求得控制器地址
    * @ClassName: Action  
    * @Description: TODO  
    * @author CY  
    * @date 2018年10月9日  
    *
 */
public enum TDCAction {
    /** 航班查询 */
    ACTION_AV("flight.av"),
    /** 下单 */
    ACTION_CREATE("flight.create.order"),
    /** 查询订单 */
    ACTION_QUERY_ORDER("flight.query.order"),
    /** 支付 */
    ACTION_PAY("flight.pay"),
    /** 取消订单 */
    ACTION_CANCEL("flight.cancel.order"),
    /** 改升查询 */
    ACTION_UPGRADE_SEARCH("flight.upgrade.search"),
    /** 改升操作 */
    ACTION_UPGRADE_OPERATOR("flight.upgrade.operator"),
    /** 退票税费查询 */
    ACTION_QUERY_REFUND_COST("flight.query.refund.cost"),
    /** 退票状态 */
    ACTION_QUERY_REFUND("flight.query.refund"),
    /** 退票确认 */
    ACTION_VALIDATION_REFUND("flight.validation.refund");
	
	private String value;
	private TDCAction(String value) {
		this.value = value;
	}
	public String getValue() {
		return this.value;
	}
}
