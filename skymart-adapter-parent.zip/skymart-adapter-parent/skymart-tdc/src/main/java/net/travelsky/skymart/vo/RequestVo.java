
package net.travelsky.skymart.vo;


/**
 * @ClassName RequestVo
 * @Description 请求参数
 * @author xu-bing
 * @date 2018年10月9日 上午9:11:25
 */
public class RequestVo<T> {
    /** 网关支付请求参数（业务参数） */
    private T inBean;
    /** 合作用户名 */
    private String userName;
    /** 用户名 */
    private String appusername;

	public RequestVo() {
		super();
	}

	public RequestVo(T inBean) {
		super();
		this.inBean = inBean;
	}

	public T getInBean() {
		return inBean;
	}

	public void setInBean(T inBean) {
		this.inBean = inBean;
	}

	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAppusername() {
		return appusername;
	}

	public void setAppusername(String appusername) {
		this.appusername = appusername;
	}
    

}
