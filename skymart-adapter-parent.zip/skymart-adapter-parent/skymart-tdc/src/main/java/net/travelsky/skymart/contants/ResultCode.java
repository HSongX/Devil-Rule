  
 
package net.travelsky.skymart.contants;

  
/**
 *  成功或失败返回结果
    * @ClassName: ResultCode  
    * @Description: TODO  
    * @author CY  
    * @date 2018年10月11日  
    *
 */
public interface ResultCode {

	static final String SUCCESS = "SUCCESS";
	static final String ERROR = "ERROR";
	static final String FAIL = "FAIL";
}
