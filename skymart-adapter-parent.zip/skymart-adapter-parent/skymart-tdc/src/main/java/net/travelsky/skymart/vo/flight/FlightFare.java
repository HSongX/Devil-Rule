package net.travelsky.skymart.vo.flight;

import java.io.Serializable;

public class FlightFare implements Serializable{
	
	private static final long serialVersionUID = 7573225758429615838L;
	//运价id
	private String priceId;
	//票面价格
	private String marketFare;
	//燃油税
	private String yqTax;
	//机建费
	private String cnTax;
	//运价基础
	private String fareBasisCode;
	//旅行代码
	private String tourCode;
	//折扣率
	private String discount;
	//行李重量
	private String baggage;
	//销售参考价
	private String rsp;
	//是否可退票
	private boolean refundedFlag;
	//退票政策描述
	private String refundedComment;
	//变更政策描述
	private String changedComment;
	//是否可免费改期
	private boolean rescheduledFlag;
	//免费改期次数
	private Integer freeChangeTimes;
	//是否可改签
	private boolean changeAirLineFlag;
	//是否可升舱
	private boolean upgradeFlag;
	//经济舱公布运价全价金额
	private String efPrice;
	//运价编号
	private String fareId;
	//运价验证串
	private String fareSign;
	//ei信息
	private String eiMsg;
	public String getPriceId() {
		return priceId;
	}
	public void setPriceId(String priceId) {
		this.priceId = priceId;
	}
	public String getMarketFare() {
		return marketFare;
	}
	public void setMarketFare(String marketFare) {
		this.marketFare = marketFare;
	}
	public String getYqTax() {
		return yqTax;
	}
	public void setYqTax(String yqTax) {
		this.yqTax = yqTax;
	}
	public String getCnTax() {
		return cnTax;
	}
	public void setCnTax(String cnTax) {
		this.cnTax = cnTax;
	}
	public String getFareBasisCode() {
		return fareBasisCode;
	}
	public void setFareBasisCode(String fareBasisCode) {
		this.fareBasisCode = fareBasisCode;
	}
	public String getTourCode() {
		return tourCode;
	}
	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public String getBaggage() {
		return baggage;
	}
	public void setBaggage(String baggage) {
		this.baggage = baggage;
	}
	public String getRsp() {
		return rsp;
	}
	public void setRsp(String rsp) {
		this.rsp = rsp;
	}
	public boolean isRefundedFlag() {
		return refundedFlag;
	}
	public void setRefundedFlag(boolean refundedFlag) {
		this.refundedFlag = refundedFlag;
	}
	public String getRefundedComment() {
		return refundedComment;
	}
	public void setRefundedComment(String refundedComment) {
		this.refundedComment = refundedComment;
	}
	public String getChangedComment() {
		return changedComment;
	}
	public void setChangedComment(String changedComment) {
		this.changedComment = changedComment;
	}
	public boolean isRescheduledFlag() {
		return rescheduledFlag;
	}
	public void setRescheduledFlag(boolean rescheduledFlag) {
		this.rescheduledFlag = rescheduledFlag;
	}
	public Integer getFreeChangeTimes() {
		return freeChangeTimes;
	}
	public void setFreeChangeTimes(Integer freeChangeTimes) {
		this.freeChangeTimes = freeChangeTimes;
	}
	public boolean isChangeAirLineFlag() {
		return changeAirLineFlag;
	}
	public void setChangeAirLineFlag(boolean changeAirLineFlag) {
		this.changeAirLineFlag = changeAirLineFlag;
	}
	public boolean isUpgradeFlag() {
		return upgradeFlag;
	}
	public void setUpgradeFlag(boolean upgradeFlag) {
		this.upgradeFlag = upgradeFlag;
	}
	public String getEfPrice() {
		return efPrice;
	}
	public void setEfPrice(String efPrice) {
		this.efPrice = efPrice;
	}
	public String getFareId() {
		return fareId;
	}
	public void setFareId(String fareId) {
		this.fareId = fareId;
	}
	public String getFareSign() {
		return fareSign;
	}
	public void setFareSign(String fareSign) {
		this.fareSign = fareSign;
	}
	public String getEiMsg() {
		return eiMsg;
	}
	public void setEiMsg(String eiMsg) {
		this.eiMsg = eiMsg;
	}
	
	
}
