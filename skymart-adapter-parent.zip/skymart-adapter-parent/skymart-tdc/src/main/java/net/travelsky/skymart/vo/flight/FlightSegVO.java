package net.travelsky.skymart.vo.flight;

/**
 * 航段信息
 * @author Eli
 * @version $Id: FlightSegVO.java, v 0.1 2018-1-15 下午6:05:25 Eli Exp $
 */
public class FlightSegVO {
    /**  出发城市*/
    private String  originCity;
    /** 到达城市 */
    private String  destinationCity;
    /**  出发机场*/
    private String  depAirport;
    /** 到达机场 */
    private String  arrAirport;
    /** 查询日期(yyyy-MM-dd) */
    private String  searchDate;
    /** 航段类别(G-去程，R-回程) */
    private String  segTp;
    /** 航段序号(从0开始) */
    private Integer segSq;

    public String getOriginCity() {
        return originCity;
    }

    public void setOriginCity(String originCity) {
        this.originCity = originCity;
    }

    public String getDestinationCity() {
        return destinationCity;
    }

    public void setDestinationCity(String destinationCity) {
        this.destinationCity = destinationCity;
    }

    public String getDepAirport() {
        return depAirport;
    }

    public void setDepAirport(String depAirport) {
        this.depAirport = depAirport;
    }

    public String getArrAirport() {
        return arrAirport;
    }

    public void setArrAirport(String arrAirport) {
        this.arrAirport = arrAirport;
    }

    public String getSearchDate() {
        return searchDate;
    }

    public void setSearchDate(String searchDate) {
        this.searchDate = searchDate;
    }

    public String getSegTp() {
        return segTp;
    }

    public void setSegTp(String segTp) {
        this.segTp = segTp;
    }

    public Integer getSegSq() {
        return segSq;
    }

    public void setSegSq(Integer segSq) {
        this.segSq = segSq;
    }

}
