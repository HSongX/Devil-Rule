package net.travelsky.skymart.vo.flight;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author Eli
 * @version $Id: ToAvSearchRequestVO.java, v 0.1 2018-1-15 下午6:00:42 Eli Exp $
 */
public class ToAvSearchVO {

	/** 航程种类(OW单程/RT往返) */
	private String routeType;
	/** 运价种类(I国际/D国内) */
	private String fareType;
	/** 中转方案 only HO now */
	private String direct;
	/** 航司配置信息 */
	private Map<String, String> customerInfos;
	/** 航段相关信息 */
	private List<FlightSegVO> flightSegs;

	public String getRouteType() {
		return routeType;
	}

	public void setRouteType(String routeType) {
		this.routeType = routeType;
	}

	public String getFareType() {
		return fareType;
	}

	public void setFareType(String fareType) {
		this.fareType = fareType;
	}

	public String getDirect() {
		return direct;
	}

	public void setDirect(String direct) {
		this.direct = direct;
	}

	public Map<String, String> getCustomerInfos() {
		return customerInfos;
	}

	public void setCustomerInfos(Map<String, String> customerInfos) {
		this.customerInfos = customerInfos;
	}

	public List<FlightSegVO> getFlightSegs() {
		return flightSegs;
	}

	public void setFlightSegs(List<FlightSegVO> flightSegs) {
		this.flightSegs = flightSegs;
	}

}
