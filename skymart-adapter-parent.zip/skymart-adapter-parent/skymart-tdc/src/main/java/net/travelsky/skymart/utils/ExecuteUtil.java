 
package net.travelsky.skymart.utils;
import org.apache.http.HttpHost;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.travelsky.skymart.code.http.HttpParameter;
import net.travelsky.skymart.code.http.HttpRequest;
import net.travelsky.skymart.code.http.HttpResponse;
import net.travelsky.skymart.code.http.config.URLConfig;
import net.travelsky.skymart.code.http.enums.Encoding;
import net.travelsky.skymart.code.http.enums.Scheme;
import net.travelsky.skymart.config.TDCAction;
import net.travelsky.skymart.config.TDCConfig;

/**
 *  这个类用来发起HTTP请求，并且得到响应结果
    * @ClassName: ExecuteUtil  
    * @Description: TODO  
    * @author CY  
    * @date 2018年10月10日  
    *
 */
public class ExecuteUtil {
	
	private static Logger log = LoggerFactory.getLogger(ExecuteUtil.class);
    /** 连接超时时间，缺省为8秒钟 */
    private static int    DEFAULT_CONNECTION_TIMEOUT = 8000;

    /** 回应超时时间,缺省为30秒钟 */
    private static int    DEFAULT_SO_TIMEOUT 		 = 30000;
	/**
	 *  发送HTTP请求,执行请求
	    * @Title: executeHTTP  
	    * @Description: TODO  
	    * @param @param config
	    * @param @param action
	    * @param @param param
	    * @param @return
	    * @return String
	    * @throws
	 */
    public static HttpResponse executeHTTP (TDCConfig config, TDCAction action, String json_param) {
    	
    	HttpResponse response = null;
		try {
			long start = System.currentTimeMillis();
			// 获取签名
			String sign = TDCSignUtil.getSign(json_param, action.getValue(), config.getKey());
			// 创建URL对象
			URLConfig httpURL = new URLConfig(Scheme.HTTP, config.getHost(), config.getPort(), config.getUrl());
			HttpRequest request = new HttpRequest();
			request.setScoketTimeout(DEFAULT_SO_TIMEOUT);
			request.setConnectTimeout(DEFAULT_CONNECTION_TIMEOUT);
            // 创建参数对象
			HttpParameter parameter = new HttpParameter();
            // 设置请求得参数
			request.setParameter(parameter.setParameter("action", action.getValue()));
			request.setParameter(parameter.setParameter("sign",sign));
			request.setParameter(parameter.setParameter("json_param",TDCThirdDes.getEncodeString(json_param)));
			
			// 判断是开启代理
			if(config.isOpenProxy()) {
				// 创建代理对象(在使用有线网络时候使用这个代理)
				HttpHost proxy = new HttpHost(config.getProxyHost(), config.getProxyPort());
				// 在有线网络使用代理是放开这个注释
				response = request.sendPost(httpURL, Encoding.UTF8, proxy);
				log.info("耗时：" + (System.currentTimeMillis() - start) + "ms");
				return response;
			}else {	
				// 发送请求
				response = request.sendPost(httpURL, Encoding.UTF8);
				log.info("耗时：" + (System.currentTimeMillis() - start) + "ms");
				return response;
			}
			
		} catch (Exception e) {
			log.error("ERROR:[executeHTTP]", e);
		}
		return response;
    }

}
