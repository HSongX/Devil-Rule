   
package net.travelsky.skymart.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import lombok.Data;
import lombok.ToString;

/**  
    * @ClassName: TMConfig  
    * @Description: TODO  
    * @author CY  
    * @date 2018年10月9日  
    *    
    */
@Data
@ToString 
@Component
@ConfigurationProperties(prefix="yc.http")
@PropertySource("classpath:yc-http.yml")
public class TDCConfig {
	
	@Value("${yc-host}")
	private String host;
	@Value("${yc-url}")
	private String url;
	@Value("${yc-port}")
	private String port;
	@Value("${yc-key}")
	private String key;
	@Value("${username-yc}")
	private String userName;
	@Value("${open-proxy}")
	private boolean openProxy;
	@Value("${proxy-host}")
	private String proxyHost;
	@Value("${proxy-port}")
	private int proxyPort;

}


