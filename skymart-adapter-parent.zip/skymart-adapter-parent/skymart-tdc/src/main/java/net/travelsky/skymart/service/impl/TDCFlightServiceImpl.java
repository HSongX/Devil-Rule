package net.travelsky.skymart.service.impl;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import net.travelsky.skymart.code.http.HttpResponse;
import net.travelsky.skymart.config.TDCAction;
import net.travelsky.skymart.config.TDCConfig;
import net.travelsky.skymart.contants.ResultCode;
import net.travelsky.skymart.service.ITDCFlightService;
import net.travelsky.skymart.tools.JSONUtil;
import net.travelsky.skymart.utils.ExecuteUtil;
import net.travelsky.skymart.vo.RequestVo;
import net.travelsky.skymart.vo.flight.FlightList;
import net.travelsky.skymart.vo.flight.ToAvSearchVO;


/**
 * 航班查询业务接口
 * 
 * @ClassName: TDCFlightServiceImpl
 * @Description: TODO
 * @author JL
 * @date 2018年10月12日
 *
 */

@Service
public class TDCFlightServiceImpl implements ITDCFlightService {
	
	private static Logger log = LoggerFactory.getLogger(TDCFlightServiceImpl.class);

	@Autowired private TDCConfig config;

	/**
	 * 航班接口查询
	 */
	@Override
	public FlightList flightSearch(RequestVo<ToAvSearchVO> av) {

		if (av == null) {
			return null;
		}
		try {
			av.setAppusername("");
			av.setUserName(config.getUserName());
			// 转换查询条件为JSON，并且发起请求驿程接口
			String json_param = JSONUtil.toJson(av);
			HttpResponse resp = ExecuteUtil.executeHTTP(config, TDCAction.ACTION_AV, json_param);
			if(null == resp) {
				return null;
			}
			// 校验返回结果
			if (resp.isSuccess()) {
				// 转换响应对象
				List<FlightList> rsVos = JSONUtil.toList(resp.getResponse(), FlightList.class);
				FlightList rsVo = null;
				if (rsVos != null && rsVos.size() > 0) {
					rsVo = rsVos.get(0);
					// 判定返回结果得正确性
					if (!rsVo.getResult().equals(ResultCode.SUCCESS)) {
						return null;
					}
					log.debug("rsVo=" + JSONUtil.toJson(rsVo));
					return rsVo;
				}

			}
		} catch (Exception e) {
			log.error("ERROR:[flightSearch]", e);
		}

		return null;
	}

}
