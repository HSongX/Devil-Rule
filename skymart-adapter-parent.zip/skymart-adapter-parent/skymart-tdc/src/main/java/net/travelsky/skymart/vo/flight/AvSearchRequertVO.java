package net.travelsky.skymart.vo.flight;
/**
 * 
 * @author Eli
 * @version $Id: AvSearchRequertVO.java, v 0.1 2018-1-15 下午5:59:35 Eli Exp $
 */
public class AvSearchRequertVO extends BaseRequest {

    /**  查询业务参数*/
    private ToAvSearchVO inBean;

    public ToAvSearchVO getInBean() {
        return inBean;
    }

    public void setInBean(ToAvSearchVO inBean) {
        this.inBean = inBean;
    }


}
