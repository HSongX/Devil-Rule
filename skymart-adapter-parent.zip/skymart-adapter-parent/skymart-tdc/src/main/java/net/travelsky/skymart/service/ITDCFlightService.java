package net.travelsky.skymart.service;

import net.travelsky.skymart.vo.RequestVo;
import net.travelsky.skymart.vo.flight.FlightList;
import net.travelsky.skymart.vo.flight.ToAvSearchVO;

/**
 *  航班查询业务接口
    * @ClassName: ITDCFlightService  
    * @Description: TODO  
    * @author JL  
    * @date 2018年10月12日  
    *
 */
public interface ITDCFlightService {
	
	/**
	 *  航班查询接口
	    * @Title: flightSearch  
	    * @Description: TODO  
	    * @param @param av
	    * @param @return
	    * @return ResultVo<AvSearchRequertVO>
	    * @throws
	 */
	FlightList flightSearch(RequestVo<ToAvSearchVO> av);

}
