package net.travelsky.skymart.vo.flight;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FlightSegmentDetail implements Serializable{

	private static final long serialVersionUID = 3416859470655601977L;
	//起飞航站楼
	private String depTerminal;
	//起飞机场三字码
	private String depAirport;
	//到达机场三字码
	private String arrAirport;
	//航班号
	private String flightNo;
	//承运人
	private String carrier;
	//机型
	private String fltTp;
	//起飞时间(HH:mm)
	private String depTm;
	//到达时间(HH:mm)
	private String arrTm;
	//是否直达
	private boolean isDirect;
	//经停站数
	private Integer stops;
	//是否有餐
	private boolean meal;
	//餐食代码
	private String mealCode;
	//是否是共享航班
	private boolean isShare;
	//到达航站楼
	private String arrTerminal;
	//仓位列表
	private List<FlightCabin> cabinList = new ArrayList<FlightCabin>();
	//如下字段自己添加，不是航司接口返回的数据****************************************
	//该航班最低成人票价
	private String minMarketFare;
	//航司图标url
	private String airlineLogoUrl;
	//起飞机场名字
	private String boardAirportName;
	//到达机场名字
	private String offAirportName;
	
	public String getDepTerminal() {
		return depTerminal;
	}
	public void setDepTerminal(String depTerminal) {
		this.depTerminal = depTerminal;
	}
	public String getDepAirport() {
		return depAirport;
	}
	public void setDepAirport(String depAirport) {
		this.depAirport = depAirport;
	}
	public String getArrAirport() {
		return arrAirport;
	}
	public void setArrAirport(String arrAirport) {
		this.arrAirport = arrAirport;
	}
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	public String getFltTp() {
		return fltTp;
	}
	public void setFltTp(String fltTp) {
		this.fltTp = fltTp;
	}
	public String getDepTm() {
		return depTm;
	}
	public void setDepTm(String depTm) {
		this.depTm = depTm;
	}
	public String getArrTm() {
		return arrTm;
	}
	public void setArrTm(String arrTm) {
		this.arrTm = arrTm;
	}
	public boolean isDirect() {
		return isDirect;
	}
	public void setDirect(boolean isDirect) {
		this.isDirect = isDirect;
	}
	public Integer getStops() {
		return stops;
	}
	public void setStops(Integer stops) {
		this.stops = stops;
	}
	public boolean isMeal() {
		return meal;
	}
	public void setMeal(boolean meal) {
		this.meal = meal;
	}

	public String getMealCode() {
		return mealCode;
	}
	public void setMealCode(String mealCode) {
		this.mealCode = mealCode;
	}

	public boolean isShare() {
		return isShare;
	}
	public void setShare(boolean isShare) {
		this.isShare = isShare;
	}
	public String getArrTerminal() {
		return arrTerminal;
	}
	public void setArrTerminal(String arrTerminal) {
		this.arrTerminal = arrTerminal;
	}
	public List<FlightCabin> getCabinList() {
		return cabinList;
	}
	public void setCabinList(List<FlightCabin> cabinList) {
		this.cabinList = cabinList;
	}
	public String getMinMarketFare() {
		return minMarketFare;
	}
	public void setMinMarketFare(String minMarketFare) {
		this.minMarketFare = minMarketFare;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getAirlineLogoUrl() {
		return airlineLogoUrl;
	}
	public void setAirlineLogoUrl(String airlineLogoUrl) {
		this.airlineLogoUrl = airlineLogoUrl;
	}
	public String getBoardAirportName() {
		return boardAirportName;
	}
	public void setBoardAirportName(String boardAirportName) {
		this.boardAirportName = boardAirportName;
	}
	public String getOffAirportName() {
		return offAirportName;
	}
	public void setOffAirportName(String offAirportName) {
		this.offAirportName = offAirportName;
	}
	
	

}
