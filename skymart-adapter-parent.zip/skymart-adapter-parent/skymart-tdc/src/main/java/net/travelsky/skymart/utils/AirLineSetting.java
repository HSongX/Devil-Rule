 
package net.travelsky.skymart.utils;

import java.util.HashMap;
import java.util.Map;

/**
 *  航司设置获取
    * @ClassName: AirLineSetting  
    * @Description: TODO  
    * @author CY  
    * @date 2018年10月29日  
    *
 */
public class AirLineSetting {
	
	// 添加航司code
	private static Map<String,String> airLineMap = new HashMap<String,String>();
	
	public static Map<String,String> getAirLineMap(){

		return airLineMap;
	}
	
	public static void setAirLineCode(String key) {
		airLineMap.clear();
		airLineMap.put(key, "");
	}
}
