package net.travelsky.skymart.vo.flight;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FlightCabin implements Serializable{

	private static final long serialVersionUID = 5935541008875930672L;
	//仓位代码
	private String cabinCode;
	//仓位等级
	private String cabinClass;
	//可销售数
	private String inventory;
	//产品列表
	private List<FlightProduct> flightProduct = new ArrayList<FlightProduct>();
	//舱位等级名称
	private String cabinClassName;
	public String getCabinCode() {
		return cabinCode;
	}
	public void setCabinCode(String cabinCode) {
		this.cabinCode = cabinCode;
	}
	public String getCabinClass() {
		return cabinClass;
	}
	public void setCabinClass(String cabinClass) {
		this.cabinClass = cabinClass;
	}
	public String getInventory() {
		return inventory;
	}
	public void setInventory(String inventory) {
		this.inventory = inventory;
	}
	public List<FlightProduct> getFlightProduct() {
		return flightProduct;
	}
	public void setFlightProduct(List<FlightProduct> flightProduct) {
		this.flightProduct = flightProduct;
	}
	public String getCabinClassName() {
		return cabinClassName;
	}
	public void setCabinClassName(String cabinClassName) {
		this.cabinClassName = cabinClassName;
	}
	
}
