package net.travelsky.skymart.vo.flight;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FlightList implements Serializable{
	
	private static final long serialVersionUID = 3987668557819126686L;
	//返回结果
	private String result;
	//结果信息
	private String message;
	//错误码
	private String errCode;
	//错误信息
	private String errMessage;
	//行程列表
	private List<FlightSegmentList> flightSegmentList = new ArrayList<FlightSegmentList>();
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getErrCode() {
		return errCode;
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public String getErrMessage() {
		return errMessage;
	}
	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}
	public List<FlightSegmentList> getFlightSegmentList() {
		return flightSegmentList;
	}
	public void setFlightSegmentList(List<FlightSegmentList> flightSegmentList) {
		this.flightSegmentList = flightSegmentList;
	}
	
	

}
