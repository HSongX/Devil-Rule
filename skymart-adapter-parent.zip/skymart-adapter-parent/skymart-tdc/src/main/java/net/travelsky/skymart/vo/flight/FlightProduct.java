package net.travelsky.skymart.vo.flight;

import java.io.Serializable;

public class FlightProduct implements Serializable{

	private static final long serialVersionUID = 2943428697797353308L;
	//产品类型
	private String productType;
	//运价航程类型
	private String priceRouteType;
	//成人产品价格
	private FlightFare adultFare;
	//儿童产品价格
	private FlightFare childFare;
	//婴儿产品价格
	private FlightFare infantFare;
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getPriceRouteType() {
		return priceRouteType;
	}
	public void setPriceRouteType(String priceRouteType) {
		this.priceRouteType = priceRouteType;
	}
	public FlightFare getAdultFare() {
		return adultFare;
	}
	public void setAdultFare(FlightFare adultFare) {
		this.adultFare = adultFare;
	}
	public FlightFare getChildFare() {
		return childFare;
	}
	public void setChildFare(FlightFare childFare) {
		this.childFare = childFare;
	}
	public FlightFare getInfantFare() {
		return infantFare;
	}
	public void setInfantFare(FlightFare infantFare) {
		this.infantFare = infantFare;
	}
	
	


}
