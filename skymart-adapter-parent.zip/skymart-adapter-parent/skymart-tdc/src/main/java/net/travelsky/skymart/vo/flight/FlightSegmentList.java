package net.travelsky.skymart.vo.flight;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FlightSegmentList implements Serializable{

	private static final long serialVersionUID = -6628696580961499845L;
	//是否飞猪航班数据
	private boolean fliggy;
	//目的城市三字码
	private String destinationCity;
	//旅行顺序
	private Integer segNo;
	//起飞城市三字码
	private String originCity;
	//航班日期
	private String flightDate;
	//航段类别
	private String segmentType;
	//官网数据来源
	private String sourse;
	//航班详情
	private List<FlightSegmentDetail> flightSegmentDetail = new ArrayList<FlightSegmentDetail>();
	//如下字段自己添加，不是航司接口返回的数据****************************************
	//目的城市名字
	private String destinationCityName;
	//起飞城市名字
	private String originCityName;
	//航司名字
	private String airlineName;
	
	public boolean isFliggy() {
		return fliggy;
	}
	public void setFliggy(boolean fliggy) {
		this.fliggy = fliggy;
	}
	public String getDestinationCity() {
		return destinationCity;
	}
	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}
	
	public Integer getSegNo() {
		return segNo;
	}
	public void setSegNo(Integer segNo) {
		this.segNo = segNo;
	}
	public String getOriginCity() {
		return originCity;
	}
	public void setOriginCity(String originCity) {
		this.originCity = originCity;
	}
	public String getFlightDate() {
		return flightDate;
	}
	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}
	public String getSegmentType() {
		return segmentType;
	}
	public void setSegmentType(String segmentType) {
		this.segmentType = segmentType;
	}
	public String getSourse() {
		return sourse;
	}
	public void setSourse(String sourse) {
		this.sourse = sourse;
	}
	public List<FlightSegmentDetail> getFlightSegmentDetail() {
		return flightSegmentDetail;
	}
	public void setFlightSegmentDetail(List<FlightSegmentDetail> flightSegmentDetail) {
		this.flightSegmentDetail = flightSegmentDetail;
	}
	public String getDestinationCityName() {
		return destinationCityName;
	}
	public void setDestinationCityName(String destinationCityName) {
		this.destinationCityName = destinationCityName;
	}
	public String getOriginCityName() {
		return originCityName;
	}
	public void setOriginCityName(String originCityName) {
		this.originCityName = originCityName;
	}
	public String getAirlineName() {
		return airlineName;
	}
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
