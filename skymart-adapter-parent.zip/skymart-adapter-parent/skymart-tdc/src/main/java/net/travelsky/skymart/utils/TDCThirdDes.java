 
package net.travelsky.skymart.utils;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 * @Description 字符串 DESede(3DES) 加密
 * @author wangsong
 * @date 2015年9月6日 下午3:11:33
 * @Company TravelSky
 */
public class TDCThirdDes {

	public static final String Algorithm = "DESede"; // 定义加密算法,可用DES,DESede,Blowfish

	public static final byte[] keyBytes = { 0x2f, 0x63, 0x4F, 0x58,
			(byte) 0x88, 0x12, 0x40, 0x38, 0x28, 0x22, 0x79, 0x51, (byte) 0xCB,
			(byte) 0xDD, 0x52, 0x66, 0x72, 0x29, 0x73, (byte) 0x98, 0x31, 0x45,
			0x26, (byte) 0xF3 }; // 24字节的密钥

	// keybyte为加密密钥，长度为24字节
	// src为被加密的数据缓冲区（源）
	public static byte[] encryptMode(byte[] keybyte, byte[] src) {
		try {
			// 生成密钥
			SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);
			// 加密
			Cipher c1 = Cipher.getInstance(Algorithm);
			c1.init(Cipher.ENCRYPT_MODE, deskey);
			return c1.doFinal(src);// 在单一方面的加密或解密
		} catch (java.security.NoSuchAlgorithmException e1) {
			// TODO: handle exception
			e1.printStackTrace();
		} catch (javax.crypto.NoSuchPaddingException e2) {
			e2.printStackTrace();
		} catch (java.lang.Exception e3) {
			e3.printStackTrace();
		}
		return null;
	}

	// keybyte为加密密钥，长度为24字节
	// src为加密后的缓冲区
	public static byte[] decryptMode(byte[] keybyte, byte[] src) {
		try {
			// 生成密钥
			SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);
			// 解密
			Cipher c1 = Cipher.getInstance(Algorithm);
			c1.init(Cipher.DECRYPT_MODE, deskey);
			return c1.doFinal(src);
		} catch (java.security.NoSuchAlgorithmException e1) {
			// TODO: handle exception
			e1.printStackTrace();
		} catch (javax.crypto.NoSuchPaddingException e2) {
			e2.printStackTrace();
		} catch (java.lang.Exception e3) {
			e3.printStackTrace();
		}
		return null;
	}

	// 转换成十六进制字符串
	public static String byte2Hex(byte[] b) {
    	// [commented by zonggf 2016-07-14] 修改循环中使用string 拼接字符串
		// String hs = "";
		StringBuffer hsSb = new StringBuffer();
		String stmp = "";
		for (int n = 0; n < b.length; n++) {
			stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
			if (stmp.length() == 1) {
				hsSb.append("0" + stmp);
				// hs = hs + "0" + stmp;
			} else {
				hsSb.append(stmp);
				// hs = hs + stmp;
			}
			// if (n < b.length - 1)
			// hs = hs + ":";
		}
		// return hs.toUpperCase();
		return hsSb.toString().toUpperCase();
	}

	/*
	 * 16进制数字字符集
	 */
	private static String hexString = "0123456789ABCDEF";

	/*
	 * 将字符串编码成16进制数字,适用于所有字符（包括中文）
	 */
	public static String encode(String str) {
		// 根据默认编码获取字节数组
		byte[] bytes = str.getBytes();
		StringBuilder sb = new StringBuilder(bytes.length * 2);
		// 将字节数组中每个字节拆解成2位16进制整数
		for (int i = 0; i < bytes.length; i++) {
			sb.append(hexString.charAt((bytes[i] & 0xf0) >> 4));
			sb.append(hexString.charAt((bytes[i] & 0x0f) >> 0));
		}
		return sb.toString();
	}

	/*
	 * 将16进制数字解码成字符串,适用于所有字符（包括中文）
	 */
	public static byte[] decode(String bytes) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(
				bytes.length() / 2);
		// 将每2位16进制整数组装成一个字节
		for (int i = 0; i < bytes.length(); i += 2)
			baos.write((hexString.indexOf(bytes.charAt(i)) << 4 | hexString
					.indexOf(bytes.charAt(i + 1))));
		return baos.toByteArray();
	}

	// 解密的
	public static String getDecodeString(String encodeString) {
		String decodeStr = "";
		byte[] b = decode(encodeString/* .replaceAll(":", "") */);
		byte[] srcBytes = decryptMode(keyBytes, b);
		decodeStr = new String(srcBytes);
		return decodeStr;
	}

	// 加密的
	public static String getEncodeString(String src) {
		byte[] encoded = encryptMode(keyBytes, src.getBytes());
		String temp = new String(encoded);
		temp = byte2Hex(encoded);
		return temp;
	}

	// 解密的
	public static String getDecodeString(String encodeString,String charset) {
		String decodeStr = "";
		byte[] b = decode(encodeString);
		byte[] srcBytes = decryptMode(keyBytes, b);
		try {
			decodeStr = new String(srcBytes,charset);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return decodeStr;
	}

	// 加密的
	public static String getEncodeString(String src,String charset) {
		try {
			byte[] encoded = encryptMode(keyBytes, src.getBytes(charset));
			String temp = byte2Hex(encoded);
			return temp;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 添加新安全算法,如果用JCE就要把它添加进去
		// Security.addProvider(new com.sun.crypto.provider.SunJCE());

		String szSrc = "super";
		System.out.println("加密前的字符串:" + szSrc);

		String en16Src = getEncodeString(szSrc);
		System.out.println("加密后的十六进制串:" + en16Src);

		String de16Src = getDecodeString(en16Src);
		System.out.println("解密后的字符串:" + de16Src);
	}

}
