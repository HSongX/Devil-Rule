package net.travelsky.skymart.vo.flight;
/**
 * 
 * @author Eli
 * @version $Id: BaseRequest.java, v 0.1 2018-1-15 下午5:56:36 Eli Exp $
 */
public class BaseRequest {
    /**
     * 用户名
     */
    private String userName;
    /**
     * 下级用户名
     */
    private String appusername;
    /**
     * 易行有户名
     */
    private String yxusername;
    public String getAppusername() {
        return appusername;
    }
    public void setAppusername(String appusername) {
        this.appusername = appusername;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String getYxusername() {
        return yxusername;
    }
    public void setYxusername(String yxusername) {
        this.yxusername = yxusername;
    }
    public String toString(){
        return "userName:"+this.userName+",appusername:"+appusername;
    }
}
